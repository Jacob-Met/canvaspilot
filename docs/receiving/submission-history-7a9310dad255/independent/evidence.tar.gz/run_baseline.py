import os,subprocess,pathlib,json,time
r=pathlib.Path("/tmp/hamon-7a9310dad255-canvas-history-memory")
env=os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE="1",CANVAS_BASE_URL="http://127.0.0.1:1",
           CANVAS_API_TOKEN="memory-fixture-token-not-live",CANVAS_PROFILE=str(r/"unused-parent-profile"),
           CANVAS_SESSION_PORT="1")
cmd=["/home/jacob/canvaspilot-announcements-3dcb83a1/.venv/bin/python","-B",str(r/"receive_history.py"),
     "--source","/tmp/hamon-7a9310dad255-canvas-history/baseline","--out",str(r/"baseline-run"),"--baseline"]
start=time.monotonic()
p=subprocess.run(cmd,env=env,capture_output=True,timeout=90)
(r/"baseline-process.stdout").write_bytes(p.stdout)
(r/"baseline-process.stderr").write_bytes(p.stderr)
(r/"baseline-execution.json").write_text(json.dumps({"command":cmd,"exit":p.returncode,"seconds":time.monotonic()-start},indent=2)+"\n")
print(p.stdout.decode(errors="replace")); print(p.stderr.decode(errors="replace")); print("exit",p.returncode)
raise SystemExit(p.returncode)
