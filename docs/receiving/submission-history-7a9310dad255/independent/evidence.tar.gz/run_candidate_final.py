import os,subprocess,pathlib,json,time,hashlib
root=pathlib.Path("/tmp/hamon-7a9310dad255-canvas-history-memory")
owner=pathlib.Path("/tmp/hamon-7a9310dad255-canvas-history")
manifest_bytes=(owner/"candidate-final-source-manifest.json").read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest()=="4e88d12e61424cc87b5717b1e9df078802818696e7f2e32c2c2502f1fcd2bce0"
manifest=json.loads(manifest_bytes)
assert manifest["native_head"]=="bc1baddd38b19fc454b2adb4a53acfd3cb6c254d"
assert manifest["native_tree"]=="4e114ac2aba9daec205b186b66ca1447e900d944"
snapshot=root/"received-candidate-bc1bad"
snapshot.mkdir()
entries=[item for item in manifest["files"] if item["path"].startswith("src/")]
previous=json.loads((root/"received-corrected-candidate-owner-manifest.json").read_text())
before={item["path"]:item for item in previous["files"]}
after={item["path"]:item for item in manifest["files"]}
assert set(before)==set(after)
different=[path for path in before if before[path]!=after[path]]
assert different==["src/canvaspilot/mcp_server.py"],different
(root/"final-candidate-adoption.json").write_text(json.dumps({
    "previous_head":previous["native_head"],"final_head":manifest["native_head"],
    "different_paths":different,"all_other_manifest_entries_exact":len(before)-1,
    "scope":"Manifest metadata comparison plus exact byte verification of all native src/ inputs before receiving."
},indent=2)+"\n")
for item in entries:
    data=(owner/"candidate"/item["path"]).read_bytes()
    assert len(data)==item["bytes"] and hashlib.sha256(data).hexdigest()==item["sha256"],item["path"]
    assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==item["git_blob"],item["path"]
    dest=snapshot/item["path"]
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    dest.chmod(0o444)
for dest in sorted(snapshot.rglob("*"),reverse=True):
    if dest.is_dir(): dest.chmod(0o555)
snapshot.chmod(0o555)
(root/"received-final-candidate-owner-manifest.json").write_bytes(manifest_bytes)
(root/"received-final-candidate-binding.json").write_text(json.dumps({
    "owner_head":manifest["native_head"],"owner_tree":manifest["native_tree"],
    "owner_manifest_sha256":hashlib.sha256(manifest_bytes).hexdigest(),
    "public_parent":manifest["public_parent"],"snapshot":str(snapshot),
    "scope":"Read-only copy of exact candidate src/ closure; not a full 520-file checkout.",
    "candidate_source_inspected_by_receiver":False,"source_entries":entries
},indent=2)+"\n")
for name,sha in {
    "receive_history.py":"158aa881f34a479a0ebcca0bf679f6cdff28ef8a8588d5d2a6a585e1983e84c3",
    "contract.json":"1ca24427f6dd1bcb9bcdd3e5b69614b3dd6cc1c69cb82d75c2aacd2def23b7fc",
    "fixture.json":"4f5ca3be3b5676be3262fc9f503377231edbab562daac6e2c9f79ba5518d32aa",
}.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
env=os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE="1",CANVAS_BASE_URL="http://127.0.0.1:1",
           CANVAS_API_TOKEN="memory-fixture-token-not-live",CANVAS_PROFILE=str(root/"unused-parent-profile"),
           CANVAS_SESSION_PORT="1")
cmd=["/home/jacob/canvaspilot-announcements-3dcb83a1/.venv/bin/python","-B",str(root/"receive_history_selected.py"),
     "--source",str(snapshot),"--out",str(root/"final-candidate-mcp-run")]
start=time.monotonic()
p=subprocess.run(cmd,env=env,capture_output=True,timeout=180)
(root/"final-candidate-process.stdout").write_bytes(p.stdout)
(root/"final-candidate-process.stderr").write_bytes(p.stderr)
(root/"final-candidate-execution.json").write_text(json.dumps({
    "command":cmd,"exit":p.returncode,"seconds":time.monotonic()-start,
    "owner_head":manifest["native_head"],"source_entries":len(entries)
},indent=2)+"\n")
for item in entries:
    assert hashlib.sha256((owner/"candidate"/item["path"]).read_bytes()).hexdigest()==item["sha256"],item["path"]
print(p.stdout.decode(errors="replace")); print(p.stderr.decode(errors="replace")); print("exit",p.returncode)
raise SystemExit(p.returncode)
