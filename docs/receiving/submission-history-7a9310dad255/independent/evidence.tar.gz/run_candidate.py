import os,subprocess,pathlib,json,time,hashlib
root=pathlib.Path("/tmp/hamon-7a9310dad255-canvas-history-memory")
owner=pathlib.Path("/tmp/hamon-7a9310dad255-canvas-history")
manifest_bytes=(owner/"candidate-source-manifest.json").read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest()=="d361118663d86ce2aac0c611eb42dba366f4f92acb5026168fac6c3addee686a"
manifest=json.loads(manifest_bytes)
assert manifest["native_head"]=="d95a11f65314779a9a35993ae2072093fba18990"
assert manifest["native_tree"]=="d84dce7757f6dfc74234f8047e006b3abcc04e1d"
snapshot=root/"received-candidate-d95a11"
snapshot.mkdir()
entries=[item for item in manifest["files"] if item["path"].startswith("src/")]
for item in entries:
    data=(owner/"candidate"/item["path"]).read_bytes()
    assert len(data)==item["bytes"] and hashlib.sha256(data).hexdigest()==item["sha256"],item["path"]
    assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==item["git_blob"],item["path"]
    dest=snapshot/item["path"]
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    dest.chmod(0o444)
for dest in sorted(snapshot.rglob("*"),reverse=True):
    if dest.is_dir(): dest.chmod(0o555)
snapshot.chmod(0o555)
(root/"received-candidate-owner-manifest.json").write_bytes(manifest_bytes)
(root/"received-candidate-binding.json").write_text(json.dumps({
    "owner_head":manifest["native_head"],"owner_tree":manifest["native_tree"],
    "owner_manifest_sha256":hashlib.sha256(manifest_bytes).hexdigest(),
    "public_parent":manifest["public_parent"],"snapshot":str(snapshot),
    "scope":"Read-only copy of exact candidate src/ closure; not a full 520-file checkout.",
    "candidate_source_inspected_by_receiver":False,"source_entries":entries
},indent=2)+"\n")
for name,sha in {
    "receive_history.py":"158aa881f34a479a0ebcca0bf679f6cdff28ef8a8588d5d2a6a585e1983e84c3",
    "contract.json":"1ca24427f6dd1bcb9bcdd3e5b69614b3dd6cc1c69cb82d75c2aacd2def23b7fc",
    "fixture.json":"4f5ca3be3b5676be3262fc9f503377231edbab562daac6e2c9f79ba5518d32aa",
}.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
env=os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE="1",CANVAS_BASE_URL="http://127.0.0.1:1",
           CANVAS_API_TOKEN="memory-fixture-token-not-live",CANVAS_PROFILE=str(root/"unused-parent-profile"),
           CANVAS_SESSION_PORT="1")
cmd=["/home/jacob/canvaspilot-announcements-3dcb83a1/.venv/bin/python","-B",str(root/"receive_history.py"),
     "--source",str(snapshot),"--out",str(root/"candidate-run")]
start=time.monotonic()
p=subprocess.run(cmd,env=env,capture_output=True,timeout=180)
(root/"candidate-process.stdout").write_bytes(p.stdout)
(root/"candidate-process.stderr").write_bytes(p.stderr)
(root/"candidate-execution.json").write_text(json.dumps({
    "command":cmd,"exit":p.returncode,"seconds":time.monotonic()-start,
    "owner_head":manifest["native_head"],"source_entries":len(entries)
},indent=2)+"\n")
for item in entries:
    assert hashlib.sha256((owner/"candidate"/item["path"]).read_bytes()).hexdigest()==item["sha256"],item["path"]
print(p.stdout.decode(errors="replace")); print(p.stderr.decode(errors="replace")); print("exit",p.returncode)
raise SystemExit(p.returncode)
