import json,hashlib,difflib
from pathlib import Path
r=Path("/tmp/hamon-7a9310dad255-canvas-history-memory")
m=json.loads((r/"received-current-79a-candidate-owner-manifest.json").read_text())
old=json.loads((r/"received-final-candidate-owner-manifest.json").read_text())
entries={x["path"]:x for x in m["files"]};prev={x["path"]:x for x in old["files"]}
paths=old["changed_paths"]
same=[p for p in paths if entries[p]["git_blob"]==prev[p]["git_blob"]]
different=[p for p in paths if entries[p]["git_blob"]!=prev[p]["git_blob"]]
assert len(paths)==9 and len(same)==7 and different==["README.md","src/canvaspilot/cli.py"],(same,different)
a=(r/"received-candidate-bc1bad/src/canvaspilot/cli.py").read_bytes()
b=(r/"received-candidate-67a196/src/canvaspilot/cli.py").read_bytes()
aa="from canvaspilot.client import CanvasAuthError, CanvasPaginationError";zz="from canvaspilot.client import CanvasAuthError"
cc="except (CanvasAuthError, CanvasPaginationError, httpx.HTTPError, ValueError, TypeError, OSError) as error:"
vv="except (CanvasAuthError, httpx.HTTPError, ValueError, TypeError, OSError) as error:"
s=b.decode();assert s.count(aa)==1 and s.count(cc)==1
assert s.replace(aa,zz,1).replace(cc,vv,1).encode()==a
owner=Path("/tmp/hamon-7a9310dad255-canvas-history/current-79a/candidate")
newread=(owner/"README.md").read_bytes()
assert hashlib.sha1(b"blob "+str(len(newread)).encode()+b"\0"+newread).hexdigest()==entries["README.md"]["git_blob"]
current=json.loads((r/"current-main-79a-observations-v2.json").read_text())
upstream=next(x["content"] for x in current["files"] if x["path"]=="README.md")
oldroot=Path("/tmp/hamon-7a9310dad255-canvas-history")
base=(oldroot/"baseline/README.md").read_text()
qualified=(oldroot/"candidate/README.md").read_text()
matcher=difflib.SequenceMatcher(None,base.splitlines(True),qualified.splitlines(True),autojunk=False)
composed=upstream
hunks=[]
for tag,i,j,k,l in matcher.get_opcodes():
    if tag=="equal":continue
    before="".join(base.splitlines(True)[i:j]);after="".join(qualified.splitlines(True)[k:l])
    if before:
        assert composed.count(before)==1,(tag,before)
        composed=composed.replace(before,after,1)
    else:
        anchor="".join(base.splitlines(True)[max(0,i-1):i])
        assert composed.count(anchor)==1,(tag,anchor)
        composed=composed.replace(anchor,anchor+after,1)
    hunks.append({"operation":tag,"before":before,"after":after})
assert composed.encode()==newread
def pin(path):
    b=path.read_bytes();return {"path":str(path),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
receipt=json.loads((r/"current-79a-candidate-run/receipt.json").read_text())
run=json.loads((r/"current-79a-candidate-execution.json").read_text())
out={"accepted":True,"kind":"unchanged independent current-parent receiving and narrow composition source review","public_parent":"79a2f2b2cbb7e74128d731cf096c7e86f1942d4b","public_parent_tree":"0114a6230c473c1ee1d01b99c7121c754b781d54","candidate_head":m["native_head"],"candidate_tree":m["native_tree"],"source_manifest":pin(r/"received-current-79a-candidate-owner-manifest.json"),"unchanged_feature_files":same,"composed_feature_files":different,"cli_review":"Reversing exactly the two incoming calendar-specific CanvasPaginationError additions restores the complete accepted bc1 CLI byte-for-byte.","readme_review":"Applying only the exact original history README changes onto verified current79a README reproduces the entire composed README byte-for-byte.","readme_hunks":hunks,"receipt":pin(r/"current-79a-candidate-run/receipt.json"),"run":run,"execution":pin(r/"current-79a-candidate-execution.json"),"stdout":pin(r/"current-79a-candidate-process.stdout"),"stderr":pin(r/"current-79a-candidate-process.stderr"),"runner":pin(r/"receive_history.py"),"contract":pin(r/"contract.json"),"fixture":pin(r/"fixture.json"),"counts":{k:receipt.get(k) for k in ["passed","failed","assertions","source_unchanged"]},"source_entries":len([p for p in entries if p.startswith("src/")]),"limits":"Native API, synthetic loopback HTTP CLI, and actual MCP stdio receiving; no school/account/browser/session-broker activation or deployment."}
dest=r/"current-79a-independent-acceptance.json"
with dest.open("x") as f:json.dump(out,f,indent=2);f.write("\n")
print(json.dumps({"acceptance":pin(dest),"receipt":out["receipt"],"candidate":m["native_head"],"tree":m["native_tree"],"same_features":same,"composed":different,"counts":out["counts"],"execution":run},indent=2))
