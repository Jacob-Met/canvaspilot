"""Inspect the actual MCP stdio catalog without invoking a Canvas reader."""
import asyncio
import json
import os
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    params = StdioServerParameters(
        command=sys.executable,
        args=["-B", "-m", "canvaspilot.mcp_server"],
        env={key: value for key, value in os.environ.items()
             if key in {"PATH", "PYTHONPATH", "PYTHONDONTWRITEBYTECODE",
                        "CANVAS_API_TOKEN", "CANVAS_PROFILE", "CANVAS_BASE_URL",
                        "NO_PROXY", "LANG", "LC_ALL"}},
    )
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            catalog = await session.list_tools()
            names = [tool.name for tool in catalog.tools]
            print(json.dumps({"tools": names,
                              "submission_history_present": "canvas_submission_history" in names}))
            if sys.argv[1] == "baseline":
                assert "canvas_submission_history" not in names
            else:
                assert "canvas_submission_history" in names


if __name__ == "__main__":
    asyncio.run(main())
