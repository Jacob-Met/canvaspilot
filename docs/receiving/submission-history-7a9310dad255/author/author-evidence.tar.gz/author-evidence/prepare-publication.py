#!/usr/bin/env python3
"""Package exact owned source and raw receiving evidence."""
import base64, gzip, hashlib, io, json, pathlib, subprocess, tarfile, time
R=pathlib.Path("/tmp/hamon-7a9310dad255-canvas-history")
M=pathlib.Path("/tmp/hamon-7a9310dad255-canvas-history-memory")
OUT=R/"publication-author"
PREFIX="docs/receiving/submission-history-7a9310dad255"
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def get(p):return json.loads(p.read_bytes())
def meta(p,b,mode="100644"):return {"path":p,"mode":mode,"bytes":len(b),"sha256":sha(b),"git_blob":blob(b)}
def git(repo,*args):return subprocess.check_output(["git",*args],cwd=repo)
def write_json(p,j):p.write_text(json.dumps(j,indent=2)+"\n")
manifest=get(R/"current-79a/candidate-source-manifest.json")
assert sha((R/"current-79a/candidate-source-manifest.json").read_bytes())=="b81aed59a0751b602a425b745ad1aa8e73eb2f7c24a5a6c3609e3119ff8b779a"
assert manifest["native_head"]=="67a1963d8b34bff33ee504c8fd8a1fc4c4af9e86"
assert manifest["native_tree"]=="bf2d1499fe0e3fdd620297fa01a1ab705b46637b"
source=R/"current-79a/candidate"
assert git(source,"rev-parse","HEAD").decode().strip()==manifest["native_head"]
assert len(manifest["files"])==712
for e in manifest["files"]:
    b=(source/e["path"]).read_bytes()
    assert meta(e["path"],b,e["mode"])==e,e["path"]
    assert ("100755" if (source/e["path"]).stat().st_mode&0o111 else "100644")==e["mode"]
corrected=get(R/"candidate-current79-clean-env-checks/receipt.json")
assert corrected["passed"] and corrected["selected_source_unchanged"]
assert len(corrected["checks"])==1 and corrected["checks"][0]["exit"]==0
prior=get(R/"candidate-current79-checks/receipt.json")
assert not prior["passed"] and prior["selected_source_unchanged"]
assert [(x["name"],x["exit"]) for x in prior["checks"]]==[("mcp-catalog",0),("inherited-suite",1),("configured-lint",0)]
suite=(R/"candidate-current79-clean-env-checks/inherited-suite.stdout.log").read_text()
assert "603 passed" in suite and "1 skipped" in suite and "6 subtests passed" in suite
for name in ["candidate-current79-clean-env-checks","candidate-current79-checks"]:
    for check in get(R/name/"receipt.json")["checks"]:
        for kind in ["stdout","stderr"]:
            assert sha((R/name/(check["name"]+"."+kind+".log")).read_bytes())==check[kind+"_sha256"]
receiver_bindings=[];receiver_entries=[]
for label,payload_name,prefix in [
 ("original-qualified-55fe","publication-payload.json",PREFIX+"/independent"),
 ("current-qualified-79a","publication-current-79a-payload.json",PREFIX+"/independent-current-79a")]:
    payload=get(M/payload_name)
    assert len(payload["entries"])==payload["file_count"]
    for e in payload["entries"]:
        b=pathlib.Path(e["native"]).read_bytes()
        assert len(b)==e["bytes"] and sha(b)==e["sha256"] and blob(b)==e["git_blob"],e["path"]
        receiver_entries.append({**e,"path":prefix+"/"+e["path"]})
    archive_entry=next(e for e in payload["entries"] if e["encoding"]=="base64")
    archive_manifest=get(pathlib.Path(next(e for e in payload["entries"] if e["path"]=="archive-manifest.json")["native"]))
    expected={e["path"]:e for e in archive_manifest.get("files",archive_manifest.get("members"))}
    checked=0
    with tarfile.open(archive_entry["native"],"r:gz") as archive:
        for member in archive.getmembers():
            assert member.isfile(),member.name
            b=archive.extractfile(member).read();e=expected[member.name]
            assert len(b)==e["bytes"] and sha(b)==e["sha256"],member.name
            if "git_blob" in e:assert blob(b)==e["git_blob"]
            checked+=1
    assert checked==payload["archive_members"]==len(expected)
    receiver_bindings.append({"label":label,"payload":meta(payload_name,(M/payload_name).read_bytes()),"file_count":payload["file_count"],"archive_members_verified":checked,"archive":{k:v for k,v in archive_entry.items() if k!="native"}})
acceptance=get(M/"publication-current-79a/acceptance.json")
assert acceptance["accepted"] and acceptance["candidate_head"]==manifest["native_head"]
assert acceptance["counts"]=={"passed":9,"failed":0,"assertions":465,"source_unchanged":True}
assert acceptance["source_manifest"]["sha256"]==sha((R/"current-79a/candidate-source-manifest.json").read_bytes())
OUT.mkdir()
members={}
def add(p,b,mode=0o644):
    assert p not in members and not p.startswith("/") and ".." not in pathlib.PurePosixPath(p).parts,p
    members[p]=(b,mode)
for p in sorted(R.rglob("*")):
    rel=p.relative_to(R)
    if any(x in {".git","__pycache__",".pytest_cache"} for x in rel.parts):continue
    if rel.parts[0] in {"baseline","candidate","publication-author"}:continue
    if rel.parts[:2] in [("current-79a","baseline"),("current-79a","candidate")]:continue
    if rel.as_posix()=="current-79a-github-source.tar.gz":continue
    if p.is_symlink():raise AssertionError(str(p))
    if p.is_file():add("author-evidence/"+rel.as_posix(),p.read_bytes(),0o755 if p.stat().st_mode&0o111 else 0o644)
for label,repo,head in [
 ("initial-d95",R/"candidate","d95a11f65314779a9a35993ae2072093fba18990"),
 ("cli-corrected-33e",R/"candidate","33e5d1257851ef97021c70b82cd523240a25e1b5"),
 ("mcp-corrected-bc1",R/"candidate","bc1baddd38b19fc454b2adb4a53acfd3cb6c254d"),
 ("current-79a-67a",source,manifest["native_head"])]:
    add("owned-source/"+label+"/commit.txt",git(repo,"cat-file","commit",head))
    for p in manifest["changed_paths"]:add("owned-source/"+label+"/"+p,git(repo,"show",head+":"+p))
for label,repo,head in [
 ("capture-55fe",R/"baseline","eabf2296c3bb0e6195d61f8d173d297012187a94"),
 ("capture-79a",R/"current-79a/baseline",manifest["native_capture_head"])]:
    add("owned-source/"+label+"/commit.txt",git(repo,"cat-file","commit",head))
archive_path=OUT/"author-evidence.tar.gz"
with archive_path.open("xb") as raw:
    with gzip.GzipFile(filename="",fileobj=raw,mode="wb",mtime=0,compresslevel=9) as gz:
        with tarfile.open(fileobj=gz,mode="w",format=tarfile.PAX_FORMAT) as archive:
            for name,(b,mode) in sorted(members.items()):
                ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=mode;ti.mtime=0
                archive.addfile(ti,io.BytesIO(b))
with tarfile.open(archive_path,"r:gz") as archive:
    readback=archive.getmembers()
    assert len(readback)==len(members)
    for member in readback:assert (archive.extractfile(member).read(),member.mode)==members[member.name]
archive_meta=meta(archive_path.name,archive_path.read_bytes())
write_json(OUT/"archive-manifest.json",{"schema":"canvaspilot.submission-history.author-archive.v1","archive":archive_meta,"member_count":len(members),"all_members_readback_exact":True,"members":[meta(name,b,"100755" if mode&0o111 else "100644") for name,(b,mode) in sorted(members.items())]})
qualification={
 "schema":"canvaspilot.submission-history.author-qualification.v1","accepted":True,"created_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
 "public_parent":manifest["public_parent"],"public_parent_tree":manifest["public_parent_tree"],"native_source_head":manifest["native_head"],"native_source_tree":manifest["native_tree"],
 "publication_ancestry":"Publication must parent actual public 79a, not the native capture commit.",
 "source_manifest":meta("current-79a/candidate-source-manifest.json",(R/"current-79a/candidate-source-manifest.json").read_bytes()),
 "source_files_verified":712,"feature_paths":manifest["changed_paths"],"unrelated_parent_leaves_preserved":703,
 "current_native_gate":{"passed":603,"skipped":1,"subtests_passed":6,"receipt":meta("candidate-current79-clean-env-checks/receipt.json",(R/"candidate-current79-clean-env-checks/receipt.json").read_bytes()),"raw_result":suite.strip().splitlines()[-1],"source_unchanged":True},
 "configured_lint_and_registered_mcp_catalog":{"passed":True,"receipt":meta("candidate-current79-checks/receipt.json",(R/"candidate-current79-checks/receipt.json").read_bytes()),"scope":"Unchanged current source; the inherited-suite failure in this receipt is separately preserved."},
 "independent_current":{"groups":9,"assertions":465,"accepted":True,"acceptance":meta("acceptance.json",(M/"publication-current-79a/acceptance.json").read_bytes())},
 "receiver_packet_bindings":receiver_bindings,"author_archive":archive_meta,"author_archive_members":len(members),
 "preserved_failures":[
  "Initial directory setup ENOENT and missing rg inspection helper.",
  "Original baseline runner synthetic global token selected PAT in six broker stub cases: 408 passed, 6 failed. All six stopped on TLS verification; no successful remote HTTP response. Empty global token fixed only the harness; corrected baseline 414 passed.",
  "Initial d95 source: 472 passed, 9 failed, two Ruff findings; independent receiver 7/9. Actual CLI httpx INFO stderr contamination plus maintained SDK annotation attribute mismatch.",
  "Scoped CLI logger restoration and maintained wire-annotation assertion correction: independent receiver 9/9 and 465 assertions; authored focus 66/67, expected malformed-shape message masked by MCP SDK.",
  "Anticipated ValueError translated to SDK ToolError in only the new MCP tool, retaining error status; authored complete 481 passed on 55fe, independent affected MCP groups 82 assertions passed.",
  "Current original runner: 602 passed, 1 failed, 1 skipped, 6 subtests; root loopback CANVAS_BASE_URL mismatched inherited standard-origin pagination continuation. Explicitly unsetting only that override produced the accepted suite without source or assertion changes.",
  "First publication-builder code-mode submission had a JavaScript nested-template SyntaxError before any native tool execution or file write; corrected serialization retained this record."
 ],
 "reconstruction":"All nine owned files from each of d95, 33e, bc1 and 67a are archived with native commit text. Exact parent blobs remain at immutable public Git commits 55fe and 79a, with full source manifests archived. The reproducible 79a archive bytes are not duplicated; immutable URL, SHA256, full Git leaf validation and fetch logs are retained.",
 "limits":"Native Python 3.14.4, actual MCP stdio and synthetic loopback process HTTP; no school/account activation, user profile, browser broker, deployment or live submission changes. Initial failed baseline attempted TLS to an inherited test host using only a synthetic token; it is not described as wholly offline."
}
write_json(OUT/"qualification.json",qualification)
readme="""# Self-submission history — author qualification

Accepted native product tree: {tree}. Public parent: {parent}. The nine scoped source, test and documentation paths preserve all 703 unrelated current-parent leaves. Publication must parent the actual public commit; native capture commits establish local byte identity only.

## Result

The current inherited and new suite passed **603 tests, with 1 skipped and 6 passing subtests**. Configured Ruff and the actual registered MCP catalog passed on the same unchanged source. The separately authored independent receiver passed **9 groups and 465 assertions**, covering API values, real CLI processes over synthetic loopback HTTP and actual MCP stdio.

The feature exposes CanvasAPI.submission_history, the submission-history CLI command and canvas_submission_history MCP tool. It performs two read-only GETs for assignment context and the caller's self submission, requesting returned history and comments without read_status. Current fields, raw historical records and top-level comments remain separate. Returned empty history is distinct from omitted or null history. It does not sort, deduplicate, infer attempts or join current grades/comments to old attempts. HTML, URLs and file metadata remain data. Positive ASCII decimal identifiers are normalized before any request, without an artificial magnitude limit.

## Failures and corrections

The original baseline runner supplied a global synthetic API token. Six inherited broker tests selected PAT behavior and stopped on TLS verification against their test host. No successful remote HTTP response occurred. Removing only the global token yielded the accepted 414-test baseline; the raw 408-pass, 6-failure run is preserved.

Initial source d95 failed actual CLI receiving because inherited HTTPX INFO logging contaminated the new command's machine-readable stderr. Only the new command now temporarily raises that logger's effective threshold and restores it on every path. Maintained process tests corrected their inspection of MCP wire annotation aliases. The independent receiver then passed all nine groups. The maintained suite still found that the MCP SDK hid an anticipated validation message. Only the new MCP tool now translates anticipated ValueError into the SDK's explicit ToolError, retaining error status. Final source bc1 passed all 481 tests on the original parent and the independent affected MCP replay.

The first current-parent suite passed 602 tests but rejected one inherited pagination continuation. The root runner forced a loopback Canvas origin while that fixture returns the standard Canvas origin. The guard correctly refused it. Explicitly unsetting only that override produced the accepted run. Global credentials remain empty; individual process fixtures own their synthetic token and loopback origin. No source, inherited assertion or expected value changed. Both runs are archived.

## Evidence

qualification.json binds source, result, scope and independent packet hashes. archive-manifest.json names every byte-verified author-evidence.tar.gz member. The archive retains complete raw results, original negative runs, drivers, contracts, capture/composition records, full leaf manifests and all nine owned files from each of four candidate revisions.

The sibling independent directory retains the original frozen receiver, fixture, contract, original failures, corrected complete receiving and anticipated-error MCP replay. The sibling independent-current-79a directory retains unchanged current-parent receiving and source-composition review.

Unchanged parent source is durable at public commits 55fe1e0a3c4ad85e1065f295e49d44722c3be32b and {parent}. Full archived manifests bind each leaf. The reproducible public GitHub archive is identified by immutable URL, SHA256 and full leaf verification rather than duplicated.

The final native run used Python 3.14.4, httpx 0.28.1, MCP 2.3.0, pytest 9.1.1 and Ruff 0.16.10. Hosted checks and actual public integration are separate gates. No school-account, browser-session, deployment or live Canvas behavior is claimed.
""".format(parent=manifest["public_parent"],tree=manifest["native_tree"])
(OUT/"README.md").write_text(readme)
entries=[]
for p in manifest["changed_paths"]:
    b=(source/p).read_bytes();entries.append({**meta(p,b),"native":str(source/p),"encoding":"utf-8","content":b.decode()})
for p in sorted(OUT.iterdir()):
    b=p.read_bytes();binary=p.suffix==".gz"
    entries.append({**meta(PREFIX+"/author/"+p.name,b),"native":str(p),"encoding":"base64" if binary else "utf-8",**({} if binary else {"content":b.decode()})})
for e in receiver_entries:entries.append({**e,**({} if e["encoding"]=="base64" else {"content":pathlib.Path(e["native"]).read_text()})})
assert len(entries)==25 and len({e["path"] for e in entries})==25
transports=[]
for e in entries:
    if e["encoding"]=="base64":
        encoded=base64.b64encode(pathlib.Path(e["native"]).read_bytes()).decode()
        p=R/("publication-"+e["git_blob"]+".base64")
        p.write_text("\n".join(encoded[i:i+4096] for i in range(0,len(encoded),4096))+"\n")
        transports.append({"path":e["path"],"native":str(p),"characters":len(encoded),"lines":(len(encoded)+4095)//4096,"git_blob":e["git_blob"]})
payload={"schema":"canvaspilot.submission-history.publication.v1","parent":manifest["public_parent"],"parent_tree":manifest["public_parent_tree"],"native_source_head":manifest["native_head"],"native_source_tree":manifest["native_tree"],"file_count":len(entries),"total_bytes":sum(e["bytes"] for e in entries),"entries":entries,"binary_transports":transports}
write_json(R/"publication-payload.json",payload)
print(json.dumps({"accepted":True,"author_archive":archive_meta,"archive_members":len(members),"publication_paths":len(entries),"publication_bytes":payload["total_bytes"],"payload":meta("publication-payload.json",(R/"publication-payload.json").read_bytes()),"transports":transports,"current_suite":qualification["current_native_gate"]},indent=2))
