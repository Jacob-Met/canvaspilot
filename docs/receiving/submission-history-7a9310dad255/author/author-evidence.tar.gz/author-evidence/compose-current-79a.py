import hashlib, json, os, shutil, subprocess, tarfile, time
from pathlib import Path

root = Path("/tmp/hamon-7a9310dad255-canvas-history")
input_data = json.loads((root / "current-79a-public-input.json").read_text())
current_root = root / "current-79a"
current_root.mkdir()
baseline = current_root / "baseline"
baseline.mkdir()
candidate = current_root / "candidate"
expected = {row["path"]: row for row in input_data["leaves"]}
receipt = {"started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "public_head": input_data["public_head"], "public_tree": input_data["public_tree"], "commands": []}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def run(args, cwd, name, data=None):
    result = subprocess.run(args, cwd=cwd, input=data, capture_output=True, timeout=60, check=False)
    (current_root / (name + ".stdout.log")).write_bytes(result.stdout)
    (current_root / (name + ".stderr.log")).write_bytes(result.stderr)
    receipt["commands"].append({"name": name, "command": args, "cwd": str(cwd), "exit": result.returncode, "stdout_sha256": digest(result.stdout), "stderr_sha256": digest(result.stderr)})
    if result.returncode:
        (current_root / "failed-composition-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        raise RuntimeError(name + ": " + result.stderr.decode(errors="replace"))
    return result.stdout

with tarfile.open(root / "current-79a-github-source.tar.gz", "r:gz") as archive:
    seen = set()
    for item in archive.getmembers():
        if item.isdir():
            continue
        assert item.isfile(), item.name
        prefix = "canvaspilot-" + input_data["public_head"] + "/"
        assert item.name.startswith(prefix), item.name
        name = item.name[len(prefix):]
        assert name in expected and name not in seen, name
        assert ".." not in Path(name).parts and not name.startswith("/"), name
        row = expected[name]
        body = archive.extractfile(item).read()
        assert len(body) == row["size"] and git_blob(body) == row["sha"], name
        output = baseline / name
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("xb") as stream:
            stream.write(body)
        assert row["mode"] in ("100644", "100755"), name
        os.chmod(output, 0o755 if row["mode"] == "100755" else 0o644)
        seen.add(name)
assert seen == set(expected), sorted(set(expected) - seen)
run(["git", "init", "-b", "capture/current-main"], baseline, "init")
run(["git", "add", "-f", "--all"], baseline, "capture-add")
tree = run(["git", "write-tree"], baseline, "capture-tree").decode().strip()
assert tree == input_data["public_tree"], (tree, input_data["public_tree"])
identity = ["git", "-c", "user.name=HAMON estate-7a9310dad255", "-c", "user.email=hamon-7a9310dad255@users.noreply.github.com", "-c", "commit.gpgsign=false"]
run(identity + ["commit", "-m", "Capture exact published Canvas main79a source"], baseline, "capture-commit")
capture_head = run(["git", "rev-parse", "HEAD"], baseline, "capture-head").decode().strip()
run(["git", "clone", "--no-hardlinks", str(baseline), str(candidate)], current_root, "clone-owned-source")
run(["git", "switch", "-c", "product/submission-history-current-79a"], candidate, "candidate-branch")
author = json.loads((root / "candidate-final-source-manifest.json").read_text())
allowed = author["changed_paths"]
patch = run(["git", "diff", "--binary", "eabf2296c3bb0e6195d61f8d173d297012187a94", author["native_head"], "--"] + allowed, root / "candidate", "original-feature-diff")
(current_root / "original-feature.diff").write_bytes(patch)
# Original preimages permit Git's ordinary three-way application without borrowing an owner's repository.
for index, name in enumerate(allowed):
    original = root / "baseline" / name
    if original.exists():
        run(["git", "hash-object", "-w", "--stdin"], candidate, "preimage-" + str(index), original.read_bytes())
run(["git", "apply", "--3way", "--index", str(current_root / "original-feature.diff")], candidate, "apply-feature")
changed = run(["git", "diff", "--cached", "--name-only"], candidate, "changed-paths").decode().splitlines()
assert sorted(changed) == sorted(allowed), changed
run(["git", "diff", "--cached", "--check"], candidate, "diff-check")
diff = run(["git", "diff", "--cached", "--binary"], candidate, "current-feature-diff")
(current_root / "composed-feature.diff").write_bytes(diff)
run(identity + ["commit", "-m", "Compose self-submission history with current pagination and calendar source"], candidate, "candidate-commit")
stage = run(["git", "ls-files", "--stage", "-z"], candidate, "source-list")
files = []
for row in stage.split(b"\0"):
    if not row:
        continue
    metadata, raw_name = row.split(b"\t", 1)
    mode, oid, _ = metadata.decode().split()
    name = raw_name.decode()
    body = (candidate / name).read_bytes()
    assert git_blob(body) == oid, name
    if name not in allowed:
        assert name in expected and oid == expected[name]["sha"] and mode == expected[name]["mode"], name
    files.append({"path": name, "mode": mode, "git_blob": oid, "bytes": len(body), "sha256": digest(body)})
assert len(files) == 712, len(files)
source_by_path = {row["path"]: row for row in files}
for row in author["files"]:
    if row["path"] in allowed and row["path"] not in ("README.md", "src/canvaspilot/cli.py"):
        assert source_by_path[row["path"]]["git_blob"] == row["git_blob"], row["path"]
manifest = {"at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "public_parent": input_data["public_head"], "public_parent_tree": input_data["public_tree"], "native_capture_head": capture_head, "native_head": run(["git", "rev-parse", "HEAD"], candidate, "candidate-head").decode().strip(), "native_tree": run(["git", "rev-parse", "HEAD^{tree}"], candidate, "candidate-tree").decode().strip(), "original_qualified_author_head": author["native_head"], "changed_paths": changed, "unrelated_parent_leaves_preserved": len(expected) - 5, "files": files, "ancestry_boundary": "The native capture commit has exactly the public79a tree. GitHub publication must use the actual public79a commit as its parent, not this native capture commit.", "composition": "Ordinary three-way apply of the exact already-qualified55fe-to-bc1 feature patch. Only current README and CLI differ from the authored candidate; the landed calendar exception handling and pagination documentation remain preserved."}
(current_root / "candidate-source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
receipt.update({"complete": True, "baseline_files": len(expected), "baseline_tree": tree, "candidate_files": len(files), "candidate_head": manifest["native_head"], "candidate_tree": manifest["native_tree"], "manifest_sha256": digest((current_root / "candidate-source-manifest.json").read_bytes())})
(current_root / "composition-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({key: receipt[key] for key in ("complete", "baseline_files", "baseline_tree", "candidate_files", "candidate_head", "candidate_tree", "manifest_sha256")}, indent=2))
