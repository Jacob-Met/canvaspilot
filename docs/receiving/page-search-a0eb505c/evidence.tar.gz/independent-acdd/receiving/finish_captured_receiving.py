from pathlib import Path
import ast,hashlib,json,stat,time,traceback
R=Path('/home/jacob/canvaspilot-page-search-independent-20261008-a0eb')
P=Path('/home/jacob/canvaspilot-page-search-20261008-a0eb');S=P/'receiving-acdd8c1b'
OUT=R/'captured-receiving-completion';OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=R/'gate-01/result.json'
assert sha(raw.read_bytes())=='cc940b827d8ef701cc0399c9d291e6f70cc0ff90c65194450a8673f37cb1fb15'
g=json.loads(raw.read_bytes());c=json.loads((R/'contract-before-candidate.json').read_bytes())
checks=[]
def ck(condition,label):
 checks.append({'label':label,'passed':bool(condition)})
 if not condition:raise AssertionError(label)
result={'schema':1,'status':'running','execution_kind':'Corrected receiver assertions over exact original actual-client observations; no new HTTP execution','raw_gate_sha256':sha(raw.read_bytes()),'created_at':time.time(),'cases':[]}
try:
 client=(S/'src/canvaspilot/client.py').read_bytes()
 ck(sha(client)=='d3473b7805908c15b276689abff9dd0dbd8d428e8691d557a26a5b2285444797','unchanged native client source')
 text=client.decode();node=next(n for n in ast.walk(ast.parse(text)) if isinstance(n,ast.FunctionDef) and n.name=='_with_per_page');snippet=ast.get_source_segment(text,node)
 ck('out.setdefault("per_page", 50)' in snippet,'actual native default is50')
 (OUT/'inherited-page-size-source.txt').write_text(snippet+'\n')
 correction={'schema':1,'classification':'Receiver expectation correction only','original_assertion':'per_page100','correct_native_expectation':'per_page50','basis':'Unchanged client _with_per_page source and actual captured requests; producer contract promised preservation, not100.','original_gate_status':'exit1; both cases stopped at the same unsupported receiver assertion after capturing their complete actual outputs.','unchanged_contract':'Ordered duplicates, Unicode fields, unavailable-body coverage, whole-output refusal, close/logger restoration','new_execution':False,'candidate_source_changed':False,'raw_result_sha256':sha(raw.read_bytes())}
 (OUT/'expectation-correction.json').write_text(json.dumps(correction,indent=2)+'\n')
 ck(g['isolation']['uid']==1000 and g['isolation']['namespace']!=g['isolation']['launcher_namespace'],'actual execution nonroot private namespace')
 ck(g['isolation']['interfaces']==[[1,'lo']],'actual execution had only loopback')
 for case in g['cases']:
  label=case['name'];req=case['requests'];failure=case['late_failure']
  ck(case['status']=='failed' and 'first query exact native include/per_page' in case['traceback'],label+' original failure retained exactly')
  ck(len(req)==2,label+' exactly two actual collection requests')
  ck(req[0]['query']=={'include[]':['body'],'per_page':['50']},label+' exact inherited initial parameters')
  ck(req[1]['query']=={'page':['two'],'include[]':['body']},label+' continuation query not rewritten')
  ck(all(x['method']=='GET' and x['path']=='/api/v1/courses/42/pages' and x['fictional_authorization_correct'] for x in req),label+' only explicit fictional collection reads')
  ck(case['close_observation']==[{'transport_existed':True,'transport_closed':True,'native_reference_cleared':True}],label+' native client closed once')
  ck(case['logger_level_after']==17 and case['http_log']=='',label+' HTTP logger suppressed and exact prior level restored')
  ck(not (R/'gate-01'/(label+'-never-created-profile')).exists(),label+' private nonexistent profile untouched')
  if failure:
   ck(case['exit_code']==1,label+' structured nonzero failure')
   ck(case['stdout']=='',label+' no partial stdout from matching first page')
   e=json.loads(case['stderr'])
   ck(e['ok'] is False and e['error']=='HTTPStatusError' and '503' in e['message'],label+' real later503 reported')
   ck('matches' not in e,label+' no invented partial report')
  else:
   ck(case['exit_code']==0 and case['stderr']=='',label+' clean actual CLI success')
   report=json.loads(case['stdout']);matches=report['matches'];un=report['unavailable_bodies']
   ck(report['course_id']=='42' and report['query']==c['query'] and report['match_mode']=='literal_casefold',label+' exact course/query/mode')
   ck(report['pages_returned']==6 and report['pages_matched']==4 and report['titles_searched']==6 and report['bodies_searched']==3,label+' exact coverage counts with empty body searched')
   ck([m['position'] for m in matches]==[1,2,3,5],label+' stable matching source order')
   ck([m['matched_fields'] for m in matches]==[['title'],['body_text'],['title'],['title']],label+' separate casefold title/body matching')
   ck([m['body_text'] for m in matches]==['No hit here','Die Straße führt.',None,None],label+' exact cleaned available text')
   ck([m['page'] for m in matches]==[c['pages'][i-1] for i in [1,2,3,5]],label+' exact complete original matching pages')
   ck(matches[0]['page']['page_id']==matches[1]['page']['page_id']==17 and matches[0]['page']!=matches[1]['page'],label+' repeated page identity retained twice')
   ck([(u['position'],u['reason']) for u in un]==[(3,'locked_for_user'),(4,'body_not_supplied'),(5,'body_null')],label+' ordered explicit unavailable reasons')
   ck([u['page'] for u in un]==[c['pages'][i-1] for i in [3,4,5]],label+' exact unavailable page objects retained')
   ck('not a claim' in report['coverage'],label+' limited coverage expressly disclosed')
  result['cases'].append({'name':label,'status':'passed_against_captured_actual_observation','new_http_calls':0})
 ck((R/'gate-01/source-binding-before.json').read_bytes()==(R/'gate-01/source-binding-after.json').read_bytes(),'forty source files exact before/after actual execution')
 ck(all(x['passed'] for x in g['checks'] if 'source ' in x['label'] or 'freeze' in x['label']),'original source-byte/blob/mode assertions all passed')
 freeze=json.loads((P/'evidence/receiving-acdd8c1b-source-freeze.json').read_bytes())
 for name,e in freeze['source'].items():
  b=(S/name).read_bytes()
  if sha(b)!=e['sha256'] or stat.S_IMODE((S/name).stat().st_mode)!=int(e['mode'][-3:],8):raise AssertionError('source drift '+name)
 own_parser=(P/'evidence/own-cli-parser.txt').read_bytes();own_dispatch=(P/'evidence/own-cli-dispatch.txt').read_bytes()
 cli=(S/'src/canvaspilot/cli.py').read_bytes();parent_cli=(P/'evidence/current-parent-cli.py').read_bytes()
 ck(cli.count(own_parser)==1 and cli.count(own_dispatch)==1,'own CLI additions each occur once')
 ck(cli.replace(own_parser,b'',1).replace(own_dispatch,b'',1)==parent_cli,'remove only own spans recovers current parent CLI')
 ck(hashlib.sha1(('blob '+str(len(parent_cli))+'\0').encode()+parent_cli).hexdigest()=='e33ef5f6656ae0995b99a670f50fdef4a593d01e','current parent CLI Git blob exact')
 readme=(S/'README.md').read_bytes();parent_readme=(P/'evidence/current-parent-README.md').read_bytes()
 ck(readme.startswith(parent_readme),'complete current parent README retained as exact prefix')
 ck(hashlib.sha1(('blob '+str(len(parent_readme))+'\0').encode()+parent_readme).hexdigest()=='b29a86296e77f79103d5e23e160d7b03bd02222f','current parent README Git blob exact')
 result['status']='passed';result['source_files']=40
except BaseException:
 result['status']='failed';result['traceback']=traceback.format_exc()
result['checks']=checks;result['checks_passed']=sum(x['passed'] for x in checks);result['checks_total']=len(checks);result['new_http_calls']=0
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'cases':len(result['cases']),'checks_passed':result['checks_passed'],'checks_total':result['checks_total'],'new_http_calls':0,'result_sha256':sha((OUT/'result.json').read_bytes())}),flush=True)
raise SystemExit(0 if result['status']=='passed' else 1)
