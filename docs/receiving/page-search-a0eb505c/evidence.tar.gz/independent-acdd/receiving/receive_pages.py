from __future__ import annotations
import contextlib,hashlib,io,json,logging,os,socket,stat,sys,threading,time,traceback
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlsplit,parse_qs
ROOT=Path('/home/jacob/canvaspilot-page-search-independent-20261008-a0eb')
PRODUCER=Path('/home/jacob/canvaspilot-page-search-20261008-a0eb')
SOURCE=PRODUCER/'receiving-acdd8c1b'
FREEZE=PRODUCER/'evidence/receiving-acdd8c1b-source-freeze.json'
RUN=ROOT/'gate-01';RUN.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
C=json.loads((ROOT/'contract-before-candidate.json').read_bytes())
checks=[]
def check(value,label):
 checks.append({'label':label,'passed':bool(value)})
 if not value:raise AssertionError(label)
def binding():
 f=json.loads(FREEZE.read_bytes())
 check(sha(FREEZE.read_bytes())==C['producer_freeze_sha256'],'immutable producer freeze')
 out={}
 for name,e in f['source'].items():
  p=SOURCE/name;b=p.read_bytes()
  check(sha(b)==e['sha256'] and len(b)==e['bytes'],'source SHA '+name)
  check(hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()==e['git_blob'],'source raw Git blob '+name)
  check(format(stat.S_IMODE(p.stat().st_mode),'o')==e['mode'][-3:],'source mode '+name)
  out[name]={'sha256':sha(b),'blob':e['git_blob'],'bytes':len(b),'mode':e['mode']}
 return out
def audit(event,args):
 if event=='socket.connect':
  target=args[1]
  if isinstance(target,tuple) and target[0]!='127.0.0.1':raise AssertionError('nonfixture connection refused')
 if event=='socket.bind':
  target=args[1]
  if isinstance(target,tuple) and target[0]!='127.0.0.1':raise AssertionError('nonfixture bind refused')
sys.addaudithook(audit)
result={'schema':1,'source_freeze_sha256':C['producer_freeze_sha256'],'contract_sha256':sha((ROOT/'contract-before-candidate.json').read_bytes()),'started_at':time.time(),'cases':[],'status':'running'}
try:
 check(os.getuid()==1000,'nonroot fixture UID')
 ns=os.readlink('/proc/self/ns/net')
 check(ns!=sys.argv[1],'private namespace differs from launcher')
 check(socket.if_nameindex()==[(1,'lo')],'only loopback in process namespace')
 result['isolation']={'uid':os.getuid(),'namespace':ns,'launcher_namespace':sys.argv[1],'interfaces':socket.if_nameindex()}
 before=binding();(RUN/'source-binding-before.json').write_text(json.dumps(before,indent=2)+'\n')
 sys.path.insert(0,str(SOURCE/'src'))
 from canvaspilot import cli
 from canvaspilot.client import CanvasClient
 import httpx
 import importlib.metadata
 result['runtime']={'python':sys.version.split()[0],'httpx':httpx.__version__,'pydantic':importlib.metadata.version('pydantic'),'python_executable':sys.executable}
 (RUN/'semantic-output-mapping.json').write_text(json.dumps({'contract_body_field':'body','public_matched_fields_token':'body_text','meaning':'Same supplied HTML body searched after unchanged strip_html; terminology mapped before execution','new_product_assumption':False},indent=2)+'\n')
 pages=C['pages'];page1=pages[:1];page2=pages[1:];original=json.dumps(pages,sort_keys=True,ensure_ascii=False)
 for label,late_failure in [('duplicates_and_unavailable',False),('later_page_refusal',True)]:
  case={'name':label,'late_failure':late_failure};requests=[];closes=[];out=io.StringIO();err=io.StringIO();logs=io.StringIO();profile=RUN/(label+'-never-created-profile')
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_GET(self):
    u=urlsplit(self.path);q=parse_qs(u.query)
    entry={'method':'GET','path':u.path,'query':q,'fictional_authorization_correct':self.headers.get('Authorization')=='Bearer fictional-local-fixture'}
    requests.append(entry)
    if u.path!='/api/v1/courses/42/pages':
     self.send_response(404);self.end_headers();return
    second=q.get('page')==['two']
    if second and late_failure:
     data=json.dumps({'message':'private fixture second page unavailable'}).encode();status=503
    else:
     data=json.dumps(page2 if second else page1,ensure_ascii=False).encode();status=200
    self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)))
    if not second:self.send_header('Link','<http://127.0.0.1:'+str(self.server.server_port)+'/api/v1/courses/42/pages?page=two&include%5B%5D=body>; rel="next"')
    self.end_headers();self.wfile.write(data)
  server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  old_close=CanvasClient.close;http_log=logging.getLogger('httpx');old_level=http_log.level;handler=logging.StreamHandler(logs);http_log.addHandler(handler);http_log.setLevel(17)
  def observed_close(self):
   transport=self._http
   old_close(self)
   closes.append({'transport_existed':transport is not None,'transport_closed':transport.is_closed if transport is not None else None,'native_reference_cleared':self._http is None})
  CanvasClient.close=observed_close
  started=time.time()
  try:
   check(not profile.exists(),label+' profile initially absent')
   code=0
   with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
    try:cli.main(['find-pages','42','--text',C['query'],'--base-url','http://127.0.0.1:'+str(server.server_port),'--token','fictional-local-fixture','--profile',str(profile)])
    except SystemExit as ex:code=ex.code
   case.update({'exit_code':code,'stdout':out.getvalue(),'stderr':err.getvalue(),'requests':requests,'close_observation':closes,'logger_level_after':http_log.level,'http_log':logs.getvalue()})
   check(len(requests)==2,label+' exactly two collection requests')
   check(requests[0]['query']=={'include[]':['body'],'per_page':['100']},label+' first query exact native include/per_page')
   check(requests[1]['query']=={'page':['two'],'include[]':['body']},label+' opaque second query preserved without reapplying filters')
   check(all(r['fictional_authorization_correct'] for r in requests),label+' explicit fictional auth only')
   check(len(closes)==1 and closes[0]=={'transport_existed':True,'transport_closed':True,'native_reference_cleared':True},label+' actual native HTTP client closed once')
   check(http_log.level==17,label+' previous logger level restored')
   check(logs.getvalue()=='',label+' no HTTP log partial output')
   check(not profile.exists(),label+' supplied nonexistent profile untouched')
   if late_failure:
    check(code==1,label+' nonzero structured failure')
    check(out.getvalue()=='',label+' stdout wholly empty despite first page match')
    failure=json.loads(err.getvalue())
    check(failure['ok'] is False and failure['error']=='HTTPStatusError',label+' inherited HTTP error reported')
    check('503' in failure['message'] and 'matches' not in failure,label+' complete failure rather than partial report')
   else:
    check(code==0 and err.getvalue()=='',label+' successful clean output')
    report=json.loads(out.getvalue());case['report']=report
    check(report['course_id']=='42' and report['query']==C['query'],label+' original search identity')
    check(report['match_mode']=='literal_casefold',label+' explicit literal casefold mode')
    check(report['pages_returned']==6 and report['pages_matched']==4 and report['titles_searched']==6 and report['bodies_searched']==3,label+' exact coverage counts')
    ms=report['matches'];check([m['position'] for m in ms]==[1,2,3,5],label+' matching source order including duplicates')
    check([m['matched_fields'] for m in ms]==[['title'],['body_text'],['title'],['title']],label+' title and body searched separately')
    check([m['body_text'] for m in ms]==['No hit here','Die Straße führt.',None,None],label+' exact text and unavailable values')
    check([m['page'] for m in ms]==[pages[i-1] for i in [1,2,3,5]],label+' original complete page objects retained')
    check(ms[0]['page']['page_id']==ms[1]['page']['page_id']==17 and ms[0]['page']!=ms[1]['page'],label+' repeated identity not coalesced')
    un=report['unavailable_bodies']
    check([(u['position'],u['reason']) for u in un]==[(3,'locked_for_user'),(4,'body_not_supplied'),(5,'body_null')],label+' exact ordered unavailable coverage')
    check([u['page'] for u in un]==[pages[i-1] for i in [3,4,5]],label+' unavailable original pages retained')
    check('not a claim' in report['coverage'],label+' coverage states nonexhaustive meaning')
   check(json.dumps(pages,sort_keys=True,ensure_ascii=False)==original,label+' fixture source objects unchanged')
   case['status']='passed'
  except BaseException:
   case['status']='failed';case['traceback']=traceback.format_exc();case.update({'stdout':out.getvalue(),'stderr':err.getvalue(),'requests':requests,'close_observation':closes})
  finally:
   CanvasClient.close=old_close;http_log.removeHandler(handler);http_log.setLevel(old_level);server.shutdown();server.server_close();thread.join(2)
   case['seconds']=time.time()-started
  (RUN/(label+'.json')).write_text(json.dumps(case,indent=2,ensure_ascii=False)+'\n');result['cases'].append(case)
 after=binding();check(after==before,'all forty source bytes unchanged after receiving')
 (RUN/'source-binding-after.json').write_text(json.dumps(after,indent=2)+'\n')
 result['status']='passed' if all(c['status']=='passed' for c in result['cases']) else 'failed'
except BaseException:
 result['status']='failed';result['traceback']=traceback.format_exc()
finally:
 result['finished_at']=time.time();result['checks']=checks;result['checks_passed']=sum(x['passed'] for x in checks);result['checks_total']=len(checks)
 (RUN/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'status':result['status'],'cases':[(c['name'],c['status']) for c in result['cases']],'checks_passed':result['checks_passed'],'checks_total':result['checks_total'],'result_sha256':sha((RUN/'result.json').read_bytes())}),flush=True)
sys.exit(0 if result['status']=='passed' else 1)
