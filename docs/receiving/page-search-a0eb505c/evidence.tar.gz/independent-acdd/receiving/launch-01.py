from pathlib import Path
import os,json,subprocess,hashlib,time
R=Path('/home/jacob/canvaspilot-page-search-independent-20261008-a0eb')
assert not (R/'invocation-01.json').exists()
script=R/'receive_pages.py';python='/home/jacob/canvaspilot-todo-847ff4f12343/venv/bin/python'
host=os.readlink('/proc/self/ns/net')
code="import os,subprocess,sys;subprocess.run(['ip','link','set','lo','up'],check=True);os.execvp('runuser',['runuser','-u','jacob','--',sys.argv[1],'-B',sys.argv[2],sys.argv[3]])"
env=dict(os.environ);env.update({'PYTHONDONTWRITEBYTECODE':'1','CANVAS_API_TOKEN':'','CANVAS_BASE_URL':'https://canvas.invalid','HTTP_PROXY':'','HTTPS_PROXY':'','ALL_PROXY':'','NO_PROXY':'127.0.0.1,localhost'})
start=time.time()
with (R/'command-01.log').open('w') as log:
 p=subprocess.run(['unshare','--net','python3','-c',code,python,str(script),host],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
result={'schema':1,'exit_code':p.returncode,'seconds':time.time()-start,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'python':python,'host_network_namespace':host,'private_network':'unshare --net, loopback up inside only','run_uid':1000,'explicit_canvas_inputs':'fictional token and private nonexistent profile at actual entry function; source/client behavior unchanged','environment_values_dumped':False,'log_sha256':hashlib.sha256((R/'command-01.log').read_bytes()).hexdigest()}
(R/'invocation-01.json').write_text(json.dumps(result,indent=2)+'\n')
for name in ['command-01.log','invocation-01.json']:os.chown(R/name,1000,1000)
print(json.dumps(result),flush=True)
