## Learner outcome and bounded ownership

External worker `chatgpt-a0eb505c4971/mac_production`, under Jacob’s standing estate mandate, owns:

```text
canvaspilot find-pages 42 --text "field journal"
```

A learner can currently list page metadata or export explicitly chosen pages, but cannot locate a phrase across returned course-page bodies from the CLI. The original native witness at main `e46a90ff00f80a128baf842587f08df5862318aa` / tree `5fef10b4fac997cd1049de24447dce02bfa49ec3` proves ordinary help succeeds, `find-pages` exits 2, and a body-only phrase omitted by `list_pages` remains available through the unchanged page reader/include-body collection.

Native claim **4881 / cev_5050a1234efc40ee89a3b135** preceded source edits. Frozen contract SHA-256: `451ea076fb645871eb95ac19e8f45e22c02b5239c962b417e7160960257bfdee`. Original witness: `28eb676361d37be536cec406e54326e8da6066f2f04b4b0dd1d4c3edbb57c4b7`. Private source/evidence: `/home/jacob/canvaspilot-page-search-20261008-a0eb`.

## Resulting behavior

- Admit one positive decimal course ID and a non-whitespace UTF-8 query of at most 512 bytes before client/profile setup. Preserve meaningful query whitespace.
- Search a literal Unicode-casefold substring separately in supplied titles and complete body text cleaned by the existing reader. No regex, ranking, accent folding or cross-field concatenation.
- Use the unchanged paginator once for the course Pages GET with `include[]=body`; no new transport, per-page fallback, server title-only filter or embedded-content request.
- Preserve returned order, duplicate identities, unknown fields and original matching page objects; expose matching fields and returned positions.
- Report missing, null and locked bodies explicitly as unavailable. Supplied empty text is searched; titles may match independently. Block-editor attributes and attachments are not searched. Counts describe returned pages/available text, and empty matches do not imply that unavailable content lacks the phrase.
- A later request/pagination failure or malformed row refuses the complete report without partial successful stdout. Decoded input is bounded to 1,000 rows/8 MiB after the existing client decodes it. Keep the existing client-close path and HTTPX logger state.
- No saved file, course/read/completion/submission/account mutation or live provider action.

Primary contract: [Canvas Pages API](https://developerdocs.instructure.com/services/canvas/resources/pages), read 2026-10-08, including its optional body include, title-only server search and block-editor distinction.

## Source fence, current composition and receiving

Only new `src/canvaspilot/page_search.py`; additive `find-pages` parser/dispatch in `cli.py`; dedicated `tests/test_page_search.py` and `tests/test_page_search_cli.py`; `docs/page-search.md`; one README pointer and unique receiving evidence. Existing API/client/broker/MCP/bundle/page-export modules, other command bodies, dependencies and workflows stay unchanged.

Fresh project issues/searches, 18 Canvas Conscience records and 20 matching external coordination records showed no page-search owner. Prior page-packet ownership is released at native 4679. Preserve all current announcement, enrollment, todo, syllabus, inbox/discussion export and explicit security/CI holds. This is external source custody, not a resident goal or lease.

The initial native scope is qualified by 19 authored helper/actual-loopback-CLI cases across a preserved 18-pass run and one focused completion. Original per-page/envelope receiver mistakes, argument-message correction, lint findings and controller-cache/path setup failures remain separately recorded. No live school session, account, dependency install or broad clone was used.

Current receiving composition is pinned to `acdd8c1be09300dc4daf455d7f010a69bf7fede5` / tree `c4e4fea18701452b9ab16b1def71e3c3551ea86e`, retaining the merged announcement-search and enrollment work. Removing only our two CLI insertions recovers the exact current CLI, and the current README is an exact prefix. The 40-file materialized source freeze is `9a93aa77708ca7c8ae8cbf18653e84924a009558bbff6db410b4f820336a9cfe`; this partial materialization is not called the full canonical tree.

Independent review, current-parent receiving and maintained hosted CI precede normal source integration. No public feature branch, merge, installation or deployment is claimed by this issue.
