from pathlib import Path
import json,hashlib,shutil,datetime,tarfile,gzip,io,os
r=Path("/home/jacob/canvaspilot-page-search-20261008-a0eb");e=r/"evidence"
dst=Path("/var/lib/hamon/custody/canvaspilot-page-search-20261008-a0eb/qualified-56a72a2e")
assert not dst.exists()
packet=dst/"packet";public=dst/"publication";packet.mkdir(parents=True);public.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def cp(s,d,expected=None):
 b=Path(s).read_bytes()
 if expected:assert sha(b)==expected,(s,"hash")
 d.parent.mkdir(parents=True,exist_ok=True);assert not d.exists();d.write_bytes(b);assert d.read_bytes()==b
def j(p):return json.loads(Path(p).read_text())
base=j(e/"baseline-source.json")
for d in base["files"]:cp(r/"baseline"/d["path"],packet/"baseline"/d["path"],d["sha256"])
for label in ("acdd8c1b","56a72a2e"):
 f=j(e/("receiving-"+label+"-source-freeze.json"))
 for p,d in f["source"].items():cp(r/("receiving-"+label)/p,packet/("source-"+label)/p,d["sha256"])
for p in sorted(e.rglob("*")):
 if p.is_file() and not any(x in p.parts for x in ("__pycache__",".ruff_cache",".pytest_cache")):cp(p,packet/"author/evidence"/p.relative_to(e))
for name in ("CONTRACT.json","baseline_witness.py","run_gate01.py","run_gate02.py","run_gate03.py","receive_actual_cli_acdd.py","compose_56a.py","seal_packet_56a.py"):
 cp(r/name,packet/"author/controllers"/name)
ind=Path("/var/lib/hamon/custody/canvas-page-search-independent-20261008-a0eb")
assert sha((ind/"independent-review.json").read_bytes())=="d0f6875bc87b8eae9ed807604ce7c83c2c19c0ac7991a675dde403719b7b0352"
assert sha((ind/"successor-56a72a2e/independent-review.json").read_bytes())=="79701a9d8cecf14497d06ec3bcc0f1230c13990840495bd6a3748e1ae3d4e55e"
for p in sorted(ind.rglob("*")):
 if p.is_file():
  rel=p.relative_to(ind)
  if rel.parts[0]=="successor-56a72a2e":target=packet/"independent-successor"/Path(*rel.parts[1:])
  else:target=packet/"independent-acdd"/rel
  cp(p,target)
files={}
for p in sorted(packet.rglob("*")):
 if p.is_file():files[p.relative_to(packet).as_posix()]={"bytes":p.stat().st_size,"sha256":sha(p.read_bytes()),"mode":"100644"}
manifest={"created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"files":files,"file_count":len(files),"scope":"Complete selected original author and independent source/receiving custody; generated caches and dependencies excluded. Paths are archive-relative."}
manifest_bytes=(json.dumps(manifest,indent=2)+"\n").encode()
(public/"manifest.json").write_bytes(manifest_bytes)
archive=public/"evidence.tar.gz"
with archive.open("xb") as raw:
 with gzip.GzipFile(fileobj=raw,mode="wb",filename="",mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode="w",format=tarfile.PAX_FORMAT) as tf:
   for rel,d in files.items():
    b=(packet/rel).read_bytes();ti=tarfile.TarInfo(rel);ti.size=len(b);ti.mode=0o644;ti.uid=0;ti.gid=0;ti.uname="";ti.gname="";ti.mtime=0
    tf.addfile(ti,io.BytesIO(b))
 raw.flush();os.fsync(raw.fileno())
with tarfile.open(archive,"r:gz") as tf:
 members=tf.getmembers();assert len(members)==len(files)
 for m in members:
  assert m.isfile() and m.name in files and m.mode==0o644
  b=tf.extractfile(m).read();assert sha(b)==files[m.name]["sha256"]
cp(e/"author-qualification.json",public/"qualification.json")
cp(ind/"independent-review.json",public/"independent-review.json")
cp(ind/"successor-56a72a2e/independent-review.json",public/"successor-binding.json")
readme=f"""# Course-page text search receiving

This packet supports [issue92](https://github.com/Jacob-Met/canvaspilot/issues/92) and the six-path find-pages contribution.

The original command could list pages and retrieve bodies, but could not find literal text across page titles and available bodies. The new command returns complete ordered matches with exact page rows and explicit unavailable-body coverage. See the [usage and limits](../../page-search.md).

- [Author qualification](qualification.json) distinguishes the original absence witness, source corrections and all native gates.
- [Independent actual-client receiving](independent-review.json) pins the acdd composition and the actual two fictional HTTP scenarios.
- [Current-parent source binding](successor-binding.json) qualifies the additive syllabus-preserving 56a composition without repeating settled receiving.
- [Full original source and evidence archive](evidence.tar.gz), with [every member checksum](manifest.json).

The archive contains {len(files)} original source, controller, receipt and output files. Its SHA256 is {sha(archive.read_bytes())}. The manifest SHA256 is {sha(manifest_bytes)}. No third-party runtime, generated cache or real account data is included.

The author matrix closes 19 cases across the recorded 18-pass run and the one focused corrected case. Gate02's final controller status was lost during a remote-session outage; its actual JUnit/stdout and later reconciliation are retained rather than represented as a successful full controller. Initial parser/error, inherited per-page, response-envelope, cache-inventory and lint-invocation failures remain visible.

The independent raw run exited 1 on its own inherited per-page expectation. It had already captured both complete actual-client scenarios; 42 assertions then passed over those exact observations with no repeated HTTP. The later source binding preserves that distinction.

Source parent: 56a72a2e2cee5ec04671d12ebe5bc2484afb8026, tree a07c3e941219ff80968e1ff20528a63541bb7400. The product-only prospective tree is 061e78751f9a0eb0b7cd905ceda67bbc81066864; publication adds this separate receipt packet. All 1614 unrelated current-parent leaves remain exact. The 43-file native source snapshot and Git bundles are explicitly partial custody, not claims of canonical ancestry.

Native Python 3.14.4, HTTPX 0.28.1 and existing runtime metadata are hash-bound in the archive. Hosted repository CI and any final merge are separate receiving gates. No live Canvas account, installation or deployment was performed.
"""
(public/"README.md").write_text(readme)
pf={}
for p in sorted(public.iterdir()):
 b=p.read_bytes();pf[p.name]={"bytes":len(b),"sha256":sha(b),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest(),"mode":"100644"}
receipt={"created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"root":str(dst),"archive_members":len(files),"archive_member_bytes":sum(d["bytes"] for d in files.values()),"source_parent":"56a72a2e2cee5ec04671d12ebe5bc2484afb8026","product_only_tree":"061e78751f9a0eb0b7cd905ceda67bbc81066864","source_freeze_sha256":"bc775aec9488d876bd5b3d6353cd0054f4a6397ae580ffff3f8beb5cef27cffa","six_path_patch_sha256":"2b8b48ed186f2431da864e6fe2b1a4eada9990dad7397af06e2b82fcc613373a","publication":pf,"status":"Native packet sealed and byte-verified; GitHub publication/CI/merge pending."}
b=(json.dumps(receipt,indent=2)+"\n").encode();(dst/"publication-packet.json").write_bytes(b)
for p in public.iterdir():
 with p.open("rb") as f:os.fsync(f.fileno())
fd=os.open(dst,os.O_RDONLY);os.fsync(fd);os.close(fd)
print(json.dumps({"receipt":str(dst/"publication-packet.json"),"sha256":sha(b),"archive_members":len(files),"publication":pf}))
