from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from urllib.parse import urlsplit, parse_qs
import os,sys,json,hashlib,subprocess,time,datetime
root=Path("/home/jacob/canvaspilot-page-search-20261008-a0eb")
source=root/"receiving-acdd8c1b"
gate=root/"evidence"/"subprocess-receiving-acdd8c1b"
gate.mkdir(exist_ok=False)
freeze=json.loads((root/"evidence"/"receiving-acdd8c1b-source-freeze.json").read_text())
for path,entry in freeze["source"].items():
 assert hashlib.sha256((source/path).read_bytes()).hexdigest()==entry["sha256"]
rows=[
 {"page_id":91,"url":"field-records","title":"Week 2","body":"<p>Keep a field <em>journal</em> after each observation.</p>","published":True,"unknown":{"zero":0,"flag":False}},
 {"page_id":91,"url":"field-journal-index","title":"FIELD JOURNAL index","body":None,"block_editor_attributes":{"blocks":"not searched"}},
]
requests=[]
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  parsed=urlsplit(self.path);query=parse_qs(parsed.query);requests.append({"method":"GET","path":parsed.path,"query":query})
  if parsed.path!="/api/v1/courses/42/pages":
   self.send_error(404);return
  second="cursor" in query
  data=json.dumps([rows[1] if second else rows[0]],ensure_ascii=False).encode()
  self.send_response(200);self.send_header("Content-Type","application/json");self.send_header("Content-Length",str(len(data)))
  if not second:self.send_header("Link",f'<http://127.0.0.1:{self.server.server_port}/api/v1/courses/42/pages?cursor=next%2Bopaque>; rel="next"')
  self.end_headers();self.wfile.write(data)
server=ThreadingHTTPServer(("127.0.0.1",0),Handler)
thread=Thread(target=server.serve_forever,daemon=True);thread.start()
env=os.environ.copy();env.update(PYTHONPATH=str(source/"src"),PYTHONDONTWRITEBYTECODE="1",CANVAS_API_TOKEN="",CANVAS_BASE_URL="https://canvas.invalid",CANVAS_PROFILE=str(gate/"unused-profile"))
argv=[sys.executable,str(source/"src/canvaspilot/cli.py"),"find-pages","00042","--text","field journal","--base-url",f"http://127.0.0.1:{server.server_port}","--token","fictional-local-fixture","--profile",str(gate/"unused-profile")]
start=time.monotonic()
try:
 result=subprocess.run(argv,cwd=source,env=env,capture_output=True,timeout=90)
finally:
 server.shutdown();thread.join(timeout=5);server.server_close()
seconds=time.monotonic()-start
(gate/"stdout.json").write_bytes(result.stdout);(gate/"stderr.txt").write_bytes(result.stderr)
(gate/"fixture.json").write_text(json.dumps(rows,indent=2)+"\n");(gate/"requests.json").write_text(json.dumps(requests,indent=2)+"\n")
out=json.loads(result.stdout)
checks={
 "actual_child_exit0":result.returncode==0,
 "stderr_empty":not result.stderr,
 "both_returned_rows_match":out["pages_returned"]==out["pages_matched"]==2,
 "body_coverage_explicit":out["bodies_searched"]==1 and len(out["unavailable_bodies"])==1 and out["unavailable_bodies"][0]["reason"]=="body_null",
 "exact_original_rows_duplicate_id_retained":[m["page"] for m in out["matches"]]==rows,
 "field_matching_separate":[m["matched_fields"] for m in out["matches"]]==[["body_text"],["title"]],
 "exact_initial_include_and_opaque_next":requests==[{"method":"GET","path":"/api/v1/courses/42/pages","query":{"include[]":["body"],"per_page":["50"]}},{"method":"GET","path":"/api/v1/courses/42/pages","query":{"cursor":["next+opaque"]}}],
 "profile_absent":not(gate/"unused-profile").exists(),
 "source40_unchanged":all(hashlib.sha256((source/path).read_bytes()).hexdigest()==entry["sha256"] for path,entry in freeze["source"].items()),
}
receipt={"created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"parent":freeze["parent"],"freeze_sha256":hashlib.sha256((root/"evidence"/"receiving-acdd8c1b-source-freeze.json").read_bytes()).hexdigest(),"argv":argv,"exit":result.returncode,"seconds":seconds,"checks":checks,"stdout_sha256":hashlib.sha256(result.stdout).hexdigest(),"fixture_sha256":hashlib.sha256((gate/"fixture.json").read_bytes()).hexdigest(),"network":"Only a private ephemeral127.0.0.1 authored server; no school account or external request.","no_matrix_rerun":True}
(gate/"result.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"checks":checks,"seconds":seconds,"receipt":str(gate/"result.json"),"sha256":hashlib.sha256((gate/"result.json").read_bytes()).hexdigest()}))
assert all(checks.values())
