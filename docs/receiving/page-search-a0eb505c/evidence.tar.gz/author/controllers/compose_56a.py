from pathlib import Path
import json,hashlib,shutil,datetime,difflib,subprocess
r=Path("/home/jacob/canvaspilot-page-search-20261008-a0eb"); e=r/"evidence"
old=r/"receiving-acdd8c1b"; dst=r/"receiving-56a72a2e"; pin=e/"parent-56a72a2e"
assert not dst.exists()
f=json.loads((e/"receiving-acdd8c1b-source-freeze.json").read_text())
for p,d in f["source"].items():
 assert hashlib.sha256((old/p).read_bytes()).hexdigest()==d["sha256"]
leaves={}
for p in sorted(pin.glob("leaves-*.json")):
 for d in json.loads(p.read_text()):assert d["path"] not in leaves;leaves[d["path"]]=d
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def tree(mapping):
 dirs={}
 for path,d in mapping.items():
  node=dirs
  ps=path.split("/")
  for x in ps[:-1]:node=node.setdefault(x,{})
  node[ps[-1]]=(d["mode"],d["sha"])
 def walk(node):
  items=[]
  for k,v in node.items():
   if isinstance(v,dict):mode="40000";sha=walk(v);key=k+"/"
   else:mode,sha=v;key=k
   items.append((key,k,mode,sha))
  b=b"".join(mode.encode()+b" "+k.encode()+b"\0"+bytes.fromhex(sha) for _,k,mode,sha in sorted(items))
  return hashlib.sha1(b"tree "+str(len(b)).encode()+b"\0"+b).hexdigest()
 return walk(dirs)
assert len(leaves)==1616 and tree(leaves)=="a07c3e941219ff80968e1ff20528a63541bb7400"
for p in f["source"]:
 q=dst/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/p,q)
for p in (pin/"inputs").rglob("*"):
 if p.is_file():
  rel=p.relative_to(pin/"inputs").as_posix();b=p.read_bytes()
  assert blob(b)==leaves[rel]["sha"]
  q=dst/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
cli=(dst/"src/canvaspilot/cli.py").read_text()
for name,anchor in (("parser",'    page_export = sub.add_parser(\n'),("dispatch",'        elif args.cmd == "grade-review":\n')):
 span=(e/("own-cli-"+name+".txt")).read_text()
 assert span not in cli and cli.count(anchor)==1
 cli=cli.replace(anchor,span+anchor,1)
inverse=cli
for n in ("parser","dispatch"):inverse=inverse.replace((e/("own-cli-"+n+".txt")).read_text(),"",1)
assert inverse==(pin/"inputs/src/canvaspilot/cli.py").read_text()
(dst/"src/canvaspilot/cli.py").write_text(cli)
oldread=(e/"current-parent-README.md").read_bytes();ours=(old/"README.md").read_bytes()
assert ours.startswith(oldread)
appendix=ours[len(oldread):]
parentread=(pin/"inputs/README.md").read_bytes()
(dst/"README.md").write_bytes(parentread+appendix)
own=["README.md","src/canvaspilot/cli.py","src/canvaspilot/page_search.py","tests/test_page_search.py","tests/test_page_search_cli.py","docs/page-search.md"]
source={}
for p in sorted(dst.rglob("*")):
 if p.is_file():
  b=p.read_bytes();rel=p.relative_to(dst).as_posix()
  source[rel]={"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"blob":blob(b),"mode":"100644"}
for p in f["source"]:
 if p not in ("README.md","src/canvaspilot/cli.py"):assert source[p]["sha256"]==f["source"][p]["sha256"]
current=dict(leaves)
for p in own:current[p]={"path":p,"mode":"100644","sha":source[p]["blob"]}
assert sum(current[p]==d for p,d in leaves.items())==1614
freeze={"created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"parent":"56a72a2e2cee5ec04671d12ebe5bc2484afb8026","parent_tree":tree(leaves),"parent_leaves":len(leaves),"product_only_tree":tree(current),"product_leaves":len(current),"original_receiving_freeze":hashlib.sha256((e/"receiving-acdd8c1b-source-freeze.json").read_bytes()).hexdigest(),"kind":"43-file native partial source composition; complete canonical tree reconstructed separately","own_paths":own,"source":source,"preservation":{"unchanged_prior_materialized_files":38,"exact_new_parent_inputs":3,"cli_remove_two_owned_spans_recovers_current_parent":True,"readme_current_parent_exact_prefix_own_appendix_exact":True,"unrelated_current_parent_leaves_exact":1614},"receiving_policy":"No scoped cases rerun. Exact helper, assertions and command spans retained; syllabus uses disjoint parser/dispatch. Independent successor byte review pending."}
data=(json.dumps(freeze,indent=2)+"\n").encode();(e/"receiving-56a72a2e-source-freeze.json").write_bytes(data)
for rel in ("README.md","src/canvaspilot/cli.py"):
 patch="".join(difflib.unified_diff((old/rel).read_text().splitlines(True),(dst/rel).read_text().splitlines(True),fromfile="acdd/"+rel,tofile="56a/"+rel))
 (e/("successor-56a-"+rel.replace("/","_")+".patch")).write_text(patch)
print(json.dumps({"freeze":str(e/"receiving-56a72a2e-source-freeze.json"),"sha256":hashlib.sha256(data).hexdigest(),"source_files":len(source),"product_tree":freeze["product_only_tree"],"product_leaves":len(current),"cli_sha256":source["src/canvaspilot/cli.py"]["sha256"],"readme_sha256":source["README.md"]["sha256"]}))
