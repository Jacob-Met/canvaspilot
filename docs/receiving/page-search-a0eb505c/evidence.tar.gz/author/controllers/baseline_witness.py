from pathlib import Path
import os,sys,json,subprocess,hashlib,datetime
ROOT=Path("/home/jacob/canvaspilot-page-search-20261008-a0eb")
PY="/home/jacob/canvaspilot-todo-847ff4f12343/venv/bin/python"
BASE=ROOT/"baseline"
env=os.environ.copy()
env.update(PYTHONPATH=str(BASE/"src"),PYTHONDONTWRITEBYTECODE="1",CANVAS_API_TOKEN="",CANVAS_BASE_URL="https://canvas.invalid",CANVAS_PROFILE=str(ROOT/"never-used-profile"))
cases=[]
for name,args in [("ordinary-help",["--help"]),("missing-find-pages",["find-pages","42","--text","field journal"])]:
 r=subprocess.run([PY,str(BASE/"src/canvaspilot/cli.py"),*args],env=env,cwd=BASE,capture_output=True,text=True,timeout=60)
 (ROOT/"evidence"/(name+".stdout")).write_text(r.stdout)
 (ROOT/"evidence"/(name+".stderr")).write_text(r.stderr)
 cases.append({"name":name,"exit":r.returncode,"stdout_sha256":hashlib.sha256(r.stdout.encode()).hexdigest(),"stderr_sha256":hashlib.sha256(r.stderr.encode()).hexdigest()})
sys.path.insert(0,str(BASE/"src"))
from canvaspilot import CanvasAPI,CanvasClient
rows=[{"page_id":1,"url":"week-one","title":"Week one","body":"<p>Keep a field <em>journal</em> each afternoon.</p>","published":True},{"page_id":2,"url":"notes","title":"Notes","body":"<p>Bring a pencil.</p>","published":True}]
fixture={"routes":{"GET /api/v1/courses/42/pages":rows,"GET /api/v1/courses/42/pages/week-one":rows[0]}}
with CanvasClient(base_url="https://canvas.invalid",token="",profile=ROOT/"never-used-profile",fixture=fixture) as client:
 api=CanvasAPI(client)
 listing=api.list_pages(42)
 detail=api.get_page(42,"week-one")
 full=client.get_paginated("/api/v1/courses/42/pages",params={"include[]":["body"]})
assert cases[0]["exit"]==0 and cases[1]["exit"]==2
assert "field journal" not in json.dumps(listing).casefold()
assert "field journal" in detail["body_text"].casefold()
assert full==rows
assert not (ROOT/"never-used-profile").exists()
result={"created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source_commit":"e46a90ff00f80a128baf842587f08df5862318aa","source_tree":"5fef10b4fac997cd1049de24447dce02bfa49ec3","cases":cases,"listing":listing,"single_page":detail,"body_collection":full,"observed_gap":"CLI find-pages exits2; unchanged page list omits body text; existing native detail/collection retain the phrase.","limits":"Authored dictionary fixture plus actual CLI parser; not transport pagination, live school access or claimed test failure.","network_namespace":"Private unshare --net","python":sys.version}
(ROOT/"evidence"/"baseline-result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"result":str(ROOT/"evidence"/"baseline-result.json"),"sha256":hashlib.sha256((ROOT/"evidence"/"baseline-result.json").read_bytes()).hexdigest(),"cases":cases,"gap_confirmed":True}))
