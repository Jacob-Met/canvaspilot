from pathlib import Path
import os,sys,subprocess,json,hashlib,time,datetime
root=Path("/home/jacob/canvaspilot-page-search-20261008-a0eb")
source=root/"candidate"
gate=root/"evidence"/"gate-02"
gate.mkdir(exist_ok=False)
env=os.environ.copy()
env.update(PYTHONPATH=str(source/"src"),PYTHONDONTWRITEBYTECODE="1",CANVAS_API_TOKEN="",CANVAS_BASE_URL="https://canvas.invalid",CANVAS_PROFILE=str(gate/"never-used-profile"),TMPDIR=str(gate))
files={}
for p in sorted(source.rglob("*")):
 if p.is_file():
  b=p.read_bytes();files[p.relative_to(source).as_posix()]={"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
(gate/"source-before.json").write_text(json.dumps(files,indent=2)+"\n")
runs=[]
for name,argv in [("focused", [sys.executable,"-m","pytest","-q","-p","no:cacheprovider","--junitxml="+str(gate/"focused.xml"),"tests/test_page_search.py","tests/test_page_search_cli.py"]),("lint",[sys.executable,"-m","ruff","check","src/canvaspilot/page_search.py","src/canvaspilot/cli.py","tests/test_page_search.py","tests/test_page_search_cli.py"])]:
 start=time.monotonic()
 try:
  result=subprocess.run(argv,cwd=source,env=env,capture_output=True,timeout=180)
  out=result.stdout;err=result.stderr;status=result.returncode;timed_out=False
 except subprocess.TimeoutExpired as error:
  out=error.stdout or b"";err=error.stderr or b"";status=None;timed_out=True
 (gate/(name+".stdout")).write_bytes(out);(gate/(name+".stderr")).write_bytes(err)
 runs.append({"name":name,"argv":argv,"exit":status,"timed_out":timed_out,"seconds":time.monotonic()-start,"stdout_sha256":hashlib.sha256(out).hexdigest(),"stderr_sha256":hashlib.sha256(err).hexdigest()})
 print(json.dumps(runs[-1]),flush=True)
for relative,entry in files.items():
 assert hashlib.sha256((source/relative).read_bytes()).hexdigest()==entry["sha256"],relative
receipt={"created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"python":sys.version,"runs":runs,"input_files_unchanged":len(files),"no_live_canvas":True,"fixture":"only authored dictionary and actual ephemeral127.0.0.1 HTTP","no_dependency_install":True}
(gate/"result.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"receipt":str(gate/"result.json"),"sha256":hashlib.sha256((gate/"result.json").read_bytes()).hexdigest()}),flush=True)
