"""Receive the exact isolated CanvasPilot source with existing native dependencies."""
import pathlib,subprocess,os,json,hashlib,time,sys
root=pathlib.Path('/home/jacob/hamon-canvas-discussion-export-71826f7aa69e')
src=root/'source'; out=root/'evidence/qualification-1';out.mkdir(exist_ok=False)
python='/home/jacob/canvaspilot-announcements-3dcb83a1/.venv/bin/python'
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(src/'src')}
manifest=json.loads((root/'evidence/source-cut.json').read_text())
def pins():
 result=[]
 for row in manifest['files']:
  b=(src/row['path']).read_bytes();h=hashlib.sha256(b).hexdigest()
  assert h==row['sha256'],row['path']
  result.append({'path':row['path'],'sha256':h})
 return result
before=pins();steps=[]
commands=[
 ('lint',[python,'-B','-m','ruff','check','--no-cache','src','tests','scripts'],120),
 ('project',[python,'-B','-m','pytest','-q','-p','no:cacheprovider','--junitxml='+str(out/'pytest.xml')],1200),
]
for name,cmd,limit in commands:
 started=time.monotonic();timed_out=False
 try:
  r=subprocess.run(cmd,cwd=src,env=env,capture_output=True,timeout=limit)
  code=r.returncode;stdout=r.stdout;stderr=r.stderr
 except subprocess.TimeoutExpired as e:
  timed_out=True;code=None;stdout=e.stdout or b'';stderr=e.stderr or b''
 (out/(name+'.stdout.txt')).write_bytes(stdout);(out/(name+'.stderr.txt')).write_bytes(stderr)
 step={'name':name,'command':cmd,'exitCode':code,'timeout':timed_out,'seconds':round(time.monotonic()-started,3),'stdoutBytes':len(stdout),'stderrBytes':len(stderr),'stdoutSha256':hashlib.sha256(stdout).hexdigest(),'stderrSha256':hashlib.sha256(stderr).hexdigest()}
 steps.append(step);(out/'progress.json').write_text(json.dumps(steps,indent=2)+'\n')
 print(json.dumps({**step,'tail':stdout.decode(errors='replace')[-4000:],'stderrTail':stderr.decode(errors='replace')[-1000:]}),flush=True)
after=pins()
result={'sourceCutSha256':hashlib.sha256((root/'evidence/source-cut.json').read_bytes()).hexdigest(),'base':manifest['base'],'baseTree':manifest['baseTree'],'steps':steps,'sourceBefore':before,'sourceAfter':after,'sourceUnchanged':before==after,'passed':all(x['exitCode']==0 and not x['timeout'] for x in steps),'python':python,'scope':'All maintained current staged source/tests/scripts at frozen92e9 source plus six discussion-export contribution paths. Existing read-only native dependency closure; no install, live account access or source mutation. Later main4675 submission-export source is outside this frozen run.'}
(out/'receiving.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'complete':True,'passed':result['passed'],'sourceUnchanged':result['sourceUnchanged'],'receipt':str(out/'receiving.json')}),flush=True)
