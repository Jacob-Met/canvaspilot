import os, socket
_allowed=('127.0.0.1',int(os.environ['CANVAS_SESSION_PORT']))
_connect=socket.socket.connect
_connect_ex=socket.socket.connect_ex
def _check(address):
    if isinstance(address,tuple) and address != _allowed:
        raise AssertionError('Only this independent loopback broker is allowed')
def connect(self,address):
    _check(address)
    return _connect(self,address)
def connect_ex(self,address):
    _check(address)
    return _connect_ex(self,address)
socket.socket.connect=connect
socket.socket.connect_ex=connect_ex
