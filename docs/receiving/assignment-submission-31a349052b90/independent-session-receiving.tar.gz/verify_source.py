"""Independent frozen-source and author-receipt verification; no native rerun."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
AUTHOR = Path('/dev/shm/hamon-31a349052b90/canvas-assignment-submission-31a349052b90')
BASE = AUTHOR / 'current-base'
FINAL = AUTHOR / 'publish-candidate'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def pin(data):
    return {'bytes': len(data), 'sha256': sha(data), 'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}
composition = json.loads((AUTHOR / 'current-composition-receipt.json').read_bytes())
freeze = json.loads((AUTHOR / 'publish-source-freeze.json').read_bytes())
inputs = composition['current_native_inputs']
for entry in inputs:
    actual = pin((BASE / entry['path']).read_bytes())
    assert actual['git_blob'] == entry['sha']
    assert actual['bytes'] == entry['size']
for entry in freeze['source_files']:
    assert pin((FINAL / entry['path']).read_bytes()) == {k: entry[k] for k in ('bytes', 'sha256', 'git_blob')}
new_import = b'from canvaspilot.assignment_submission import project_assignment_submission\n'
new_call = b'            row["submission"], row["submission_warnings"] = project_assignment_submission(\n                a.get("submission")\n            )\n'
baseline_api = (BASE / 'src/canvaspilot/api.py').read_bytes()
final_api = (FINAL / 'src/canvaspilot/api.py').read_bytes()
assert final_api.count(new_import) == final_api.count(new_call) == 1
assert final_api.replace(new_import, b'').replace(new_call, b'') == baseline_api
baseline_ast = ast.parse(baseline_api)
final_ast = ast.parse(final_api)
def methods(tree):
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'CanvasAPI')
    return {node.name: ast.dump(node, include_attributes=False) for node in cls.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
old_methods, new_methods = methods(baseline_ast), methods(final_ast)
assert old_methods.keys() == new_methods.keys()
changed = [name for name in old_methods if old_methods[name] != new_methods[name]]
assert changed == ['list_assignments']
unchanged_package = []
for file in sorted((BASE / 'src').rglob('*.py')):
    relative = file.relative_to(BASE)
    if str(relative) != 'src/canvaspilot/api.py':
        assert file.read_bytes() == (FINAL / relative).read_bytes()
        unchanged_package.append(str(relative))
eof = []
for entry in freeze['EOF_only_changes_from_tested_current_candidate']:
    old = (AUTHOR / 'current-candidate' / entry['path']).read_bytes()
    new = (FINAL / entry['path']).read_bytes()
    assert old == new + b'\n'
    if entry['path'].endswith('.py'):
        assert ast.dump(ast.parse(old), include_attributes=False) == ast.dump(ast.parse(new), include_attributes=False)
    eof.append({'path': entry['path'], 'removed_bytes': 1, 'before': pin(old), 'after': pin(new)})
assert len(eof) == 3
gates = []
for name in ['baseline-public-boundaries', 'candidate-full-native', 'current-main-process-receiving']:
    directory = AUTHOR / 'evidence' / name
    data = (directory / 'receipt.json').read_bytes()
    receipt = json.loads(data)
    assert sha((directory / 'stdout').read_bytes()) == receipt['stdout_sha256']
    assert sha((directory / 'stderr').read_bytes()) == receipt['stderr_sha256']
    for source_pin in receipt['source_pins']:
        assert pin((Path(receipt['cwd']) / source_pin['path']).read_bytes()) == {k: source_pin[k] for k in ('bytes', 'sha256', 'git_blob')}
    counts = {}
    for case in receipt['cases']:
        counts[case['status']] = counts.get(case['status'], 0) + 1
    gates.append({'name': name, 'cwd': receipt['cwd'], 'receipt_sha256': sha(data), 'exit_code': receipt['exit_code'], 'cases': counts, 'total_cases': len(receipt['cases']), 'stdout_sha256': receipt['stdout_sha256'], 'stderr_sha256': receipt['stderr_sha256'], 'source_pins_verified': len(receipt['source_pins'])})
archive = (AUTHOR / 'publication/author-native-receiving.tar.gz').read_bytes()
assert len(archive) == 559468
assert sha(archive) == '34d4060f16b71828fedf5b33d7e5dbb563a3deb4d3b8f1b088a9adb719710cd0'
result = {'reviewer': '/root/engine_execution', 'accepted': True, 'source_parent': composition['current_commit'], 'source_parent_tree': composition['current_tree'], 'current_native_inputs_verified': len(inputs), 'final_source_files': freeze['source_files'], 'api_methods': len(old_methods), 'changed_api_methods': changed, 'all_api_bytes_outside_one_import_and_hook_preserved': True, 'unchanged_package_files': unchanged_package, 'EOF_only_bridge': eof, 'author_native_gates_received_not_reexecuted': gates, 'author_archive': pin(archive), 'official_sources': [{'url': 'https://canvas.instructure.com/doc/api/assignments.html', 'retrieval_ref': 'turn10view0', 'supports': 'The included submission concerns the requesting user. The aggregate has_submitted_submissions flag concerns at least one student; absence does not supply a current-user state.'}, {'url': 'https://developerdocs.instructure.com/services/canvas/resources/submissions', 'retrieval_ref': 'turn8search0', 'supports': 'Submission workflow, attempt/time and late/missing/excused are distinct reported fields; late-policy labels are separate. Projection policy and typed warnings are CanvasPilot design, not an inferred Canvas grade/deadline decision.'}], 'native_reruns': 0, 'network_or_account_calls': 0}
data = (json.dumps(result, indent=2) + '\n').encode()
(ROOT / 'source-verification.json').write_bytes(data)
print(json.dumps({'accepted': True, 'source_parent': composition['current_commit'], 'inputs': len(inputs), 'methods': len(old_methods), 'changed': changed, 'gates': [{'name': x['name'], 'cases': x['cases']} for x in gates], 'receipt_sha256': sha(data)}))
