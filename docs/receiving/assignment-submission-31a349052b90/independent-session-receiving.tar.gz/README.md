# CanvasPilot assignment submission: independent receiving appendix

Reviewer: `/root/engine_execution`, 2026-10-08. Disposition: accepted for the exact final source below, subject to the owner's ordinary published-head integration gates. This appendix supplies independent source review and a distinct native session receiving boundary. It changes no CanvasPilot application source and records no hosted CI or live-account claim.

## Exact source

Receiving parent: `Jacob-Met/canvaspilot` commit `ca2318fe7c56d2e4ec1b363ff8a945ab78bf4a0c`, tree `ea775021cbf300367369a169f584f1092347cf5c`.

| File | Final Git blob |
| --- | --- |
| `src/canvaspilot/api.py` | `8de750525055991ca470fb4881d0368a07631818` |
| `src/canvaspilot/assignment_submission.py` | `95b1f19927e4eecf99fc852325737c3cfe86cd0d` |
| `tests/test_assignment_submission.py` | `5a5b14e207a85b414e973508bcbc8c94558d2479` |
| `tests/test_assignment_submission_process.py` | `41c5efc672cd1154c278609c773e5deff003ec08` |
| `docs/assignment-submission.md` | `be1465caebdc7cddc302fb3e71a372fe540195c4` |
| `README.md` | `f1740a512af81916490a27887141382d10469efa` |

The current client `1db4b1135305f7e410025ae7937f9a6cd349f020` and session broker `0e586bb933d517160bc3bfbd8ad86b3ba59ee92f` are unchanged. `source-verification.json` records independent hashes for all 46 current native inputs and all six final files. Removing the one added import and the projection hook reconstructs the original API bytes exactly; only `list_assignments` changes among its 40 methods. Every other existing package file is byte-identical. Three removed trailing LF bytes bridge the original author-tested source to final publication source; both affected Python ASTs are identical. The independent session receiving ran the final, normalized source directly.

## Source and contract disposition

The existing assignment request already asks for `include[]=submission`. The new helper projects eight reported fields without making another request or altering authentication, continuation, filtering, order, count, or error behavior. Existing CLI, MCP and sync consumers carry the result through their current paths.

Missing or null submission remains null; an explicit empty object remains an empty object. Omitted known fields remain omitted and explicit null remains null. Four string fields retain unfamiliar labels. `attempt` accepts only a nonnegative integer, excluding booleans; `late`, `missing`, and `excused` accept only booleans. Malformed known fields are omitted with location-only warnings, while valid neighboring fields survive. Unknown fields, answer bodies, attachments and grades are not exposed by this compact projection. No missing, late, excused, deadline or grade status is inferred.

The official [Assignment reference](https://canvas.instructure.com/doc/api/assignments.html) distinguishes the requesting user's included submission from the assignment-wide `has_submitted_submissions` aggregate. The [Submission reference](https://developerdocs.instructure.com/services/canvas/resources/submissions) exposes separate reported workflow, attempt, timestamp, late, missing, excused and late-policy fields. These references support the reported-data boundary; the projection's type checks and warnings are CanvasPilot policy, not Canvas grade or deadline determinations.

## Independent native receiving

Four real CLI child processes were executed once: two against the exact current parent and two against the final candidate. Each used the current production session broker handler over an isolated loopback HTTP server. Only its browser-terminal `_call` seam supplied synthetic JSON. There was no browser, live Canvas service, account, credential, dependency installation or broad suite rerun. The retained guard limits child TCP connections to the one ephemeral loopback endpoint. The absent profile remained absent, and package hashes remained unchanged.

| Consequential control | Current parent | Final candidate |
| --- | --- | --- |
| One short page followed by an opaque absolute continuation URL; current-user projection, malformed neighbors and aggregate-only absence checked | CLI exited 0; feature assertion fails with `KeyError: 'submission'` | Pass, CLI exits 0 |
| Later page omits required Link metadata; no partial list may escape | Pass, CLI exits 1 with empty stdout | Pass, CLI exits 1 with empty stdout |

The success case confirms that an absolute opaque continuation is followed exactly even when the first page is shorter than the requested page size, without reappending the initial query filters. It then checks three distinguishable current-user results, including unfamiliar labels, explicit null, rejected boolean-as-integer and integer-as-boolean fields, retained usable neighbors, and no inferred status from an old due date or the aggregate flag. The refusal case confirms the unchanged session pagination failure prevents partial success output.

The four CLI processes generated 12 loopback HTTP requests and eight synthetic terminal GET jobs. No additional native invocation was made after these receipts were retained.

### Preserved receiver correction

The original `receive_session.py` mistakenly required successful stderr to be empty. Both successful CLI invocations produced the existing three HTTPX INFO lines for health/fetch/fetch, so the initial evaluator rejected them before payload assertions. The original script and both initial receipts remain unchanged.

`evaluate_session.py` performed only an offline evaluation of those same retained bytes. It verifies raw stream hashes and permits exactly the three expected 200 INFO lines using the same loopback port, then checks the payload, continuation and refusal behavior. Its final result is one genuine missing-feature failure plus one preserved control on the parent, and two passing controls on the candidate. This corrects a receiver expectation; it neither changes application source nor counts as another native run.

## Relation to author qualification

The separately immutable author archive is `author-native-receiving.tar.gz`, 559,468 bytes, SHA256 `34d4060f16b71828fedf5b33d7e5dbb563a3deb4d3b8f1b088a9adb719710cd0`. This reviewer verified that archive's compressed size and hash, plus the raw streams and pinned inputs of three author receipts. Archive member verification is the author's separate evidence.

The author's full 447-test pass belongs to the original feature candidate on parent `55fe1e0a3c4ad85e1065f295e49d44722c3be32b`. After the pagination dependency merged, the author reran eight actual PAT process controls on parent `ca2318fe...`, all passing. The author's initial public-boundary receipt preserves five feature failures and three passing failure controls. These are received results, not independently reexecuted tests. This appendix adds the distinct session boundary on final source; it does not relabel the older full suite as a current-parent run.

## Packet inspection and replay boundary

`manifest.json` records the exact bytes and SHA256 of every preceding appendix member. `baseline-session/receipt.json` and `candidate-session/receipt.json` contain the complete original stdout, stderr, status, request trace and source pins. `corrected-evaluation.json` records the corrected results, and `source-verification.json` records the independent source and received-evidence checks. Their source scripts are included for review.

Unpack this archive into a new directory and compare its regular files against `manifest.json` before relying on it. The archive contains no complete CanvasPilot checkout or Python environment. Reexecuting `evaluate_session.py` or `verify_source.py` requires the exact author source/evidence roots named in those scripts; both scripts are offline. A new native run of `receive_session.py` would require those exact reconstructed sources and the recorded Python dependencies, and should be recorded separately rather than replacing the preserved receipts. No new native execution is needed for this accepted disposition.
