"""Correct the receiver's stderr expectation using retained native bytes only."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
ORIGIN = "https://canvas.example.invalid"
NEXT = ORIGIN + "/api/v1/courses/71/assignments?cursor=after%2B%2F%3D&rev=accepted"
REPORTED = {"workflow_state": "graded", "attempt": 0, "submitted_at": None,
            "submission_type": None, "late_policy_status": "extended",
            "late": False, "missing": True, "excused": True}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def evaluate(case):
    assert sha(case["stdout"].encode()) == case["stdout_sha256"]
    assert sha(case["stderr"].encode()) == case["stderr_sha256"]
    assert case["terminal_errors"] == []
    assert case["wire"] == [{"method": "GET", "path": "/health"},
                            {"method": "POST", "path": "/fetch"},
                            {"method": "POST", "path": "/fetch"}]
    assert len(case["jobs"]) == 2
    assert case["jobs"][0]["path"] == "/api/v1/courses/71/assignments?order_by=due_at&include%5B%5D=submission&per_page=50"
    assert case["jobs"][1]["path"] == NEXT
    assert all(job["op"] == "fetch" and job["method"] == "GET" and job["body"] is None
               and job["headers"] == {"Accept": "application/json"} for job in case["jobs"])
    if case["name"] == "opaque_continuation_projects_current_user":
        assert case["exit_code"] == 0
        # CLI configures INFO logging, so session httpx.request emits these
        # existing successful request lines. No arbitrary stderr is allowed.
        lines = case["stderr"].splitlines()
        assert len(lines) == 3
        found = re.fullmatch(r'HTTP Request: GET http://127\.0\.0\.1:(\d+)/health "HTTP/1\.0 200 OK"', lines[0])
        assert found
        port = found.group(1)
        expected_fetch = f'HTTP Request: POST http://127.0.0.1:{port}/fetch "HTTP/1.0 200 OK"'
        assert lines[1:] == [expected_fetch, expected_fetch]
        rows = json.loads(case["stdout"])
        assert [row["id"] for row in rows] == [501, 502, 503]
        assert all(row["has_submitted_submissions"] is True for row in rows)
        assert rows[0]["submission"] == REPORTED
        assert rows[0]["submission_warnings"] == []
        assert rows[1]["submission"] == {"workflow_state": "future_canvas_label", "missing": None, "excused": False}
        assert set(rows[1]["submission_warnings"]) == {
            "submission.submitted_at: expected string or null",
            "submission.attempt: expected nonnegative integer or null",
            "submission.late: expected boolean or null"}
        assert rows[2]["submission"] is None and rows[2]["submission_warnings"] == []
        assert "synthetic-private-marker" not in case["stdout"]
    else:
        assert case["name"] == "later_metadata_refusal_has_no_partial_list"
        assert case["exit_code"] != 0 and case["stdout"] == ""
        assert "CanvasPaginationError: session pagination response has no Link metadata" in case["stderr"]

sources = []
for label, expected_pass in [("baseline-session", 1), ("candidate-session", 2)]:
    data = (ROOT / label / "receipt.json").read_bytes()
    receipt = json.loads(data)
    assert receipt["receiver"]["sha256"] == sha((ROOT / "receive_session.py").read_bytes())
    assert receipt["source_after_unchanged"] is True
    for relative, pin in receipt["source_before"].items():
        body = (Path(receipt["source"]) / relative).read_bytes()
        assert sha(body) == pin["sha256"]
        assert hashlib.sha1(b"blob " + str(len(body)).encode() + b"\0" + body).hexdigest() == pin["git_blob"]
    outcomes = []
    for case in receipt["cases"]:
        outcome = {"name": case["name"], "native_cli_exit": case["exit_code"]}
        try:
            evaluate(case)
            outcome["passed"] = True
        except Exception as error:
            outcome.update(passed=False, failure={"type": type(error).__name__, "message": str(error)})
        outcomes.append(outcome)
    count = sum(item["passed"] for item in outcomes)
    assert count == expected_pass, (label, outcomes)
    if label == "baseline-session":
        assert outcomes[0]["failure"] == {"type": "KeyError", "message": "'submission'"}
    sources.append({"label": label, "receipt_sha256": sha(data), "source": receipt["source"],
                    "python": receipt["python"], "executable": receipt["executable"],
                    "source_before": receipt["source_before"], "cases": outcomes,
                    "passed": count, "failed": len(outcomes) - count})

result = {"reviewer": "/root/engine_execution", "accepted": True,
          "base": "ca2318fe7c56d2e4ec1b363ff8a945ab78bf4a0c",
          "method": "Offline evaluation of the same four retained native CLI streams; no subprocess, endpoint, browser, or account invoked by this evaluator",
          "receiver_correction": "Original evaluator expected empty stderr and rejected successful existing HTTPX INFO logs on both sources before payload checks. Original script and initial receipts remain unchanged. The corrected evaluator permits exactly health/fetch/fetch 200 INFO lines with one identical loopback port.",
          "native_cli_processes_previously_executed": 4,
          "additional_native_cli_processes": 0,
          "sources": sources,
          "final_candidate_api_blob": "8de750525055991ca470fb4881d0368a07631818",
          "final_candidate_helper_blob": "95b1f19927e4eecf99fc852325737c3cfe86cd0d",
          "unchanged_current_client_blob": "1db4b1135305f7e410025ae7937f9a6cd349f020",
          "unchanged_current_broker_blob": "0e586bb933d517160bc3bfbd8ad86b3ba59ee92f"}
body = (json.dumps(result, indent=2) + "\n").encode()
(ROOT / "corrected-evaluation.json").write_bytes(body)
print(json.dumps({"accepted": True, "receipt_sha256": sha(body),
                  "sources": [{"label": s["label"], "passed": s["passed"], "failed": s["failed"], "cases": s["cases"]} for s in sources],
                  "new_native_calls": 0}))
