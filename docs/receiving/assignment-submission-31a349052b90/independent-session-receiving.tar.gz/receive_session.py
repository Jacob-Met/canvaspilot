"""Independent current-source broker Handler/CLI receiving; no browser or account."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import threading
from http.server import ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--label", required=True)
args = parser.parse_args()
source = Path(args.source).resolve()
own = Path(__file__).resolve().parent
output = own / args.label
output.mkdir()
profile = output / "profile-must-never-open"
origin = "https://canvas.example.invalid"
endpoint = "/api/v1/courses/71/assignments"
continuation = origin + endpoint + "?cursor=after%2B%2F%3D&rev=accepted"
os.environ["CANVAS_BASE_URL"] = origin
os.environ["CANVAS_API_TOKEN"] = ""
os.environ["CANVAS_PROFILE"] = str(profile)
sys.path.insert(0, str(source / "src"))
from canvaspilot import session_broker as broker  # noqa: E402

def digest(data):
    return hashlib.sha256(data).hexdigest()

def pin(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": digest(data),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}

before = {str(p.relative_to(source)): pin(p) for p in sorted((source / "src").rglob("*.py"))}
assert before["src/canvaspilot/client.py"]["git_blob"] == "1db4b1135305f7e410025ae7937f9a6cd349f020"
assert before["src/canvaspilot/session_broker.py"]["git_blob"] == "0e586bb933d517160bc3bfbd8ad86b3ba59ee92f"

def assignment(identifier, submission=None, *, supplied=True):
    row = {"id": identifier, "name": "Synthetic receiving assignment", "due_at": "1900-01-01T00:00:00Z",
           "has_submitted_submissions": True, "submission_types": ["on_paper"]}
    if supplied:
        row["submission"] = submission
    return row

reported = {"workflow_state": "graded", "attempt": 0, "submitted_at": None,
            "submission_type": None, "late_policy_status": "extended",
            "late": False, "missing": True, "excused": True}
first = [assignment(501, {**reported, "grade": "synthetic-private-marker", "body": "synthetic-private-marker"})]
second = [assignment(502, {"workflow_state": "future_canvas_label", "attempt": True,
                          "late": 0, "missing": None, "excused": False, "submitted_at": {},
                          "attachments": ["synthetic-private-marker"]}),
          assignment(503, supplied=False)]
state = {"mode": "success", "jobs": [], "wire": [], "terminal_errors": []}

def terminal(job, timeout=120):
    # This is the sole synthetic seam: the queued browser-terminal response.
    # Native Handler decoding, serialization, health metadata, client, pagination,
    # assignment projection and CLI JSON output all execute unchanged.
    state["jobs"].append(copy.deepcopy(job))
    try:
        assert job["op"] == "fetch" and job["method"] == "GET"
        assert job["body"] is None and job["headers"] == {"Accept": "application/json"}
        parsed = urlsplit(job["path"])
        if not parsed.scheme:
            assert parsed.path == endpoint
            assert parse_qs(parsed.query) == {"order_by": ["due_at"], "include[]": ["submission"], "per_page": ["50"]}
            response = {"status": 200, "json": first, "text": None,
                        "headers": {"link": '<' + continuation + '>; rel="next"'}}
        else:
            assert job["path"] == continuation, "opaque continuation changed or filters reapplied"
            response = {"status": 200, "json": second, "text": None}
            if state["mode"] == "success":
                response["headers"] = {"link": ""}
        return {"ok": True, "response": copy.deepcopy(response)}
    except Exception as exc:
        state["terminal_errors"].append(type(exc).__name__ + ": " + str(exc))
        return {"ok": False, "error": "independent terminal fixture rejected the request"}

class RecordedHandler(broker.Handler):
    def do_GET(self):
        state["wire"].append({"method": "GET", "path": self.path})
        return super().do_GET()

    def do_POST(self):
        state["wire"].append({"method": "POST", "path": self.path})
        return super().do_POST()

broker._call = terminal
broker.STATE.base_url = origin
broker.STATE.read_only = True
broker.STATE.ready.set()
server = ThreadingHTTPServer(("127.0.0.1", 0), RecordedHandler)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
guard = output / "guard"
guard.mkdir()
(guard / "sitecustomize.py").write_text(
    "import os, socket\n"
    "_allowed=('127.0.0.1',int(os.environ['CANVAS_SESSION_PORT']))\n"
    "_connect=socket.socket.connect\n_connect_ex=socket.socket.connect_ex\n"
    "def _check(address):\n"
    "    if isinstance(address,tuple) and address != _allowed:\n"
    "        raise AssertionError('Only this independent loopback broker is allowed')\n"
    "def connect(self,address):\n    _check(address)\n    return _connect(self,address)\n"
    "def connect_ex(self,address):\n    _check(address)\n    return _connect_ex(self,address)\n"
    "socket.socket.connect=connect\nsocket.socket.connect_ex=connect_ex\n"
)
environment = {"PATH": "/usr/bin:/bin", "LC_ALL": "C.UTF-8", "PYTHONDONTWRITEBYTECODE": "1",
               "PYTHONPATH": str(guard) + os.pathsep + str(source / "src"),
               "CANVAS_SESSION_PORT": str(server.server_port), "CANVAS_BASE_URL": origin,
               "CANVAS_API_TOKEN": "", "CANVAS_PROFILE": str(profile)}
command = [sys.executable, "-B", "-m", "canvaspilot.cli", "assignments", "71", "--bucket", "",
           "--base-url", origin, "--token", "", "--profile", str(profile)]
cases = []
try:
    for mode, name in [("success", "opaque_continuation_projects_current_user"),
                       ("missing_metadata", "later_metadata_refusal_has_no_partial_list")]:
        state.update(mode=mode, jobs=[], wire=[], terminal_errors=[])
        completed = subprocess.run(command, cwd=source, env=environment, capture_output=True, timeout=15)
        case = {"name": name, "command": command, "exit_code": completed.returncode,
                "stdout": completed.stdout.decode(), "stderr": completed.stderr.decode(),
                "stdout_sha256": digest(completed.stdout), "stderr_sha256": digest(completed.stderr),
                "jobs": copy.deepcopy(state["jobs"]), "wire": copy.deepcopy(state["wire"]),
                "terminal_errors": copy.deepcopy(state["terminal_errors"])}
        try:
            assert not state["terminal_errors"]
            assert len(state["jobs"]) == 2
            assert state["jobs"][1]["path"] == continuation
            assert state["wire"] == [{"method": "GET", "path": "/health"},
                                     {"method": "POST", "path": "/fetch"},
                                     {"method": "POST", "path": "/fetch"}]
            if mode == "success":
                assert completed.returncode == 0 and completed.stderr == b""
                rows = json.loads(completed.stdout)
                assert [r["id"] for r in rows] == [501, 502, 503]
                assert all(r["has_submitted_submissions"] is True for r in rows)
                assert rows[0]["submission"] == reported
                assert rows[0]["submission_warnings"] == []
                assert rows[1]["submission"] == {"workflow_state": "future_canvas_label", "missing": None, "excused": False}
                assert set(rows[1]["submission_warnings"]) == {
                    "submission.submitted_at: expected string or null",
                    "submission.attempt: expected nonnegative integer or null",
                    "submission.late: expected boolean or null"}
                assert rows[2]["submission"] is None and rows[2]["submission_warnings"] == []
                assert b"synthetic-private-marker" not in completed.stdout
            else:
                assert completed.returncode != 0 and completed.stdout == b""
                assert b"session pagination response has no Link metadata" in completed.stderr
            case["passed"] = True
        except Exception as exc:
            case["passed"] = False
            case["failure"] = {"type": type(exc).__name__, "message": str(exc)}
        cases.append(case)
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=3)

after = {str(p.relative_to(source)): pin(p) for p in sorted((source / "src").rglob("*.py"))}
assert before == after
assert not profile.exists()
receipt = {"reviewer": "/root/engine_execution", "repository": "Jacob-Met/canvaspilot",
           "base": "ca2318fe7c56d2e4ec1b363ff8a945ab78bf4a0c", "source": str(source), "label": args.label,
           "python": sys.version, "executable": sys.executable, "receiver": pin(Path(__file__)),
           "source_before": before, "source_after_unchanged": True,
           "method": "Actual current production session Handler and native CLI; synthetic _call terminal only; no browser/account/provider call",
           "network_boundary": "Child TCP connects restricted to this disposable 127.0.0.1 broker; PAT empty; private profile never created",
           "cases": cases, "passed": sum(c["passed"] for c in cases),
           "failed": sum(not c["passed"] for c in cases), "native_cli_processes": len(cases),
           "browser_calls": 0, "live_account_calls": 0}
data = (json.dumps(receipt, indent=2) + "\n").encode()
(output / "receipt.json").write_bytes(data)
print(json.dumps({"label": args.label, "passed": receipt["passed"], "failed": receipt["failed"],
                  "receipt_sha256": digest(data), "cases": [{k: c[k] for k in ("name", "exit_code", "passed")}
                  | ({"failure": c["failure"]} if "failure" in c else {}) for c in cases]}))
sys.exit(1 if receipt["failed"] else 0)
