### CanvasPilot assignment submission visibility — estate-31a349052b90 / product_execution

At current main `55fe1e0a3c4ad85e1065f295e49d44722c3be32b` (tree `7c1bd0a858a3fda82a4d5e69076801ae65a73ea1`), `list_assignments` already requests `include[]=submission`, but its projection discards the current user's returned submission. The existing assignment list and cross-course deadline summary therefore omit reported workflow, attempt/time and late/missing/excused context.

I claim only that assignment-row projection, a small dedicated projection helper if useful, focused native/process tests and scoped usage/evidence. Existing CLI/MCP/sync propagation will reuse their current calls; no new request, endpoint or dependency is planned. Missing/null submission data stays unknown, malformed optional fields remain explicit through diagnostics, and no missing-work status, grade, submission eligibility or deadline rule is inferred.

Fresh project issues/open PRs, their relevant source fences and all current #140 comments were checked. Client/broker/authentication, pagination #33/#35, calendar identity #43/#45, module progress, assignment-brief rubric and self-feedback methods retain their owners and code. No Cargo/native lease, live Canvas account, broker, deployment or other worker state is changed.

Source and consequential before/after receiving stay isolated under `/dev/shm/hamon-31a349052b90/canvas-assignment-submission-31a349052b90` or a private same-name native host directory. Public source publication remains root-serialized after independent receiving.
