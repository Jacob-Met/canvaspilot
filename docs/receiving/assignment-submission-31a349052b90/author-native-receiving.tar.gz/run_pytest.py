"""Run the retained Canvas assignment receiver without modifying borrowed tools."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("label")
parser.add_argument("pytest_args", nargs="*")
options = parser.parse_args()
root = Path(__file__).resolve().parent
source = options.source.resolve()
out = root / "evidence" / options.label
out.mkdir(parents=True, exist_ok=False)
python = "/dev/shm/hamon-afe225d6c6be-product/canvas-venv/bin/python"
command = [python, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider",
           "--basetemp=" + str(root / "tmp" / options.label),
           "--junitxml=" + str(out / "results.xml"), *options.pytest_args]
environment = os.environ.copy()
environment.update({"PYTHONPATH": str(source / "src"),
                    "PYTHONDONTWRITEBYTECODE": "1", "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
                    "CANVAS_SUBMISSION_SOURCE": str(source),
                    "CANVAS_SUBMISSION_EVIDENCE": str(out / "public-cases"),
                    "TMPDIR": str(root / "tmp")})
for name in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy"):
    environment.pop(name, None)
start = time.time()
result = subprocess.run(command, cwd=source, env=environment, capture_output=True)
for name, data in (("stdout", result.stdout), ("stderr", result.stderr)):
    (out / name).write_bytes(data)
cases = []
if (out / "results.xml").exists():
    for case in ET.parse(out / "results.xml").iter("testcase"):
        status = "passed"
        for tag in ("failure", "error", "skipped"):
            if case.find(tag) is not None:
                status = tag
        cases.append({"name": case.get("name"), "classname": case.get("classname"), "status": status})
pins = []
for path in sorted((source / "src").rglob("*.py")):
    data = path.read_bytes()
    pins.append({"path": str(path.relative_to(source)), "bytes": len(data),
                 "sha256": hashlib.sha256(data).hexdigest(),
                 "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()})
receipt = {"command": command, "cwd": str(source), "exit_code": result.returncode,
           "elapsed_seconds": time.time() - start, "borrowed_runtime_read_only": True,
           "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
           "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(), "cases": cases, "source_pins": pins}
(out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(result.stdout.decode(), end="")
print(result.stderr.decode(), end="")
print(json.dumps({"label": options.label, "exit_code": result.returncode,
                  "counts": {status: sum(c["status"] == status for c in cases)
                             for status in ("passed", "failure", "error", "skipped")},
                  "receipt": str(out / "receipt.json")}, indent=2))
