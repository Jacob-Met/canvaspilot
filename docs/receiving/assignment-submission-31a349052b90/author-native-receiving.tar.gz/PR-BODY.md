## Why

Assignment lists already request Canvas's current-user submission, but discard it.
The remaining `has_submitted_submissions` flag means at least one student has
submitted, so it cannot answer whether the requesting student's work is reported
submitted, missing, late or excused.

## Change

Retain eight supplied submission fields in a compact `submission` object with
location-only `submission_warnings` for malformed optional values. Missing/null
data remains unknown; explicit false/null/zero and new string state labels are
preserved. Existing assignment fields keep their meanings.

This reaches the existing assignment and sync Python APIs, CLI commands and MCP
tools through the shared assignment projection. No new request or command is
added. Current PR35 client/broker code and pagination policy are preserved.

The guide explains the aggregate/current-user distinction, existing selection
limits, optional-field handling and actual CLI/MCP usage.

## Validation

- Original main `55fe1e0a`: all 414 existing native tests passed.
- Unchanged baseline witnesses: the public API witness and five actual-process
  feature cases fail because `submission` is absent; three upstream-failure
  process controls pass.
- Candidate on that original base: all 447 tests pass, including 33 new methods.
- Composition on current main `ca2318fe` (PR35 merged): all eight affected
  HTTP/CLI/MCP process cases pass. The 28 recorded GETs retain the same decoded
  request values; no per-assignment submission read appears.
- The 447-test result belongs to the earlier base. Full hosted CI of the
  published current-base composition remains required.

Source review confirms only `list_assignments` changes among the 40 API methods;
all other existing package files retain their receiving-parent bytes. Fixtures
are synthetic, and the actual process cases restrict connections to their
disposable loopback endpoint.

Ownership: https://github.com/Jacob-Met/hamon/issues/140#issuecomment-6059762346

