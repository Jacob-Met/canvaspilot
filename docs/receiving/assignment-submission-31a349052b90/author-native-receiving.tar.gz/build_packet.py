"""Freeze and read back the native author packet; no borrowed runtime files."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
out = root / "publication"
out.mkdir(exist_ok=True)
paths = []
for directory in ("baseline", "candidate", "current-base", "current-candidate",
                  "publish-candidate", "receiving", "evidence"):
    paths.extend(path for path in (root / directory).rglob("*") if path.is_file())
for name in (
    "PACKET-README.md", "PR-BODY.md", "author-receipt.json", "runtime.json",
    "contract.json", "source-manifest.json", "source-preservation.json",
    "current-composition-receipt.json", "publish-source-freeze.json",
    "behavior-comparison.json", "current-main-behavior-comparison.json",
    "source-fetch-errors.json", "ownership-claim.md", "ownership-claim-receipt.json",
    "candidate.patch", "current-candidate.patch", "publish.patch",
    "receiving-parent-tree.json", "run_pytest.py", "build_packet.py",
):
    paths.append(root / name)
paths = sorted(set(paths))
payload = {}
members = []
for path in paths:
    relative = path.relative_to(root).as_posix()
    assert not path.is_symlink()
    data = path.read_bytes()
    payload[relative] = data
    members.append({
        "path": relative, "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    })
manifest = {
    "repository": "Jacob-Met/canvaspilot",
    "source_parent": "ca2318fe7c56d2e4ec1b363ff8a945ab78bf4a0c",
    "source_tree": "ea775021cbf300367369a169f584f1092347cf5c",
    "publication_source": "publish-source-freeze.json",
    "scope": "Author native source/evidence; independent receiving is a separate appendix",
    "payload_count": len(members), "payload_bytes": sum(item["bytes"] for item in members),
    "files": members,
}
payload["MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode="wb", filename="", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(payload.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o644
            member.uid = member.gid = 0
            member.mtime = 0
            archive.addfile(member, io.BytesIO(data))
data = buffer.getvalue()
archive_path = out / "author-native-receiving.tar.gz"
assert not archive_path.exists(), "Do not overwrite a frozen archive"
archive_path.write_bytes(data)
readback = archive_path.read_bytes()
assert readback == data
with tarfile.open(fileobj=io.BytesIO(readback), mode="r:gz") as archive:
    names = archive.getnames()
    assert set(names) == set(payload) and len(names) == len(payload)
    for member in archive.getmembers():
        assert member.isfile()
        assert archive.extractfile(member).read() == payload[member.name]
receipt = {
    "archive": archive_path.name, "bytes": len(data),
    "sha256": hashlib.sha256(data).hexdigest(),
    "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    "payload_files": len(members), "archive_members": len(payload),
    "all_members_decoded_and_read_back_exact": True,
    "source_parent": manifest["source_parent"], "source_tree": manifest["source_tree"],
    "no_compiled_executables_or_borrowed_dependencies_included": True,
    "publication_status": "Local immutable packet; no source publication asserted",
}
(out / "archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
(out / "archive-members.json").write_text(json.dumps(manifest, indent=2) + "\n")
(out / "README.md").write_bytes((root / "PACKET-README.md").read_bytes())
(out / "source-freeze.json").write_bytes((root / "publish-source-freeze.json").read_bytes())
print(json.dumps(receipt, indent=2))
