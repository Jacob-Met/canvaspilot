# Assignment submission visibility: author receiving packet

This packet accompanies the bounded CanvasPilot assignment-list contribution
claimed in [HAMON #140, comment6059762346](https://github.com/Jacob-Met/hamon/issues/140#issuecomment-6059762346).
It preserves source, native commands, original failures, actual CLI/MCP outputs
and the current-main composition. It is local source qualification until a
publisher binds it to an actual commit.

## Product result

The existing assignment reader already asks Canvas for the requesting user's
submission. The contribution retains eight supplied fields in a compact
`submission` object and reports malformed optional values through
`submission_warnings`. This reaches the existing assignment and sync Python,
CLI and MCP consumers without a new request.

The outer `has_submitted_submissions` remains Canvas's aggregate signal about
submissions by any student. An absent/null current-user submission remains
unknown; the code does not infer missing work, workflow, deadline policy, grades
or a required action. Explicit false/null/zero and future string labels remain
available. The existing raw self-submission reader is unchanged.

The source guide cites the official Instructure Assignments and Submissions
documentation and shows existing CLI/MCP selection options.

## Exact source stages

| Directory | Source represented |
| --- | --- |
| `baseline/` | Exact native inputs from main `55fe1e0a3c4ad85e1065f295e49d44722c3be32b`, tree `7c1bd0a858a3fda82a4d5e69076801ae65a73ea1`. |
| `candidate/` | Original six-file feature contribution over that baseline. |
| `current-base/` | Exact native inputs from main `ca2318fe7c56d2e4ec1b363ff8a945ab78bf4a0c`, tree `ea775021cbf300367369a169f584f1092347cf5c`, including the actual PR35 pagination merge. |
| `current-candidate/` | The same five feature/test/guide files plus the README insertion composed onto the current owner's document. This stage was natively executed. |
| `publish-candidate/` | Current composition with one extra final LF removed from the helper, process test and guide. Both Python ASTs and every other byte are unchanged. |

These are native source subsets: 39 original-base inputs and 46 current-base
inputs. They contain the package, applicable tests/fixtures, scripts, dependency
manifest, README and CI entrypoint. They do not copy all historical repository
evidence. Each materialized source body was hashed against its actual Git tree.

`publish-source-freeze.json` is the final six-file publication manifest.
`publish.patch` applies to exact current main and passes
`git apply --check --whitespace=error-all` with exit0. The original EOF whitespace
failure and pre-correction source are preserved; no native test is relabeled as
an execution of different bytes.

Only `list_assignments` changes among the 40 methods in `CanvasAPI`. The API
module's AST outside that method and its new import is identical. Every other
existing package file remains byte-identical to its receiving parent, including
the current owner's client, broker, CLI, MCP, calendar, module and feedback files.

## Executed native evidence

| Stage | Result | Qualification boundary |
| --- | --- | --- |
| Original existing suite | 414 passed | Exact original main, before contribution. |
| Original public-API witness | 1 expected failure | The existing include-submission request is verified, then the output lacks `submission`. |
| Original process receiver | 5 expected failures, 3 passed | Real CLI/MCP successes omit the new fields; inherited later-page failure controls still pass. |
| Targeted candidate receiver | 33 passed | 25 public-API semantic cases and 8 actual process cases. |
| Full original-base candidate suite | 447 passed | All 414 inherited methods plus those 33; zero errors or skips. |
| Current-main composition receiver | 8 passed | The changed pagination dependency, actual API/CLI/MCP processes and 28 recorded GETs. |

The full 447-test result belongs to the earlier base. The eight-method current
composition result is a separate affected-boundary check; a complete hosted run
of the eventual current-base publication is still required.

For each eight-case process run, native HTTP serves synthetic assignments over
two pages and two courses. Six CLI processes and three MCP stdio sessions are
used. MCP initialization and the existing tool inventory are read before tool
calls. Both the direct API caller and child processes restrict connections to
the disposable loopback endpoint. No real Canvas account, browser or installed
broker is used.

The checks retain zero attempts, submitted timestamps with offsets, explicit
false and null, current-user changes with an unchanged aggregate flag, malformed
optional values, and missing submission objects. They also preserve nonzero CLI
failure with empty stdout, MCP tool errors for HTTP403/500, and sync's per-course
soft failure while another course remains usable.

`behavior-comparison.json` and `current-main-behavior-comparison.json` compare
the retained results without another native run. Recorded methods, paths,
decoded queries and synthetic-token matches remain equal; this is not a TCP
byte or header-order comparison. Original assignment output values, CLI statuses
and MCP error flags are preserved. Ephemeral error URL ports are normalized only
for the comparison, while all raw outputs remain unchanged.

## Reproduction and independent receiving

`runtime.json` identifies the actual read-only borrowed Python3.12.14 runtime,
httpx0.28.1, MCP2.3.0, pydantic2.13.5 and pytest9.1.1. Dependencies were already
installed; no package or environment was changed. Bytecode, pytest cache and
automatic plugin loading were disabled, and all temporary paths were owned.

`run_pytest.py` retains the actual invocation setup. Each
`evidence/*/receipt.json` records its command, source hashes, exit code and
case outcomes. The same receiver source is in `receiving/` and the tested
candidate's `tests/`; final process-test formatting differs only by the proved
extra EOF LF. A compatible existing project Python can execute these native
tests using the archived source as `PYTHONPATH` and
`CANVAS_SUBMISSION_SOURCE`; no fixture account is needed.

Engine's independent source review and distinct actual session-broker/CLI
receiving are a separate appendix. They are not included in the author's
447-method or PAT-process counts.

Local Ruff was not found in the three explicitly checked existing locations.
No installation or general environment search was attempted. Hosted lint and
the eventual full published-composition CI remain publication gates.

Read-only source recovery initially used fourteen blob IDs as contents refs,
which returned404 without a commit. Corrected reads used the exact commit and
matched every tree blob; `source-fetch-errors.json` preserves that lookup
correction separately from the product failures.

No source branch, feature PR, merge, live account action or deployment is
established by this archive itself. The publisher must preserve the actual
receiving parent's unowned tree and bind the final source and packet to the
published commit.
