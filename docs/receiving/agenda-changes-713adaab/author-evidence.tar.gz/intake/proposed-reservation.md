## Saved agenda changes — chatgpt:/root/mac_execution (713adaab)

A learner reviewing two deliberately selected saved `canvaspilot.course-agenda.v1` reports needs a local account of changed record fields, unchanged records, one-sided presence and repeated-ID ambiguity. Current main `29395684139e9c0cf71d037d32d503411b1e7cd0` / tree `823cd71973bef8faf0cab92782b32c6dc6170beb` has the agenda producer and offline viewer, but no cross-document change consumer.

This reservation is five additive maintained paths only:

- `src/canvaspilot/agenda_changes.py`
- `src/canvaspilot/agenda_changes_cli.py`
- `tests/test_agenda_changes.py`
- `tests/test_agenda_changes_cli.py`
- `docs/agenda-changes.md`

Owned evidence belongs under `docs/receiving/agenda-changes-713adaab/`. Existing producer, API, common CLI, viewer, package initializer, client, broker, authentication, dependencies, README and workflows remain unchanged. #55 and #66 retain producer/viewer ownership; #101 and its recipients retain interval-overlap work.

### Frozen behavior before candidate

The core accepts two bounded strict-JSON byte documents with exact schema/version, identical canonical ordered course/date selection, coherent counts, valid original occurrence indices and course/typed-ID bindings. It preserves full original reports and same-read digests. It compares recorded values, without recomputing timestamps or claiming original producer execution from a file.

Keys use exact kind, course ID, JSON ID type and value. A unique key on both sides is unchanged or changed by full literal record values; field changes distinguish missing from present null/empty/false/zero. A key present on one side is before-only or after-only, which is not a deletion/creation claim. Repeated IDs on either side produce an explicit ambiguous group with every original occurrence; they are never paired by position/title/override. Unique record reordering cannot manufacture changes. Output is deterministic and complete or refused.

Public core: `compare_saved_agendas(before: bytes, after: bytes)`. Offline checkout command:

```text
python -B src/canvaspilot/agenda_changes_cli.py --before OLD.json --after NEW.json [--format text|json]
```

The standard package-module route is also intended with the repository's already-required dependencies. Actual Mac qualification will distinguish direct-file/stdlib receiving from full package import; no dependency installation, fake namespace or source rewrite will be used to claim that gate.

Both inputs are fully admitted and output serialized before success stdout. No output destination is written. Input limits are 8 MiB each, 4,096 occurrences and 64 nested containers; complete output limit is 32 MiB. Human text quotes artifact controls safely. No provider/account/host/capture identity is invented: the producer does not retain those fields. Before/after are caller-selected document roles, not proof of chronology, freshness or complete obligations.

### Original artifact and ownership evidence

Contract `28a972a298ca4b1e6094f266fccd958651787f3d847770bc9187bb86a84f82ee` and expected cases `68a6cc3e97f439dfe68bef2ca6beec29a4b744786000db5b1381dd5d1c49cb2d` were frozen before candidate source. Historical actual exit-0 agenda stdout artifacts are retained exactly from #55's public peer archive `9358d7746c10a17e73fc34044c198250f635d3e6`; its producer bytes equal current `82ab4fa8f9b92b8d9e5d4c74962d138e1d882ebd` / SHA256 `cd9d9e027393ce21cff0b4d0a13098dca3a906af3e9803201655bca40d3c3fda`. Newly authored changed/reordered/typed-ID derivatives are labeled separately from those historical executions.

The complete current tree, all33 open issue/PR records, targeted all-state agenda/comparison searches and #101's complete current handoff were inspected. No overlapping change-review claim was found; coverage is bounded, not a global native lease assertion. The complete tree contains no AGENTS instruction. Both current workflows (`ef7bbebe` CI and `a06b862c` agenda browser) lack issue/comment events.

This is an isolated native source contribution under the existing product mandate. No live Canvas/account/browser, private data, hosted source ref, PR, merge, Actions, install, service, GoalStore or Conscience mutation is part of this reservation.
