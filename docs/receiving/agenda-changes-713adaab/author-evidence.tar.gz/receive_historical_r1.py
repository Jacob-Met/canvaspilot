from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/Users/me/Developer/canvaspilot-agenda-changes-20261009-713adaab')
CANDIDATE=ROOT/'candidate-r2'
RUN=ROOT/'historical-consumer-r1'
EXE='/Users/me/Developer/capturesuite-analysis-provenance-20261008/.venv-analysis/bin/python'
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mtime_ns':p.stat().st_mtime_ns}
def strict(raw):
 return json.loads(raw,parse_constant=lambda v: (_ for _ in ()).throw(ValueError(v)))
def exact(a,b):
 return json.dumps(a,sort_keys=True,ensure_ascii=True,separators=(',',':'))==json.dumps(b,sort_keys=True,ensure_ascii=True,separators=(',',':'))
assert not RUN.exists()
assert shutil.disk_usage(ROOT).free>=128*1024**2+5*1024**2
freeze=strict((ROOT/'candidate-r2-source.json').read_bytes())
for name,expected in freeze['paths'].items():
 actual=pin(CANDIDATE/name);assert all(actual[k]==expected[k] for k in actual)
assert pin(ROOT/'EXPECTED.json')['sha256']=='68a6cc3e97f439dfe68bef2ca6beec29a4b744786000db5b1381dd5d1c49cb2d'
expected=strict((ROOT/'EXPECTED.json').read_bytes())
guard=[p for folder in ('candidate-r1','candidate-r2','original','historical','fixtures') for p in (ROOT/folder).rglob('*') if p.is_file()]
guard += [ROOT/n for n in ('CONTRACT.json','EXPECTED.json','SEMANTIC_CLARIFICATION.json','OUTPUT_SHAPE.json')]
before={str(p.relative_to(ROOT)):pin(p) for p in guard}
RUN.mkdir(mode=0o700)
records=[];checks=[]
for case in expected['cases']:
 argv=[EXE,'-B',str(CANDIDATE/'src/canvaspilot/agenda_changes_cli.py'),'--before',str(ROOT/'fixtures'/case['before']),'--after',str(ROOT/'fixtures'/case['after']),'--format','json']
 tick=time.monotonic();cp=subprocess.run(argv,stdin=subprocess.DEVNULL,capture_output=True,timeout=15,check=False,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 (RUN/(case['name']+'.stdout')).write_bytes(cp.stdout);(RUN/(case['name']+'.stderr')).write_bytes(cp.stderr)
 row={'name':case['name'],'argv':argv,'exit':cp.returncode,'elapsed_seconds':time.monotonic()-tick,'stdout':pin(RUN/(case['name']+'.stdout')),'stderr':pin(RUN/(case['name']+'.stderr'))}
 records.append(row)
 assert cp.returncode==0 and cp.stderr==b'',row
 result=strict(cp.stdout)
 assert result['schema']=='canvaspilot.agenda-changes.v1'
 assert {k:result['counts'][k] for k in case['counts']}==case['counts']
 if 'document_equal' in case:assert result['document_equal'] is case['document_equal']
 for side in ('before','after'):
  raw=(ROOT/'fixtures'/case[side]).read_bytes()
  assert exact(result['inputs'][side]['report'],strict(raw))
  assert result['inputs'][side]['bytes']==len(raw)
  assert result['inputs'][side]['sha256']==hashlib.sha256(raw).hexdigest()
  assert result['counts'][side+'_occurrences']==strict(raw)['counts']['total']
 if 'ambiguous_occurrences' in case:
  ambiguous=[g for g in result['groups'] if g['classification']=='ambiguous'];assert len(ambiguous)==1
  assert [len(ambiguous[0][s]) for s in ('before','after')]==case['ambiguous_occurrences']
  assert ambiguous[0]['field_changes']==[]
 if 'changed_identity' in case:
  changed=[g for g in result['groups'] if g['classification']=='changed'];assert len(changed)==1
  assert exact(changed[0]['identity'],case['changed_identity'])
 if 'changed_fields' in case:
  fields=changed[0]['field_changes'];assert [c['field'] for c in fields]==case['changed_fields']
  keyed={c['field']:c for c in fields};w=case['state_witnesses']
  for name in ('description','location'):assert [keyed[name][s]['state'] for s in ('before','after')]==w[name]
  assert keyed['location']['after']['value'] is None
  assert [keyed['hidden'][s]['value'] for s in ('before','after')]==w['hidden_values']
 checks.append({'case':case['name'],'status':'passed','counts':result['counts'],'document_equal':result['document_equal']})
# One actual readable report over the same explicitly authored change artifact.
argv=[EXE,'-B',str(CANDIDATE/'src/canvaspilot/agenda_changes_cli.py'),'--before',str(ROOT/'fixtures/historical-complete.json'),'--after',str(ROOT/'fixtures/authored-field-changes.json')]
cp=subprocess.run(argv,stdin=subprocess.DEVNULL,capture_output=True,timeout=15,check=False,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
(RUN/'readable-changes.stdout').write_bytes(cp.stdout);(RUN/'readable-changes.stderr').write_bytes(cp.stderr)
assert cp.returncode==0 and cp.stderr==b''
text=cp.stdout.decode('utf-8');assert 'Recorded agenda changes' in text
for field in ('description','hidden','location','notes','title'):assert 'Field '+json.dumps(field)+':' in text
assert '"state": "missing"' in text and '"value": null' in text
assert 'One-sided presence does not establish creation, deletion or changed access in Canvas.' in text
assert all(ord(c)>=32 or c in '\n\t' for c in text)
records.append({'name':'readable-changes','argv':argv,'exit':cp.returncode,'stdout':pin(RUN/'readable-changes.stdout'),'stderr':pin(RUN/'readable-changes.stderr')})
after={str(p.relative_to(ROOT)):pin(p) for p in guard};assert before==after
receipt={'schema':'agenda-changes-actual-saved-artifact-consumer/1','created_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'preimplementation_expected':pin(ROOT/'EXPECTED.json'),'source_freeze':pin(ROOT/'candidate-r2-source.json'),'driver':pin(Path(__file__)),'checks':checks,'actual_cli_calls':records,'before':before,'after':after,'all_source_inputs_unchanged':before==after,'scope':['Six preimplementation artifact cases and one readable-text CLI call.','Historical producer stdout was consumed anew; no new producer/live Canvas call.','Direct-file CLI with actual standard-library imports; installed package/module receiving remains unqualified.']}
raw=(json.dumps(receipt,indent=2)+'\n').encode();(RUN/'receipt.json').write_bytes(raw)
print(json.dumps({'cases':len(checks),'actual_cli_calls':len(records),'all_passed':True,'unchanged':before==after,'receipt':pin(RUN/'receipt.json')}))
