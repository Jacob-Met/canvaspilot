CONTRACT_JSON="{\"schema\":\"canvaspilot-saved-agenda-changes-contract/1\",\"owner\":\"chatgpt:/root/mac_execution\",\"beneficiary\":\"A learner reviewing what differs between two deliberately selected saved course-agenda reports before planning the next study session.\",\"base\":{\"commit\":\"29395684139e9c0cf71d037d32d503411b1e7cd0\",\"tree\":\"823cd71973bef8faf0cab92782b32c6dc6170beb\",\"producer_git_blob\":\"82ab4fa8f9b92b8d9e5d4c74962d138e1d882ebd\",\"producer_sha256\":\"cd9d9e027393ce21cff0b4d0a13098dca3a906af3e9803201655bca40d3c3fda\"},\"maintained_paths\":[\"src/canvaspilot/agenda_changes.py\",\"src/canvaspilot/agenda_changes_cli.py\",\"tests/test_agenda_changes.py\",\"tests/test_agenda_changes_cli.py\",\"docs/agenda-changes.md\"],\"evidence_prefix\":\"docs/receiving/agenda-changes-713adaab/\",\"api\":\"compare_saved_agendas(before: bytes, after: bytes) -> dict; render_agenda_changes(report, *, format='text'|'json') -> UTF-8 bytes\",\"cli\":{\"module\":\"python -B -m canvaspilot.agenda_changes_cli --before OLD.json --after NEW.json [--format text|json]\",\"offline_checkout\":\"python -B src/canvaspilot/agenda_changes_cli.py --before OLD.json --after NEW.json [--format text|json]\",\"default\":\"text\",\"success\":0,\"usage_refusal\":2,\"input_or_output_refusal\":1,\"report_output\":\"stdout only, no created output files; finish both complete input admissions and bounded serialization before first success output\",\"limits\":\"OS stream failure may occur after accepted bytes; no exact exit1 promise for interpreter shutdown flush errors.\"},\"import_closure\":{\"core\":\"Python3.11+ standard library only; no original producer import, provider, HTTP, browser or authentication calls.\",\"direct_file_cli\":\"standard library plus unchanged sibling new agenda_changes module; no fake canvaspilot namespace\",\"normal_module_cli\":\"existing canvaspilot.__init__/api/bundle/client import closure and declared installed dependencies remain required and unchanged; qualify separately when real environment is available\"},\"admission\":[\"Each argument is an explicit bounded strict UTF-8 JSON byte document, no BOM, duplicate keys or nonfinite numbers; root schema exactly canvaspilot.course-agenda.v1.\",\"Require exact v1 root keys schema/selection/collection_counts/counts/timed/all_day/timing_unavailable; preserve all arbitrary record members.\",\"Selection has exact course_ids/context_codes/start_date/end_date keys. Course IDs are canonical positive ASCII decimal strings, distinct, one through ten. Contexts exactly course_ plus corresponding IDs. Valid ISO YYYY-MM-DD dates, start<=end. Both selections must agree exactly, including ordered course IDs/date interval; a different selection is refused.\",\"Counts and indices must be nonnegative JSON integers, never booleans. Report totals/per-group counts/collection counts must agree with actual occurrences.\",\"Each occurrence carries exact kind event or assignment; supplied canonical course_id in selection; source exactly collection/index, with collection==kind. Each collection's occurrence indices are unique contiguous0..n-1, independent of grouping order.\",\"Occurrence keys are kind/course_id/source/record plus optional timing_issue only. Record must be an object with supplied int (not bool) or nonblank string id; IDs keep JSON type and value. Validate record context binding with same native documented direct course/effective section relationships and optional assignment.course_id agreement.\",\"Retain timing groups/order and timing_issue literally as recorded metadata; do not recalculate timestamps, sort or reclassify timing. Require timing_issue object with string field/reason for timing_unavailable and absent for other groups. This is structural saved-report admission, not proof the producer executed or its timing assessment is authentic.\",\"Record nesting is at most64 containers; at most4096 occurrences per report; each input at most8MiB and complete output at most32MiB. Refuse whole result on excess; limits are application bounds, not whole-process memory guarantees.\",\"CLI reads only opened regular files (symlink to regular file allowed), with a nonblocking open before fstat so FIFO/device inputs cannot hang ordinary read admission. Read at most limit+1 bytes. Same-read byte hashes are retained; no atomic two-file snapshot claim.\"],\"comparison\":[\"Key is exact tuple(kind, course_id, record.id JSON type, record.id value). Numeric1 and string'1' never match. No timestamp/title/fuzzy identity matching.\",\"For a key with >1 occurrence on either side, emit one ambiguous group containing every before/after occurrence in collection/source-index order, even if the other side is empty. Never pair duplicate IDs by position, title, override or apparently equal record.\",\"For a unique key present only before or after, emit before_only or after_only; these mean recorded presence only, not deleted/new/inaccessible Canvas object.\",\"For one occurrence on each side, compare full record values recursively with exact JSON scalar types and values, object-key order ignored, list order retained. Emit unchanged or changed. Source index/group placement alone never manufactures record changes.\",\"Changed keys expose every changed top-level record field in Unicode-codepoint field-name order. Each side is {state:'missing'} or {state:'present',value:EXACT}; null/empty/false/zero and nested arrays/objects remain literal, not collapsed.\",\"Emit all groups, including unchanged and ambiguous. Deterministic group order: first occurrence of each key in before collection/source-index order (event then assignment), followed by keys first seen only after in the same order.\",\"Retain complete admitted original before/after reports in result plus raw input byte counts/SHA256 and exact selection. Per-group references contain original group name, source and complete occurrence. Include counts by classification and before/after occurrence totals.\",\"An identical complete report may still have ambiguous repeated IDs: document_equal is true, unique rows unchanged, duplicate group remains ambiguous. Reordering only unique/duplicate occurrence source positions does not claim unique record changes.\",\"Readable text uses JSON-quoted controls/strings, gives selection/counts/limits/identity and before->after field values; never emits unescaped artifact control characters.\"],\"output_schema\":\"canvaspilot.agenda-changes.v1\",\"provenance_limits\":[\"The original producer lacks host/account/capture-time identity. The tool cannot establish same provider/account, recency, a chronological relationship or complete course obligations; before/after are caller-assigned document roles.\",\"No live Canvas reads, hidden-account discovery, deletion/freshness/attendance/grade/availability inference, recurrence expansion, overlap analysis, remote mutation, installs or browser.\",\"Historical retained real-producer artifacts are distinguished from newly authored derivatives; no new producer execution is implied.\",\"Existing #55/#66 producer/viewer, #101 overlap consumer/receivers and all other current owners remain untouched.\"],\"preimplementation_cases\":[\"Exact historical complete report versus itself:10 occurrences each,8 unchanged unique keys,1 ambiguous key with2+2 occurrences; document_equal true.\",\"Exact historical empty report versus itself:all classification/occurrence counts zero, document_equal true.\",\"Historical complete versus historical empty:8 before_only unique keys plus1 ambiguous2+0 group; no deletion claim.\",\"Historical complete versus explicit source-index permutation:8 unique unchanged,1 ambiguous; no inferred pair for reordered duplicate overrides.\",\"Hand-derived edits to unique title/null/missing/zero/false/nested text retain complete old/new record values and sorted changed fields.\",\"Typed identity1 versus string'1' remains separate keys; same ID across course or kind remains separate.\",\"Different ordered selection/date interval, wrong schema, false counts, duplicate/missing indices, foreign context, booleanID and malformed nested JSON refuse before output.\",\"Later malformed second input, strict UTF8/duplicate-key/nonfinite/bounds cases yield no success stdout.\",\"Stock direct-file CLI with actual regular/spaced/Unicode path inputs, missing/nonregular input and actual stdout/stderr streams; original package-module CLI remains a separately held dependency gate.\"],\"candidate_written\":false}"
from pathlib import Path
from copy import deepcopy
from datetime import datetime,timezone
import json,hashlib,zipfile,shutil
ROOT=Path('/Users/me/Developer/canvaspilot-agenda-changes-20261009-713adaab')
assert shutil.disk_usage(ROOT).free>=128*1024**2+5*1024**2
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,x):
 put(p,(json.dumps(x,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode())
def put(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b)}
contract=json.loads(CONTRACT_JSON)
with zipfile.ZipFile(ROOT/'original/peer-evidence.zip') as z:
 manifest=json.loads(z.read('member-manifest.json'))
 selected={}
 for name,label in [('runs/candidate-rfc-v1-tests/cases/cli-complete.json','complete'),('runs/candidate-rfc-v1-tests/cases/cli-empty.json','empty')]:
  raw=z.read(name); expected=manifest[name]
  assert expected['bytes']==len(raw) and expected['sha256']==sha(raw)
  row=json.loads(raw);assert row['returncode']==0 and row['stderr']==''
  assert row['source']['src/canvaspilot/agenda.py']=='cd9d9e027393ce21cff0b4d0a13098dca3a906af3e9803201655bca40d3c3fda'
  put(ROOT/'historical'/('%s-process.json'%label),raw)
  b=row['stdout'].encode()
  put(ROOT/'fixtures'/('historical-%s.json'%label),b)
  selected[label]={'member':name,'process':pin(ROOT/'historical'/('%s-process.json'%label)),'stdout':pin(ROOT/'fixtures'/('historical-%s.json'%label)),
   'historical_returncode':row['returncode'],'historical_args':row['args'],'historical_source_map':row['source'],
   'new_producer_execution':False}
 original=z.read('received-source/candidate-rfc/src/canvaspilot/agenda.py')
 assert original==(ROOT/'original/src/canvaspilot/agenda.py').read_bytes()
before=json.loads((ROOT/'fixtures/historical-complete.json').read_text())
permuted=deepcopy(before)
for group in ('timed','all_day','timing_unavailable'):
 for e in permuted[group]:
  e['source']['index']=permuted['collection_counts'][e['kind']]-1-e['source']['index']
dump(ROOT/'fixtures/authored-reordered.json',permuted)
changed=deepcopy(before)
for group in ('timed','all_day','timing_unavailable'):
 for e in changed[group]:
  if e['kind']=='event' and type(e['record']['id']) is int and e['record']['id']==701:
   record=e['record']
   record['title']='Studio moved — inspect the recorded text'
   del record['description']
   record['hidden']=False
   record['location']=None
   record['notes']={'rubric':[0,False,None,'']}
dump(ROOT/'fixtures/authored-field-changes.json',changed)
typed=deepcopy(json.loads((ROOT/'fixtures/historical-empty.json').read_text()))
typed['collection_counts']={'event':3,'assignment':1}
typed['counts']={'total':4,'timed':0,'all_day':0,'timing_unavailable':4}
for kind,course,idvalue,index in [('event','23',1,0),('event','23','1',1),('event','61',1,2),('assignment','23',1,0)]:
 typed['timing_unavailable'].append({'kind':kind,'course_id':course,'source':{'collection':kind,'index':index},
 'record':{'id':idvalue,'context_code':'course_'+course,'title':'same visible title'},
 'timing_issue':{'field':'all_day','reason':'expected an explicit boolean'}})
dump(ROOT/'fixtures/authored-typed-before.json',typed)
typed_after=deepcopy(typed)
typed_after['timing_unavailable'][0]['record']['title']='Integer identity changed only'
dump(ROOT/'fixtures/authored-typed-after.json',typed_after)
expectations={
 'schema':'agenda-changes-preimplementation-expectations/1',
 'derived_before_candidate':True,'candidate_exists':False,
 'historical_producer':selected,'historical_producer_module_equals_current':True,
 'cases':[
 {'name':'complete-self','before':'historical-complete.json','after':'historical-complete.json','document_equal':True,
  'counts':{'unchanged':8,'changed':0,'before_only':0,'after_only':0,'ambiguous':1},'ambiguous_occurrences':[2,2]},
 {'name':'empty-self','before':'historical-empty.json','after':'historical-empty.json','document_equal':True,
  'counts':{'unchanged':0,'changed':0,'before_only':0,'after_only':0,'ambiguous':0}},
 {'name':'complete-to-empty','before':'historical-complete.json','after':'historical-empty.json','document_equal':False,
  'counts':{'unchanged':0,'changed':0,'before_only':8,'after_only':0,'ambiguous':1},'ambiguous_occurrences':[2,0]},
 {'name':'source-order-change','before':'historical-complete.json','after':'authored-reordered.json','document_equal':False,
  'counts':{'unchanged':8,'changed':0,'before_only':0,'after_only':0,'ambiguous':1},'ambiguous_occurrences':[2,2]},
 {'name':'literal-record-fields','before':'historical-complete.json','after':'authored-field-changes.json',
  'counts':{'unchanged':7,'changed':1,'before_only':0,'after_only':0,'ambiguous':1},
  'changed_identity':{'kind':'event','course_id':'23','id_type':'integer','id':701},
  'changed_fields':['description','hidden','location','notes','title'],
  'state_witnesses':{'description':['present','missing'],'location':['missing','present'],'location_after_value':None,'hidden_values':[True,False]}},
 {'name':'typed-identity','before':'authored-typed-before.json','after':'authored-typed-after.json',
  'counts':{'unchanged':3,'changed':1,'before_only':0,'after_only':0,'ambiguous':0},
  'changed_identity':{'kind':'event','course_id':'23','id_type':'integer','id':1}}
 ],
 'limits':'These exact retained historical CLI outputs are actual artifacts. Edited/reordered/typed variants are explicitly newly authored derivatives, not claimed producer runs.',
 'refusal_cases_frozen_in_contract':contract['preimplementation_cases'][6:]
}
dump(ROOT/'CONTRACT.json',contract)
dump(ROOT/'EXPECTED.json',expectations)
receipt={'schema':'agenda-changes-original-artifact-freeze/1','created_utc':datetime.now(timezone.utc).isoformat(),
 'base':contract['base'],'contract':pin(ROOT/'CONTRACT.json'),'expectations':pin(ROOT/'EXPECTED.json'),
 'fixtures':{str(p.relative_to(ROOT)):pin(p) for p in sorted((ROOT/'fixtures').glob('*.json'))},
 'historical_process_receipts':{str(p.relative_to(ROOT)):pin(p) for p in sorted((ROOT/'historical').glob('*.json'))},
 'new_product_or_producer_runs':0,'candidate_written':False,
 'dependency_boundary':'Known Mac analysis3.12.8 and Homebrew3.12/3.13 lack httpx/mcp/pydantic. No install, stub or producer rewrite. Historical source-map match supplies actual original artifact boundary; normal package CLI remains separately held.'}
dump(ROOT/'intake/original-artifact-freeze.json',receipt)
print(json.dumps({'contract':receipt['contract'],'expectations':receipt['expectations'],'freeze':pin(ROOT/'intake/original-artifact-freeze.json'),
 'producer_sha256':sha(original),'fixtures':receipt['fixtures'],'payload_bytes':sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())}))
