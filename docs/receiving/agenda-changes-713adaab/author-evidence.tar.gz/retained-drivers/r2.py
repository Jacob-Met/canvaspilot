from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/Users/me/Developer/canvaspilot-agenda-changes-20261009-713adaab')
CANDIDATE=ROOT/'candidate-r2'
RUN=ROOT/'author-r2'
assert not RUN.exists()
assert shutil.disk_usage(ROOT).free>=128*1024**2+5*1024**2
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mtime_ns':p.stat().st_mtime_ns}
freeze=json.loads((ROOT/'candidate-r2-source.json').read_text())
for path,x in freeze['paths'].items():
 actual=pin(CANDIDATE/path)
 assert all(actual[k]==x[k] for k in actual)
source=json.loads((ROOT/'intake/current-source.json').read_text())
for x in source['files']:
 assert (ROOT/'original'/x['path']).read_bytes()==x['content'].encode()
guard=list(CANDIDATE.rglob('*'))+list((ROOT/'original').rglob('*'))+list((ROOT/'fixtures').rglob('*'))
guard=[p for p in guard if p.is_file()]
before={str(p):pin(p) for p in guard}
RUN.mkdir(mode=0o700);(RUN/'tmp').mkdir()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',TMPDIR=str(RUN/'tmp'))
exe='/Users/me/Developer/capturesuite-analysis-provenance-20261008/.venv-analysis/bin/python'
commands=[
 ('ruff',[exe,'-B','-m','ruff','check','--no-cache','src/canvaspilot/agenda_changes.py','src/canvaspilot/agenda_changes_cli.py','tests/test_agenda_changes.py','tests/test_agenda_changes_cli.py']),
 ('pytest',[exe,'-B','-m','pytest','-q','-p','no:cacheprovider','tests/test_agenda_changes.py','tests/test_agenda_changes_cli.py','--junitxml='+str(RUN/'junit.xml'),'--basetemp='+str(RUN/'pytest-tmp')])
]
records=[]
for name,cmd in commands:
 tick=time.monotonic()
 with (RUN/(name+'.stdout')).open('xb') as out,(RUN/(name+'.stderr')).open('xb') as err:
  try:
   result=subprocess.run(cmd,cwd=CANDIDATE,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=120)
   rec={'name':name,'argv':cmd,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-tick}
  except subprocess.TimeoutExpired:
   rec={'name':name,'argv':cmd,'timeout':True,'elapsed_seconds':time.monotonic()-tick}
 rec['stdout']=pin(RUN/(name+'.stdout'));rec['stderr']=pin(RUN/(name+'.stderr'))
 records.append(rec)
after={str(p):pin(p) for p in guard}
receipt={'schema':'agenda-changes-native-author-gate/1','created_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'source_freeze':pin(ROOT/'candidate-r2-source.json'),'runs':records,'before':before,'after':after,'source_inputs_unchanged':before==after,'boundaries':['Exact-file core and actual direct-file CLI children only.','Normal package/module/import, inherited full suite, live provider and browser are not run.']}
(ROOT/'author-r2/receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'runs':records,'unchanged':before==after,'receipt':pin(RUN/'receipt.json')}))
