"""Independent read-only source identity verification; no product imports or execution."""
from pathlib import Path
import hashlib, json, os, stat, subprocess, difflib, datetime
B=Path('/home/jacob/canvas-page-comparison-81ba1ed0179c')
S=B/'source'
R=Path('/home/jacob/canvas-comparison-source-review-81ba1ed0179c')
BASE='a317417a8a2c39fb23256102904c24fba16a969a'
EXPECTED={
 'evidence/contract-before-candidate.json':'d60ef8e74190a08c709b95704956a9ccdc781b51463acb1b902725c0566ae342',
 'evidence/contract-clarification-before-candidate.json':'aebb6b4b72c8cef48480c4daecaaa86597fe1b3a0cfb160ddd046a90335d67fb',
 'evidence/source-freeze-r1.json':'d86096b6066c64f76162c28e434570c7290969d7eb14bbf975a42a50377373cc',
 'evidence/final-source.diff':'033f2ac539946d9c677b874bd2957f2b2d1f184267c96f36de86cca0e1919422'}
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def read(p):
 st=p.lstat();assert stat.S_ISREG(st.st_mode)
 b=p.read_bytes();assert (st.st_size,st.st_ino,st.st_mtime_ns)==(p.stat().st_size,p.stat().st_ino,p.stat().st_mtime_ns)
 return b
def put(n,b):
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b
 return {'path':n,'bytes':len(b),'sha256':sha(b)}
def git(*args):
 return subprocess.run(['git','-C',str(S),*args],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},capture_output=True,check=True,timeout=30).stdout
head=git('rev-parse','HEAD').decode().strip()
tree={}
for row in git('ls-tree','-rz',BASE).split(b'\0'):
 if not row:continue
 h,n=row.split(b'\t',1);mode,kind,oid=h.decode().split()
 assert kind=='blob'
 tree[n.decode()]={'mode':mode,'gitBlob':oid}
copied=[]
for n,h in EXPECTED.items():
 b=read(B/n);assert sha(b)==h,n;copied.append(put('inputs/'+n,b))
freeze=json.loads(read(B/'evidence/source-freeze-r1.json'))
assert freeze['baseHead']==BASE
changed={x['path'] for x in freeze['files']}
assert changed=={'src/canvaspilot/cli.py','README.md','src/canvaspilot/page_revision_comparison.py','tests/test_page_revision_comparison.py','tests/test_page_revision_comparison_process.py','docs/page-revision-comparison.md'}
current={}
for row in freeze['files']:
 p=S/row['path'];b=read(p)
 assert len(b)==row['bytes'] and sha(b)==row['sha256']
 assert ('100755' if p.stat().st_mode & 0o111 else '100644')==row['mode']
 current[row['path']]=b
 copied.append(put('candidate/'+row['path'],b))
preserved=[]
for n,row in tree.items():
 if n in changed:continue
 p=S/n;st=p.lstat()
 if row['mode']=='120000':
  assert stat.S_ISLNK(st.st_mode);b=os.readlink(p).encode();mode='120000'
 else:
  assert stat.S_ISREG(st.st_mode);b=read(p);mode='100755' if st.st_mode&0o111 else '100644'
 assert mode==row['mode'] and blob(b)==row['gitBlob'],n
 preserved.append({'path':n,'bytes':len(b),'sha256':sha(b),**row})
assert len(preserved)==1703
shared=[]
for n in ('src/canvaspilot/cli.py','README.md'):
 old=git('cat-file','blob',tree[n]['gitBlob']);new=current[n]
 assert blob(old)==tree[n]['gitBlob']
 aa=old.splitlines(keepends=True);bb=new.splitlines(keepends=True)
 changes=[];recovered=[]
 for tag,i,j,x,y in difflib.SequenceMatcher(None,aa,bb,autojunk=False).get_opcodes():
  assert tag in ('equal','insert'),(n,tag)
  if tag=='equal':recovered.extend(bb[x:y])
  else:changes.append({'newLineStart':x+1,'newLineEnd':y,'bytes':sum(map(len,bb[x:y])),'sha256':sha(b''.join(bb[x:y]))})
 assert b''.join(recovered)==old
 shared.append({'path':n,'originalGitBlob':tree[n]['gitBlob'],'originalSha256':sha(old),'currentSha256':sha(new),'insertions':changes,'inverseRecoversOriginalExactly':True})
 copied.append(put('original/'+n,old))
contract=json.loads(read(B/'evidence/contract-before-candidate.json'))
originals=[]
for row in contract['originalPins']:
 n=row['path'];b=git('cat-file','blob',tree[n]['gitBlob'])
 assert len(b)==row['bytes'] and sha(b)==row['sha256'] and blob(b)==row['gitBlob']
 originals.append(row)
 if n not in ('src/canvaspilot/cli.py','README.md'):copied.append(put('original/'+n,b))
new_paths=changed-set(tree)
assert len(new_paths)==4
# Reconstruct and compare the complete six-file authored diff independently.
diff=''
for row in freeze['files']:
 n=row['path'];old=git('cat-file','blob',tree[n]['gitBlob']).decode() if n in tree else ''
 diff+=''.join(difflib.unified_diff(old.splitlines(keepends=True),current[n].decode().splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n))
assert diff.encode()==read(B/'evidence/final-source.diff')
for row in freeze['files']:assert read(S/row['path'])==current[row['path']]
for row in preserved:
 p=S/row['path'];b=os.readlink(p).encode() if row['mode']=='120000' else read(p)
 assert sha(b)==row['sha256']
assert git('rev-parse','HEAD').decode().strip()==head
result={'schema':'canvas.page-comparison.independent-source-verification.v1','reviewer':'estate-81ba1ed0179c/estate_coordination','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRoot':str(S),'headObserved':head,'baseline':BASE,'baselineTree':git('rev-parse',BASE+'^{tree}').decode().strip(),'baselineLeaves':len(tree),'preservedCount':len(preserved),'preserved':preserved,'sharedInsertOnly':shared,'newPaths':sorted(new_paths),'sixFileDiffByteExact':True,'sourcePins':freeze['files'],'originalInterfacePins':originals,'copied':copied,'runtimeExecutions':0,'productImports':0,'gitMutations':0,'limitations':'Git/local-file read-only comparison and source inspection; no product, test, browser, live API, or installed-package receiving.'}
m=put('source-verification.json',(json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({'verification':m,'preserved':len(preserved),'sharedInsertions':shared,'newPaths':sorted(new_paths),'runtimeExecutions':0},indent=2))
