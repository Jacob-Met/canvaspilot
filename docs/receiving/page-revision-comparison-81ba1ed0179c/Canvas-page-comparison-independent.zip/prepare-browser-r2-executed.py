import pathlib,hashlib,json,ast,subprocess,datetime,os,difflib
B=pathlib.Path('/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,b):
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
d=(B/'receive-browser-r1.mjs').read_bytes();assert sha(d)=='0cfd5c5538bd1c4ec3c533216800059d466db631a04ff46e651acb81c2aecc07'
d2=d.replace(b"join(B,'browser-r1')",b"join(B,'browser-r2')");assert d2!=d;save(B/'receive-browser-r2.mjs',d2)
p=subprocess.run(['/usr/bin/node','--check',str(B/'receive-browser-r2.mjs')],capture_output=True,timeout=10);assert p.returncode==0,p.stderr
o=(B/'run-browser-r1.py').read_bytes();assert sha(o)=='45d99f9b67bcc637be0fcaba01c1b31c2c01e5dc64d238853f7d1a6163ee993d'
o2=o.decode().replace("R=B/'browser-r1';T=B/'tmp-browser-r1'","R=B/'browser-r2';T=pathlib.Path('/home/jacob/cv81-tmp-r2')").replace('receive-browser-r1.mjs','receive-browser-r2.mjs').replace(sha(d),sha(d2)).encode();ast.parse(o2);save(B/'run-browser-r2.py',o2)
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'R1 Chrome exited SIGABRT before page creation: SingletonSocket path too long under our overlong TMP directory. Replace only TMP/TEMP/TMPDIR with new own short home path and use fresh output namespace; sandbox, resource floors, source, expected payload and test behavior unchanged.','negativeReceiptSha256':sha((B/'browser-r1/receipt.json').read_bytes()),'r1ActualGroups':0,'r1Cleanup':json.loads((B/'browser-r1/outer-receipt.json').read_bytes()),'driver':{'path':'receive-browser-r2.mjs','bytes':len(d2),'sha256':sha(d2)},'outer':{'path':'run-browser-r2.py','bytes':len(o2),'sha256':sha(o2)},'outerDiff':''.join(difflib.unified_diff(o.decode().splitlines(True),o2.decode().splitlines(True)))}
save(B/'browser-transport-correction-before-r2.json',(json.dumps(v,indent=2)+'\n').encode());print(json.dumps({'driver':v['driver'],'outer':v['outer'],'negative':v['negativeReceiptSha256']}))
