import pathlib,json,hashlib,os,datetime,sys,copy
B=pathlib.Path('/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c')
A=pathlib.Path('/home/jacob/canvas-page-comparison-81ba1ed0179c')
O=B/'original-inputs';O.mkdir(mode=0o700)
def sha(b):return hashlib.sha256(b).hexdigest()
def jb(x):return (json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def put(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b
 return {'path':str(p.relative_to(B)),'bytes':len(b),'sha256':sha(b)}
pins=[]
for name,want in [('contract-before-candidate.json','d60ef8e74190a08c709b95704956a9ccdc781b51463acb1b902725c0566ae342'),('contract-clarification-before-candidate.json','aebb6b4b72c8cef48480c4daecaaa86597fe1b3a0cfb160ddd046a90335d67fb')]:
 b=(A/'evidence'/name).read_bytes();assert sha(b)==want;pins.append(put(B/name,b))
C=json.loads((B/'contract-before-candidate.json').read_text())
for x in C['originalPins']:
 b=(A/'original-inputs'/x['path']).read_bytes()
 assert len(b)==x['bytes'] and sha(b)==x['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['gitBlob']
 pins.append(put(O/x['path'],b))
rawBefore='A\r\nsame\u2028unit\rB\nlast'
rawAfter='A\r\nB\nadded\rfinal'
wireBefore={'revision_id':'0007','title':'Before <literal> & "名"','body':rawBefore,'url':'historical-before/not-current','body_text':{'server_value':'opaque body_text field'},'updated_at':'2030-01-01T00:00:00Z','metadata':{'ordered':['first',{'kept':True}],'negative_zero':-0.0}}
wireAfter={'revision_id':19,'title':'After <literal> & "名"','body':rawAfter,'url':'historical-after/not-current','body_text':'server string, not derived projection','updated_at':'1990-01-01T00:00:00Z','metadata':{'ordered':['second',None],'number':1.0}}
selection={'course_id':'42','page_url':'note/alpha ?# 名','before_revision':'7','after_revision':'19'}
before={'revision':copy.deepcopy(wireBefore),'body_text':'A same unit B last'}
after={'revision':copy.deepcopy(wireAfter),'body_text':'A B added final'}
rows=[
 {'kind':'equal','before_line':1,'after_line':1,'text':'A\r\n'},
 {'kind':'delete','before_line':2,'after_line':None,'text':'same\u2028unit\r'},
 {'kind':'equal','before_line':3,'after_line':2,'text':'B\n'},
 {'kind':'delete','before_line':4,'after_line':None,'text':'last'},
 {'kind':'insert','before_line':None,'after_line':3,'text':'added\r'},
 {'kind':'insert','before_line':None,'after_line':4,'text':'final'},
]
assert ''.join(r['text']for r in rows if r['kind']in ['equal','delete'])==rawBefore
assert ''.join(r['text']for r in rows if r['kind']in ['equal','insert'])==rawAfter
comparison={'before_body_state':'text','after_body_state':'text','raw_equal':False,'text_equal':False,'line_diff':{'status':'computed','reason':None,'before_lines':4,'after_lines':4,'rows':rows}}
def report(be,af,co):return {'schema':'canvaspilot.page-revision-comparison.v1','selection':copy.deepcopy(selection),'before':copy.deepcopy(be),'after':copy.deepcopy(af),'comparison':copy.deepcopy(co)}
expectedCli=report(before,after,comparison)
beforeOuter={**copy.deepcopy(before),'opaque_outer':{'retained':['outer',{'value':'first'}]}}
afterOuter={**copy.deepcopy(after),'opaque_outer':{'retained':['outer',{'value':'second'}]}}
expectedApi=report(beforeOuter,afterOuter,comparison)
cases=[]
for name,be,af,bs,ass,bl,al in [
 ('absent-to-null',{'revision':{'revision_id':7,'title':'Absent'}},{'revision':{'revision_id':'019','title':'Null','body':None},'body_text':None},'absent','null',None,None),
 ('null-to-empty',{'revision':{'revision_id':7,'body':None},'body_text':None},{'revision':{'revision_id':19,'body':''},'body_text':''},'null','empty',None,0),
 ('empty-to-empty',{'revision':{'revision_id':7,'body':''},'body_text':''},{'revision':{'revision_id':19,'body':''},'body_text':''},'empty','empty',0,0)]:
 comparable=bs=='empty'and ass=='empty'
 co={'before_body_state':bs,'after_body_state':ass,'raw_equal':True if comparable else None,'text_equal':True if comparable else None,'line_diff':{'status':'computed'if comparable else'not-comparable','reason':None if comparable else'One or both revision bodies are absent or null.','before_lines':bl,'after_lines':al,'rows':[]}}
 cases.append({'name':name,'before':be,'after':af,'report':report(be,af,co)})
boundCases=[]
for name,text,status in [('exact-combined-byte-floor','é'*65536,'computed'),('one-byte-over-combined-work-limit','é'*65536+'x','limit')]:
 be={'revision':{'revision_id':7,'body':text},'body_text':text};af={'revision':{'revision_id':19,'body':''},'body_text':''}
 co={'before_body_state':'text','after_body_state':'empty','raw_equal':False,'text_equal':False,'line_diff':{'status':status,'reason':None if status=='computed'else'Line comparison not computed: the bounded work limit was exceeded.','before_lines':1,'after_lines':0,'rows':[{'kind':'delete','before_line':1,'after_line':None,'text':text}]if status=='computed'else[]}}
 boundCases.append({'name':name,'combinedRawBodyUtf8Bytes':len(text.encode()),'before':be,'after':af,'report':report(be,af,co)})
# Exactly one original-only API pair establishes the inherited envelope projection for this new fixture.
runtime=pathlib.Path('/home/jacob/canvas-page-revisions-81ba1ed0179c/source/src')
for name in ['api.py','page_revisions.py','client.py']:
 x=next(x for x in C['originalPins']if x['path']=='src/canvaspilot/'+name)
 assert sha((runtime/'canvaspilot'/name).read_bytes())==x['sha256']
sys.path.insert(0,str(runtime));sys.dont_write_bytecode=True
from canvaspilot.api import CanvasAPI
class OriginalClient:
 def __init__(self):self.calls=[]
 def request(self,method,path,params=None):
  self.calls.append({'method':method,'path':path,'params':params})
  if path.endswith('/7'):return copy.deepcopy(wireBefore)
  if path.endswith('/19'):return copy.deepcopy(wireAfter)
  raise AssertionError('unexpected original baseline route')
client=OriginalClient();api=CanvasAPI(client)
actualBefore=api.get_page_revision('00042',selection['page_url'],'0007',summary=False)
actualAfter=api.get_page_revision(42,selection['page_url'],19,summary=False)
assert actualBefore==before and actualAfter==after
assert client.calls==[
 {'method':'GET','path':'/api/v1/courses/42/pages/note%2Falpha%20%3F%23%20%E5%90%8D/revisions/7','params':{'summary':False}},
 {'method':'GET','path':'/api/v1/courses/42/pages/note%2Falpha%20%3F%23%20%E5%90%8D/revisions/19','params':{'summary':False}}]
baseline=put(B/'original-fixture-receiving.json',jb({'method':'Two controlled calls through unchanged original117 API, no provider or candidate. One new fixture projection baseline, not old suite replay.','calls':client.calls,'before':actualBefore,'after':actualAfter,'passed':True}))
cp=put(B/'expected-cli-report.json',jb(expectedCli));ap=put(B/'expected-api-report.json',jb(expectedApi))
bp=put(B/'body-state-cases.json',jb(cases));lp=put(B/'work-boundary-cases.json',jb(boundCases))
fixture=put(B/'http-fixture.json',jb({'selection':selection,'before':wireBefore,'after':wireAfter,'expectedNormalized':expectedCli,'paths':client.calls,'opaqueBefore':beforeOuter,'opaqueAfter':afterOuter}))
E={'schema':'canvas.revision-comparison.independent-expectations/1','created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scopeBeforeContractSha256':'3b47d3930322e922145390ded79c4ce8725b425246400b286088c94b941a9abf','contractSha256':C and 'd60ef8e74190a08c709b95704956a9ccdc781b51463acb1b902725c0566ae342','clarificationSha256':'aebb6b4b72c8cef48480c4daecaaa86597fe1b3a0cfb160ddd046a90335d67fb','exposure':'Only contract, pre-candidate clarification, ten unchanged original inputs, original117 API pair and original writer/CLI source read. No comparison implementation, author tests, author expectations, output or browser read. Synchronous original method lookup initially failed due to an async assumption, without product execution; retained note/correction.','selection':selection,'downloadFilename':'canvas-page-revisions-42-7-vs-19.json','files':[cp,ap,bp,lp,fixture,baseline],'groups':[
 {'id':'I1','scope':'Validate leading-zero canonical IDs and exact locator; build full manually specified six-row raw diff with CRLF/CR/LF and U+2028 inside a line. Compare full ordered object and complete normalized JSON bytes, source envelopes and reconstruction. During second fake API read mutate first envelope nested metadata; accepted before must retain its initial detached content. After return mutate inputs again and prove full report unchanged. Exactly before7 thenafter19, summary=False, no alternate API.'},
 {'id':'I2','scope':'Three complete body-state cases: absent/null, null/empty, empty/empty; compare complete expected report objects/serialized bytes. No inferred body_text or borrowed current page.'},
 {'id':'I3','scope':'Two complementary UTF8 work-boundary cases: combined raw131072B remains computed with one exact deletion;131073B gives explicit limit/emptyrows while all full original sources/equality remain. Both under overall envelope/body bounds. No other author limit sweep.'},
 {'id':'I4','scope':'New-consumer refusals only: canonical equal7/0007 and latest before must throw with0fakeAPIcalls; first cyclic unknown metadata refuses after1call; second body:null with body_text:string refuses after2orderedcalls. No input mutation or output bytes returned. No repeated broad old117 ID/path suite.'},
 {'id':'I5','scope':'Three actual CLI calls in own loopback: successful7→19 returns one passiveHTML whose explicit dataURI decodes to exact expected-cli-report.json; existingoutput refuses before anyrequest and preserves everybyte; second revision GET fails on explicit19→7 direction, exit1/stdoutempty and no output/stage. Actual query summary=false required. Existing token argument is a synthetic loopback string only; no login/profile/account.'},
 {'id':'I6','scope':'One complementary desktop actual-browser physical JSON download from the exact I5 HTML; fixed filename and wholebytes match frozen expectedCLI report. Keyboard-open the two source disclosures and confirm complete literal source data visible, no executable script/form/external asset or unexpectedrequest. No author390/print/full campaign replay.'}],
 'refusalRecipes':[{'name':'equal-canonical','before':'0007','after':7,'calls':0},{'name':'latest-before','before':'latest','after':19,'calls':0},{'name':'cycle-in-first-opaque-metadata','before':7,'after':19,'calls':1},{'name':'null-body-string-projection-in-second','before':7,'after':19,'calls':2}],
 'htmlAcceptance':'No fixed template bytes are specified by contract. Parse one explicit download anchor; decode percent/base64 data URI as declared and require complete exact normalized JSON bytes. Static no script/form/remoteasset checks and literal source display; full HTML changes are not normalized to conceal missing data. Whole report objects and download bytes are exact.',
 'attribution':'Prior117 four-group receipt762c539f remains old reader qualification. This freeze manually authors new comparison line rows and uses original cleaner once for this fixture; no new diff implementation/candidate/difflib call used to generate expectations.',
 'guards':{'existingPython':'/home/jacob/canvaspilot-enrollments-env-65ae877160f6/bin/python','noInstalls':True,'ownLoopbackOnly':True,'minimumAvailableRamBytes':2147483648,'minimumDiskFreeBytes':268435456,'browserMaximumSeconds':75,'ownNewProfileTmp':True,'sandboxUnchanged':True},
 'sourcePins':pins}
ep=put(B/'expectations-before-candidate.json',jb(E))
rp=put(B/'freeze-receipt.json',jb({'expectations':ep,'members':[cp,ap,bp,lp,fixture,baseline]+pins,'candidateBodiesRead':False,'authorTestsRead':False,'baselineOnlyTwoOriginalControlledCalls':True,'complete':True}))
print(json.dumps({'expectations':ep,'receipt':rp,'fixtures':{'cli':cp,'api':ap,'states':bp,'workBoundaries':lp},'originalOnlyBaseline':baseline,'groups':6,'candidateBodiesRead':False}))
