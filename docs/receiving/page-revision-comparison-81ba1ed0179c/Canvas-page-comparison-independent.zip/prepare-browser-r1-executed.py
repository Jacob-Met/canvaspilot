import pathlib,hashlib,json,ast,subprocess,os,datetime,difflib
B=pathlib.Path('/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c');p=pathlib.Path('/home/jacob/freight-queue-linux-81ba1ed0179c/tools/browser-transport.mjs')
def sha(b):return hashlib.sha256(b).hexdigest()
old=p.read_bytes();text=old.decode();assert text.count('/home/jacob/freight-queue-linux-81ba1ed0179c/profile-')==1
new=text.replace('/home/jacob/freight-queue-linux-81ba1ed0179c/profile-',str(B)+'/profile-').encode()
with(B/'browser-transport.mjs').open('xb')as f:f.write(new);f.flush();os.fsync(f.fileno())
r=[]
for name in ['browser-transport.mjs','receive-browser-r1.mjs']:
 b=(B/name).read_bytes();result=subprocess.run(['/usr/bin/node','--check',str(B/name)],capture_output=True,timeout=10);assert result.returncode==0,result.stderr
 r.append({'path':name,'bytes':len(b),'sha256':sha(b),'syntaxExit':result.returncode})
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helperSource':{'path':str(p),'bytes':len(old),'sha256':sha(old)},'files':r,'delta':''.join(difflib.unified_diff(text.splitlines(True),new.decode().splitlines(True),fromfile=str(p),tofile=str(B/'browser-transport.mjs'))),'sourceAndGameExecution':False,'expectedPayloadSha256':'f500f882f5fba4c3bd9c409d222536adbf4cf9b3b8f8e17270c808752d3a30ab'}
with(B/'browser-pre-execution-freeze.json').open('xb')as f:f.write((json.dumps(v,indent=2)+'\n').encode());f.flush();os.fsync(f.fileno())
print(json.dumps(v))
