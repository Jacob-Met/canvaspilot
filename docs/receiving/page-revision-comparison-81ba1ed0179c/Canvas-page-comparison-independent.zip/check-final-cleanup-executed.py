import pathlib,json,hashlib,datetime,os
B=pathlib.Path('/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c')
pids=[1202600,1202667,1202755,1202826,1202829,1205439,1205506,1205508,1205523,1205525,1209648,1209715,1209738,1210740,1210808,1210831]
matches=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdecimal():continue
 try:c=(p/'cmdline').read_bytes().split(b'\0')
 except (FileNotFoundError,PermissionError,ProcessLookupError):continue
 if any(x.startswith(('--user-data-dir='+str(B)+'/profile-').encode())for x in c):matches.append(int(p.name))
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pidsAbsent':{str(x):not pathlib.Path('/proc',str(x)).exists()for x in pids},'profiles':[str(x)for x in B.glob('profile-*')],'ownedProfileProcessMatches':matches,'tmpPathsAbsent':{str(x):not x.exists()for x in [B/'tmp-browser-r1',pathlib.Path('/home/jacob/cv81-tmp-r2')]},'loopbackServersClosed':all(json.loads((B/r/'receipt.json').read_bytes())['serverClosed']for r in ['cli-r1','cli-r2'])}
assert all(v['pidsAbsent'].values())and not v['profiles']and not matches and all(v['tmpPathsAbsent'].values())and v['loopbackServersClosed']
b=(json.dumps(v,indent=2)+'\n').encode()
with(B/'fresh-cleanup-final.json').open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
print(json.dumps({'path':str(B/'fresh-cleanup-final.json'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'proof':v}))
print(json.dumps({'rootFiles':[p.name for p in B.iterdir()]}))
