import pathlib,hashlib,json,ast,datetime,difflib,os
B=pathlib.Path('/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,b):
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
old=(B/'receive-cli-r1.py').read_bytes();assert sha(old)=='0bd65d4fa133b445ea9fcb6ec185613547849e57ef24dfd93aa8dbfe8501ed26'
text=old.decode();assert text.count("{'summary':['false']}")==5
new=text.replace("{'summary':['false']}","{'summary':['false'],'per_page':['50']}").replace("R=B/'cli-r1'","R=B/'cli-r2'").encode();ast.parse(new);save(B/'receive-cli-r2.py',new)
outer=(B/'run-receiving-r1.py').read_bytes();assert sha(outer)=='d5091d392a3e6af6ffb25f879e77b8067c7c0c53031c354f3a49921a25235b42'
o=outer.decode().replace("assert kind in ('api','cli')","assert kind=='cli'").replace("kind+'-outer-r1'","kind+'-outer-r2'").replace("receive-cli-r1.py","receive-cli-r2.py").replace("0bd65d4fa133b445ea9fcb6ec185613547849e57ef24dfd93aa8dbfe8501ed26",sha(new)).replace("kind+'-r1'","kind+'-r2'").encode();ast.parse(o);save(B/'run-receiving-r2.py',o)
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Receiver R1 rejected the unchanged original client per_page=50 query parameter before any completed CLI group; original client.py lines216 and469-480 add50. This is a receiving-fixture correction only.','originalClientSha256':'d3473b7805908c15b276689abff9dd0dbd8d428e8691d557a26a5b2285444797','negativeReceipt':{'path':'cli-r1/receipt.json','sha256':sha((B/'cli-r1/receipt.json').read_bytes())},'driver':{'path':'receive-cli-r2.py','bytes':len(new),'sha256':sha(new)},'outer':{'path':'run-receiving-r2.py','bytes':len(o),'sha256':sha(o)},'driverDiff':''.join(difflib.unified_diff(text.splitlines(True),new.decode().splitlines(True),fromfile='receive-cli-r1.py',tofile='receive-cli-r2.py')),'unchangedExpectedPayloadSha256':sha((B/'expected-cli-report.json').read_bytes()),'apiRerun':False,'sourceChange':False}
save(B/'cli-query-correction-before-r2.json',(json.dumps(v,indent=2)+'\n').encode());print(json.dumps(v))
