import pathlib,json,hashlib,sys,copy,datetime,traceback
from html.parser import HTMLParser
from urllib.parse import unquote_to_bytes
import base64
B=pathlib.Path('/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c')
binding=json.loads(pathlib.Path(sys.argv[1]).read_text())
S=pathlib.Path(binding['sourceRoot']);OUT=B/'api-r1';OUT.mkdir(mode=0o700)
def sha(b):return hashlib.sha256(b).hexdigest()
def jb(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
assert sha((B/'expectations-before-candidate.json').read_bytes())=='9701e984e24ef056fc411cbcbff1fe6a2399a6ccfaa427f622cdb12578d60661'
E=json.loads((B/'expectations-before-candidate.json').read_text());F=json.loads((B/'http-fixture.json').read_text())
for x in binding['sourcePins']:
 b=(S/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],x['path']
sys.path.insert(0,str(S/'src'));sys.dont_write_bytecode=True
from canvaspilot.page_revision_comparison import validate_revision_comparison,build_page_revision_comparison
receipt={'schema':'canvas.revision-comparison.independent-api/1','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expectationsSha256':'9701e984e24ef056fc411cbcbff1fe6a2399a6ccfaa427f622cdb12578d60661','bindings':binding,'groups':[],'passed':False}
def save(): (OUT/'receipt.json').write_bytes(jb(receipt))
class Passive(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.downloads=[];self.tags=[];self.bad=[];self.pres=[];self.inpre=False;self.pre=[]
 def handle_starttag(self,tag,attrs):
  self.tags.append(tag);a=dict(attrs)
  if tag in ('script','form','iframe','object','embed'):self.bad.append(tag)
  if any(k.lower().startswith('on')for k in a):self.bad.append('event attribute')
  if any(k in a for k in ('src','srcset','action')):self.bad.append((tag,a))
  if tag=='link'and a.get('rel')=='stylesheet':self.bad.append('external stylesheet')
  if tag=='a'and 'download'in a:self.downloads.append(a)
  if tag=='a'and 'href'in a and not a['href'].startswith(('data:','#')):self.bad.append(('external link',a))
  if tag=='pre':self.inpre=True;self.pre=[]
 def handle_endtag(self,tag):
  if tag=='pre'and self.inpre:self.pres.append(''.join(self.pre));self.inpre=False
 def handle_data(self,data):
  if self.inpre:self.pre.append(data)
def check_html(blob,report,label):
 assert isinstance(blob,bytes)and len(blob)<=8388608
 p=Passive();p.feed(blob.decode('utf-8'));assert not p.bad,p.bad
 assert len(p.downloads)==1
 a=p.downloads[0];assert a['download']==E['downloadFilename']
 header,sep,body=a['href'].partition(',');assert sep and header.startswith('data:application/json')
 payload=base64.b64decode(body,validate=True)if ';base64'in header else unquote_to_bytes(body)
 assert payload==jb(report)
 (OUT/(label+'.html')).write_bytes(blob);(OUT/(label+'.json')).write_bytes(payload)
 return {'htmlBytes':len(blob),'htmlSha256':sha(blob),'payloadBytes':len(payload),'payloadSha256':sha(payload),'download':a['download'],'preBlocks':len(p.pres),'passive':True}
class API:
 def __init__(self,be,af,mutate=False):self.before=be;self.after=af;self.calls=[];self.mutate=mutate
 def get_page_revision(self,c,p,r,*,summary=False):
  self.calls.append({'course':c,'page':p,'revision':r,'summary':summary})
  assert len(self.calls)<=2
  expected=E['selection'];assert c==expected['course_id']and p==expected['page_url']and summary is False
  if len(self.calls)==1:
   assert r=='7';return self.before
  assert r=='19'
  if self.mutate:self.before['revision']['metadata']['ordered'][1]['kept']='provider mutation during second read';self.before['opaque_outer']['retained'][1]['value']='provider-mutated'
  return self.after
def exact_result(api,want,label):
 blob,report=build_page_revision_comparison(api,'00042',E['selection']['page_url'],'0007',19)
 assert report==want and jb(report)==jb(want),label
 assert list(report)==['schema','selection','before','after','comparison']
 assert len(api.calls)==2
 return blob,report,check_html(blob,want,label)
def group(name,fn):
 evidence=fn();receipt['groups'].append({'name':name,'passed':True,'evidence':evidence});save()
try:
 def first():
  assert validate_revision_comparison('00042',E['selection']['page_url'],'0007',19)==E['selection']
  api=API(copy.deepcopy(F['opaqueBefore']),copy.deepcopy(F['opaqueAfter']),True)
  before_snapshot=copy.deepcopy(api.before);after_snapshot=copy.deepcopy(api.after)
  want=json.loads((B/'expected-api-report.json').read_text());blob,report,proof=exact_result(api,want,'manual-six-row')
  assert api.after==after_snapshot
  assert report['before']==before_snapshot
  api.before['revision']['body']='after-return changed';api.after['revision']['metadata']['ordered'].append('after-return change')
  assert jb(report)==(B/'expected-api-report.json').read_bytes()
  assert ''.join(x['text']for x in report['comparison']['line_diff']['rows']if x['kind']in ('equal','delete'))==before_snapshot['revision']['body']
  assert ''.join(x['text']for x in report['comparison']['line_diff']['rows']if x['kind']in ('equal','insert'))==after_snapshot['revision']['body']
  return {'calls':api.calls,'manualRows':6,'detachedAcrossSecondCallAndAfterReturn':True,'proof':proof}
 group('I1-complete-raw-diff-payload-and-detachment',first)
 def states():
  results=[]
  for x in json.loads((B/'body-state-cases.json').read_text()):
   api=API(copy.deepcopy(x['before']),copy.deepcopy(x['after']));before=copy.deepcopy([api.before,api.after])
   blob,r,p=exact_result(api,x['report'],x['name']);assert [api.before,api.after]==before
   results.append({'case':x['name'],'calls':api.calls,'proof':p})
  return results
 group('I2-complete-absent-null-empty-cases',states)
 def work():
  results=[]
  for x in json.loads((B/'work-boundary-cases.json').read_text()):
   api=API(copy.deepcopy(x['before']),copy.deepcopy(x['after']))
   blob,r,p=exact_result(api,x['report'],x['name'])
   assert [api.before,api.after]==[x['before'],x['after']]
   results.append({'case':x['name'],'bytes':x['combinedRawBodyUtf8Bytes'],'status':r['comparison']['line_diff']['status'],'proof':p})
  return results
 group('I3-exact-UTF8-comparison-work-boundary',work)
 def refusals():
  results=[]
  for x in E['refusalRecipes']:
   be=copy.deepcopy(F['opaqueBefore']);af=copy.deepcopy(F['opaqueAfter'])
   if x['name']=='cycle-in-first-opaque-metadata':
    be['opaque_outer']['cycle']=be['opaque_outer']
   if x['name']=='null-body-string-projection-in-second':
    af['revision']['body']=None;af['body_text']='not null'
   api=API(be,af)
   try:build_page_revision_comparison(api,'42',E['selection']['page_url'],x['before'],x['after'])
   except (TypeError,ValueError)as error:
    assert len(api.calls)==x['calls'],(x,api.calls)
    if x['name']=='cycle-in-first-opaque-metadata':assert be['opaque_outer']['cycle']is be['opaque_outer']
    if x['name']=='null-body-string-projection-in-second':assert af['revision']['body']is None and af['body_text']=='not null'
    results.append({'case':x['name'],'type':type(error).__name__,'message':str(error),'calls':api.calls})
   else:raise AssertionError('Refusal did not occur: '+x['name'])
  return results
 group('I4-narrow-new-consumer-refusals',refusals)
 receipt['passed']=True
except BaseException as e:
 receipt['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
finally:
 changed=[]
 for x in binding['sourcePins']:
  if sha((S/x['path']).read_bytes())!=x['sha256']:changed.append(x['path'])
 receipt['sourceUnchanged']=not changed;receipt['changed']=changed
 if changed:receipt['passed']=False
 receipt['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({'passed':receipt['passed'],'groups':[g['name']for g in receipt['groups']],'failure':receipt.get('failure'),'path':str(OUT/'receipt.json'),'sha256':sha((OUT/'receipt.json').read_bytes())}))
raise SystemExit(0 if receipt['passed'] else 1)
