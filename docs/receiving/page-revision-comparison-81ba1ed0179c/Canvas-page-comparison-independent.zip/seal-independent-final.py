import pathlib,json,hashlib,os,datetime,zipfile,stat,subprocess,shutil
B=pathlib.Path('/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c')
D=B/'delivery';D.mkdir(mode=0o700)
def sha(b):return hashlib.sha256(b).hexdigest()
def jb(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def pin(p):b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b)}
def save(p,b):
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
binding=json.loads((B/'candidate-binding-r1.json').read_bytes());S=pathlib.Path(binding['sourceRoot'])
for x in binding['sourcePins']:assert pin(S/x['path'])=={k:x[k]for k in ('bytes','sha256')}
C=B/'candidate-source';C.mkdir(mode=0o700)
copied=[]
for x in binding['sourcePins']:
 if x['path'].startswith('tests/'):continue
 p=C/x['path'];p.parent.mkdir(parents=True,exist_ok=True);save(p,(S/x['path']).read_bytes());os.chmod(p,stat.S_IMODE((S/x['path']).stat().st_mode));copied.append(x)
for name in ['api-r1/receipt.json','cli-r2/receipt.json','browser-r2/receipt.json']:
 assert json.loads((B/name).read_bytes())['passed']is True
cleanup=json.loads((B/'fresh-cleanup-final.json').read_bytes());assert all(cleanup['pidsAbsent'].values())and not cleanup['ownedProfileProcessMatches']
review={
 'schema':'canvas.page-comparison.independent-receiving-final/1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':'estate-81ba1ed0179c / estate_integration_resume','sourceOwner':'estate_production_resume; earlier page revision reader ownership preserved',
 'outcome':'accepted within the six frozen independent recipient groups','blockers':[],
 'contract':{'path':'contract-before-candidate.json',**pin(B/'contract-before-candidate.json')},'clarification':{'path':'contract-clarification-before-candidate.json',**pin(B/'contract-clarification-before-candidate.json')},
 'expectations':{'path':'expectations-before-candidate.json',**pin(B/'expectations-before-candidate.json')},
 'candidate':{'root':str(S),'module':next(x for x in binding['sourcePins']if x['path'].endswith('/page_revision_comparison.py')),'cli':next(x for x in binding['sourcePins']if x['path'].endswith('/cli.py')),'all14BoundPinsUnchanged':True,'archivedProductAndOriginalPins':copied},
 'groups':[
  {'name':'I1 complete manually authored six-row diff and payload','accepted':'Exact raw CRLF/CR/LF, embedded U+2028 stays one line; full ordered report and 2496-byte JSON exact; first envelope detached before a second provider call mutates it, both envelopes remain detached after return.'},
  {'name':'I2 absent/null/empty','accepted':'Three complete distinct reports, exact body states/equality/not-comparable behavior and payload bytes.'},
  {'name':'I3 exact UTF-8 work boundary','accepted':'131072 combined raw-body bytes compute the exact row; 131073 skips only line work, retaining full source envelopes and equality fields.'},
  {'name':'I4 narrow new-consumer refusals','accepted':'Equal canonical revisions and latest refuse with zero calls; first opaque cycle refuses after one call; second null body with string projection refuses after two calls.'},
  {'name':'I5 actual CLI loopback and create-only output','accepted':'Three actual CLI calls exit0/1/1: chosen7→19 produces exact10700-byte HTML/payload; existing destination refuses before any HTTP request; reversed19→7 denies the second GET403 and leaves no output or staging file. All requests are exact encoded paths with unchanged summary=false and per_page=50.'},
  {'name':'I6 actual passive-file recipient','accepted':'Chrome153 direct-file launch: physical Tab/Enter opens complete before/after source envelopes and then the sole download; exactly2253 native bytes and suggested filename match pre-candidate expectation. Page scripts0; one own file request, no external page request or runtime exception. Screenshot directly reviewed.'}
 ],
 'receipts':[{ 'path':x,**pin(B/x)}for x in ['api-r1/receipt.json','api-outer-r1/receipt.json','cli-r2/receipt.json','cli-outer-r2/receipt.json','browser-r2/receipt.json','browser-r2/outer-receipt.json','fresh-cleanup-final.json']],
 'physicalPayload':json.loads((B/'browser-r2/receipt.json').read_bytes())['groups'][0]['download'],
 'screenshot':{'path':'browser-r2/report-open-desktop.png',**pin(B/'browser-r2/report-open-desktop.png'),'directlyInspected':True,'observation':'Desktop two-column before/after complete envelopes, explicit selected direction and non-atomic-read limits, visible focus ring and complete six-row raw-line comparison are legible and coherent. No narrow-layout or print claim from this receiver.'},
 'preservedNegatives':[
  'Original-only pre-expectation read searched for an async API definition; actual released API is synchronous. The failed text lookup was corrected before candidate exposure.',
  'Initial API receiver draft had else1 syntax without required whitespace. AST rejected it before candidate execution; corrected r2 and exact prior draft are retained.',
  'CLI R1 fixture admitted only summary=false, rejecting unchanged original client per_page=50. Exactly one request/zero completed CLI groups, original stderr and cleanup retained. Corrected only query fixture/expected transport plus fresh output namespace; frozen report oracle unchanged.',
  'Browser R1 exited SIGABRT before page creation: own overly long TMP generated a too-long SingletonSocket path. Zero page groups/downloads, fatal stderr and observed cleanup retained. R2 changed only new own short TMP and output namespace; same candidate, page, frozen expectations, sandbox and resource guards.'
 ],
 'exposureAndLimits':[
  'Expectations and complete desired objects/bytes froze before candidate access. Prior released117 reader was already independently received and is disclosed; two original-only API observations supplied this fixture before candidate.',
  'Candidate manifest metadata included author result totals after our freeze. Author test and expectation bodies were never read or executed; the API import executes candidate product code and archive copying reads source bytes without using those bytes as the oracle.',
  'No new product-module source correctness review is claimed here; coordination is separately reviewing source. HTML structural selectors were bound only after expected values were frozen.',
  'CLI uses an authenticated-looking fixed local test token solely with our127.0.0.1 fixture; no live Canvas account, broker, remote mutation or access-right acceptance is claimed.',
  'No author broad tests, page-reader suite, model, compiler, mobile, print or previously settled recipient suite was rerun. No Git ref, PR, merge or Actions operation occurred in this receiving lane.',
  'Page network observation is scoped to CDP page events; retained Chrome stderr is not a claim about every browser background channel. Passive source/zero page scripts and direct-file data download are distinct observations.'
 ],
 'cleanup':'All16 observed API/CLI/browser wrapper/child PIDs absent; both own loopback servers closed; both TMP paths and owned profiles absent; source and physical input unchanged.',
 'archiveScope':'All own freeze, original inputs, exact executed drivers, failed and successful outputs, actual download and screenshot;12 candidate product/original files copied exactly. Unrelated SRS peer-review driver excluded. Author test bodies excluded.'
}
save(B/'independent-final-review.json',jb(review))
excluded={'review-srs-correction.py'}
paths=sorted(p for p in B.rglob('*')if p.is_file()and not p.is_relative_to(D)and p.relative_to(B).as_posix()not in excluded)
assert all(not p.is_symlink()for p in paths)
members=[{'path':p.relative_to(B).as_posix(),**pin(p),'mode':stat.S_IMODE(p.stat().st_mode)}for p in paths]
manifest={'schema':'canvas.comparison.independent-members/1','files':members}
save(D/'members.json',jb(manifest));Z=D/'Canvas-page-comparison-independent.zip'
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p,x in zip(paths,members):
  info=zipfile.ZipInfo(x['path']);info.create_system=3;info.external_attr=(stat.S_IFREG|x['mode'])<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,p.read_bytes())
 info=zipfile.ZipInfo('archive-members.json');info.create_system=3;info.external_attr=(stat.S_IFREG|0o600)<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,jb(manifest))
with Z.open('r+b')as f:f.flush();os.fsync(f.fileno())
with zipfile.ZipFile(Z)as z:
 assert len(z.infolist())==len(members)+1
 for x in members:
  b=z.read(x['path']);assert len(b)==x['bytes']and sha(b)==x['sha256'];assert stat.S_IMODE(z.getinfo(x['path']).external_attr>>16)==x['mode']
 assert z.read('archive-members.json')==jb(manifest)
for x in binding['sourcePins']:assert pin(S/x['path'])=={k:x[k]for k in ('bytes','sha256')}
custody={'schema':'canvas.comparison.independent-custody/1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':{'path':str(Z),**pin(Z),'members':len(members)+1},'manifest':pin(D/'members.json'),'finalReview':pin(B/'independent-final-review.json'),'everyMemberBytesAndModeReopened':True,'sourcePinsUnchanged':True}
save(D/'custody-receipt.json',jb(custody))
target='/srv/hamon-estate/coord/estate-81ba1ed0179c/canvas-revision-comparison-independent'
spec={'target':target,'files':[{'source':str(p),'name':p.name,**pin(p)}for p in [Z,D/'members.json',D/'custody-receipt.json',B/'independent-final-review.json']]}
script="""import pathlib,json,hashlib,os
s=json.loads(__import__('sys').argv[1]);d=pathlib.Path(s['target']);assert str(d)=='/srv/hamon-estate/coord/estate-81ba1ed0179c/canvas-revision-comparison-independent';d.mkdir(mode=0o700);os.chown(d,1000,1000)
for x in s['files']:
 b=pathlib.Path(x['source']).read_bytes();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256']
 p=d/x['name']
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 os.chmod(p,0o600);os.chown(p,1000,1000);assert p.read_bytes()==b
fd=os.open(d,os.O_RDONLY);os.fsync(fd);os.close(fd)
print(json.dumps({'target':str(d),'files':s['files'],'exact':True}))
"""
r=subprocess.run(['sudo','-n','python3','-c',script,json.dumps(spec)],capture_output=True,timeout=30)
save(D/'durable-copy.stdout',r.stdout);save(D/'durable-copy.stderr',r.stderr);assert r.returncode==0,r.stderr
print(json.dumps({'custody':custody,'durable':json.loads(r.stdout)},ensure_ascii=False))
