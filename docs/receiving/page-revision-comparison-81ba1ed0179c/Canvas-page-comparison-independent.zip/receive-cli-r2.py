import pathlib,json,hashlib,sys,os,datetime,subprocess,threading,http.server,urllib.parse,signal,time,shutil,traceback,base64
from html.parser import HTMLParser
B=pathlib.Path('/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c');binding=json.loads(pathlib.Path(sys.argv[1]).read_text());S=pathlib.Path(binding['sourceRoot'])
R=B/'cli-r2';R.mkdir(mode=0o700);outputs=R/"New outputs 名 caller's files";outputs.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def jb(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
F=json.loads((B/'http-fixture.json').read_text());E=json.loads((B/'expectations-before-candidate.json').read_text())
assert sha((B/'expectations-before-candidate.json').read_bytes())=='9701e984e24ef056fc411cbcbff1fe6a2399a6ccfaa427f622cdb12578d60661'
for x in binding['sourcePins']:assert sha((S/x['path']).read_bytes())==x['sha256']
memory=int(next(x.split()[1]for x in pathlib.Path('/proc/meminfo').read_text().splitlines()if x.startswith('MemAvailable:')))*1024
assert memory>=2147483648 and shutil.disk_usage(B).free>=268435456
requests=[];mode={'deny7':False}
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):
  parsed=urllib.parse.urlsplit(self.path);query=urllib.parse.parse_qs(parsed.query,keep_blank_values=True)
  requests.append({'method':'GET','path':parsed.path,'query':query})
  try:
   if query!={'summary':['false'],'per_page':['50']}:raise AssertionError('Unexpected query')
   if parsed.path==F['paths'][0]['path']:
    if mode['deny7']:status=403;body={'errors':[{'message':'owned fixture permission denied'}]}
    else:status=200;body=F['before']
   elif parsed.path==F['paths'][1]['path']:status=200;body=F['after']
   else:raise AssertionError('Unexpected route')
  except BaseException as e:status=400;body={'error':str(e)}
  raw=jb(body);self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def do_POST(self):
  requests.append({'method':'POST','path':self.path});self.send_error(405)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
base='http://127.0.0.1:'+str(server.server_address[1]);py='/home/jacob/canvaspilot-enrollments-env-65ae877160f6/bin/python'
receipt={'schema':'canvas.revision-comparison.independent-cli/1','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'baseUrl':base,'requests':requests,'calls':[],'passed':False,'binding':binding}
children=[]
def run(label,before,after,out):
 args=[py,'-P','-B','-m','canvaspilot.cli','compare-page-revisions','00042',E['selection']['page_url'],'--before',before,'--after',after,'--out',str(out),'--base-url',base,'--token','independent-loopback-only']
 env={**os.environ,'PYTHONPATH':str(S/'src'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
 start=len(requests);p=subprocess.Popen(args,cwd=outputs,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);children.append(p)
 try:stdout,stderr=p.communicate(timeout=20)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM);stdout,stderr=p.communicate(timeout=5);raise
 (R/(label+'.stdout')).write_bytes(stdout);(R/(label+'.stderr')).write_bytes(stderr)
 obs={'label':label,'pid':p.pid,'argv':args,'exit':p.returncode,'stdoutSha256':sha(stdout),'stdoutBytes':len(stdout),'stderrSha256':sha(stderr),'stderrBytes':len(stderr),'requests':copy_requests(requests[start:])}
 receipt['calls'].append(obs);(R/'receipt.json').write_bytes(jb(receipt))
 return p.returncode,stdout,stderr,obs
def copy_requests(items):return json.loads(json.dumps(items))
class Download(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.links=[];self.bad=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag in ('script','form','iframe','object','embed')or any(k.startswith('on')for k in a):self.bad.append((tag,a))
  if any(k in a for k in ('src','srcset','action')):self.bad.append((tag,a))
  if tag=='a'and 'download'in a:self.links.append(a)
def payload(html):
 p=Download();p.feed(html.decode());assert not p.bad and len(p.links)==1
 a=p.links[0];assert a['download']==E['downloadFilename'];header,_,data=a['href'].partition(',');assert header.startswith('data:application/json')
 return base64.b64decode(data,validate=True)if ';base64'in header else urllib.parse.unquote_to_bytes(data)
try:
 target=outputs/"chosen revisions 名's.html"
 code,stdout,stderr,obs=run('success','0007','019',target)
 assert code==0 and len(stdout)<=4096 and isinstance(json.loads(stdout),dict)
 assert obs['requests']==[
  {'method':'GET','path':F['paths'][0]['path'],'query':{'summary':['false'],'per_page':['50']}},
  {'method':'GET','path':F['paths'][1]['path'],'query':{'summary':['false'],'per_page':['50']}}]
 blob=target.read_bytes();assert payload(blob)==(B/'expected-cli-report.json').read_bytes()
 receipt['html']={'path':str(target),'bytes':len(blob),'sha256':sha(blob),'payloadBytes':2253,'payloadSha256':'f500f882f5fba4c3bd9c409d222536adbf4cf9b3b8f8e17270c808752d3a30ab'}
 code,stdout,stderr,obs=run('existing-output','7','19',target)
 assert code==1 and not stdout and isinstance(json.loads(stderr),dict)and obs['requests']==[]
 assert target.read_bytes()==blob
 mode['deny7']=True;failed=outputs/'refused-second.html'
 code,stdout,stderr,obs=run('denied-second-reverse-direction','19','7',failed)
 assert code==1 and not stdout and isinstance(json.loads(stderr),dict)
 assert obs['requests']==[
  {'method':'GET','path':F['paths'][1]['path'],'query':{'summary':['false'],'per_page':['50']}},
  {'method':'GET','path':F['paths'][0]['path'],'query':{'summary':['false'],'per_page':['50']}}]
 assert not os.path.lexists(failed)
 assert list(outputs.iterdir())==[target]
 assert not list(outputs.glob('.canvaspilot-pages-*'))
 assert target.read_bytes()==blob
 receipt['passed']=True
except BaseException as e:receipt['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
finally:
 for p in children:
  if p.poll()is None:
   os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5);receipt['passed']=False
 server.shutdown();server.server_close();thread.join(timeout=3)
 receipt['serverClosed']=not thread.is_alive();receipt['childrenAbsent']={str(p.pid):not pathlib.Path('/proc',str(p.pid)).exists()for p in children}
 changed=[x['path']for x in binding['sourcePins']if sha((S/x['path']).read_bytes())!=x['sha256']]
 receipt['sourceUnchanged']=not changed
 if changed or not receipt['serverClosed']or not all(receipt['childrenAbsent'].values()):receipt['passed']=False
 receipt['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(R/'receipt.json').open('wb')as f:f.write(jb(receipt));f.flush();os.fsync(f.fileno())
print(json.dumps({'passed':receipt['passed'],'calls':len(receipt['calls']),'requests':requests,'failure':receipt.get('failure'),'path':str(R/'receipt.json'),'sha256':sha((R/'receipt.json').read_bytes())}))
raise SystemExit(0 if receipt['passed'] else 1)
