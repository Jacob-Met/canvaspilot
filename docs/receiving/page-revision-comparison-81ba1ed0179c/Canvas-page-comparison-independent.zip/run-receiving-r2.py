import pathlib,json,hashlib,os,sys,datetime,subprocess,signal,shutil,time,traceback
B=pathlib.Path('/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c')
A=pathlib.Path('/home/jacob/canvas-page-comparison-81ba1ed0179c')
kind=sys.argv[1];assert kind=='cli'
def sha(b):return hashlib.sha256(b).hexdigest()
def jb(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(p,b):
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
def pin(p):b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b)}
assert os.getuid()==1000 and os.uname().nodename=='hamon-thinkpad'
R=B/(kind+'-outer-r2');R.mkdir(mode=0o700)
receipt={'schema':'canvas.comparison.independent-outer/1','mode':kind,'wrapperPid':os.getpid(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':False}
p=None
try:
 manifest=(A/'evidence/source-freeze-r1.json').read_bytes()
 assert len(manifest)==1851 and sha(manifest)=='d86096b6066c64f76162c28e434570c7290969d7eb14bbf975a42a50377373cc'
 M=json.loads(manifest);S=pathlib.Path(M['sourceRoot'])
 original=json.loads((B/'contract-before-candidate.json').read_bytes())['originalPins']
 pins={x['path']:{k:x[k]for k in ('path','bytes','sha256')}for x in original}
 for x in M['files']:pins[x['path']]={k:x[k]for k in ('path','bytes','sha256')}
 binding={'schema':'canvas.comparison.independent-binding/1','sourceRoot':str(S),'sourceFreezeSha256':sha(manifest),'sourcePins':list(pins.values()),'exposure':'Manifest metadata includes author result totals; no author test or expectation body was read or executed. All independent expected objects were frozen before this metadata exposure.'}
 for x in binding['sourcePins']:assert pin(S/x['path'])=={k:x[k]for k in ('bytes','sha256')},x['path']
 if kind=='api':
  write(B/'candidate-binding-r1.json',jb(binding));write(B/'candidate-source-freeze-r1.json',manifest)
 else:assert json.loads((B/'candidate-binding-r1.json').read_bytes())==binding
 driver=B/('receive-api-r2.py'if kind=='api'else'receive-cli-r2.py')
 expected='b81a649b9775fa55dc2f0305d325efceb8f2d2cdf051259fd41e3070af34b712'if kind=='api'else'07da6ee077b4b4295e6c41f2a7b5ae43b2babd1bd1747f8a35a88bede7121440'
 assert pin(driver)['sha256']==expected
 memory=int(next(x.split()[1]for x in pathlib.Path('/proc/meminfo').read_text().splitlines()if x.startswith('MemAvailable:')))*1024
 free=shutil.disk_usage(B).free;owned=sum(x.stat().st_size for x in B.rglob('*')if x.is_file())
 assert memory>=2147483648 and free>=268435456 and owned<536870912
 receipt['admission']={'memoryAvailable':memory,'diskFree':free,'namespaceBytes':owned};receipt['driver']={'path':str(driver),**pin(driver)}
 py='/home/jacob/canvaspilot-enrollments-env-65ae877160f6/bin/python'
 receipt['python']={'path':py,'realpath':os.path.realpath(py),**pin(pathlib.Path(os.path.realpath(py)))}
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
 with (R/'stdout').open('xb')as out,(R/'stderr').open('xb')as err:
  p=subprocess.Popen([py,'-P','-B',str(driver),str(B/'candidate-binding-r1.json')],cwd=B,env=env,stdout=out,stderr=err,start_new_session=True)
  receipt['childPid']=p.pid
  try:p.wait(timeout=65 if kind=='cli'else 45)
  except subprocess.TimeoutExpired:
   receipt['timedOut']=True;os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno())
 receipt['exit']=p.returncode
 receipt['stdout']=pin(R/'stdout');receipt['stderr']=pin(R/'stderr')
 receipt['childAbsent']=not pathlib.Path('/proc',str(p.pid)).exists()
 changed=[x['path']for x in binding['sourcePins']if pin(S/x['path'])!={k:x[k]for k in ('bytes','sha256')}]
 receipt['sourceUnchanged']=not changed
 inner=B/(kind+'-r2')/'receipt.json'
 if inner.exists():receipt['inner']={'path':str(inner),**pin(inner)};receipt['innerPassed']=json.loads(inner.read_bytes())['passed']
 receipt['passed']=p.returncode==0 and receipt.get('innerPassed')is True and not changed and receipt['childAbsent']and not receipt.get('timedOut')
except BaseException as e:receipt['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
finally:
 if p is not None and p.poll()is None:
  os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5);receipt['passed']=False
 receipt['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 write(R/'receipt.json',jb(receipt))
print(json.dumps(receipt,ensure_ascii=False))
raise SystemExit(0 if receipt['passed']else 1)
