import assert from 'node:assert/strict';
import {readFile,writeFile,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {openBrowser,sha256,until} from './browser-transport.mjs';
const B='/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c';
const R=join(B,'browser-r2'), binding=JSON.parse(await readFile(join(B,'candidate-binding-r1.json'),'utf8'));
const cli=JSON.parse(await readFile(join(B,'cli-r2/receipt.json'),'utf8'));
const input=cli.html.path,expected=await readFile(join(B,'expected-cli-report.json')),want=JSON.parse(expected);
assert.equal(sha256(expected),'f500f882f5fba4c3bd9c409d222536adbf4cf9b3b8f8e17270c808752d3a30ab');
assert.equal(sha256(await readFile(input)),'67fc3709a0821f0cf66b4e6f8c703761247bcc6f6fe6001f01f0754ecb05e66a');
let browser;const receipt={schema:'canvas.comparison.independent-browser/1',started:new Date().toISOString(),pid:process.pid,groups:[],passed:false,input:cli.html,exposure:'HTML structural selectors were bound after all expected complete objects and API/CLI cases were frozen; no expected value derives from candidate output.'};
async function pins(){for(const p of binding.sourcePins)assert.equal(sha256(await readFile(join(binding.sourceRoot,p.path))),p.sha256,p.path);}
async function tabTo(selector){for(let n=0;n<16;n++){if(await browser.evaluate('document.activeElement === document.querySelector('+JSON.stringify(selector)+')'))return n;await browser.key('Tab');}throw Error('Tab did not reach '+selector);}
try{
 await pins();browser=await openBrowser(R,'/snap/chromium/current/usr/lib/chromium-browser/chrome');receipt.chrome={pid:browser.childPid,profile:browser.profile,version:browser.version};
 await browser.navigate(input,1280,900);
 receipt.initial=await browser.evaluate('({title:document.title,scripts:document.scripts.length,details:[...document.querySelectorAll("details")].map(e=>({id:e.id,open:e.open})),anchors:[...document.querySelectorAll("a")].map(e=>({id:e.id,download:e.download}))})');
 assert.equal(receipt.initial.scripts,0);assert.equal(receipt.initial.anchors.length,1);
 const activations=[];
 for(const which of ['before','after']){
  const selector='#'+which+'-source summary',tabs=await tabTo(selector);
  await browser.key('Enter');
  const disclosure=await browser.evaluate('(()=>{const d=document.querySelector("#'+which+'-source");return {open:d.open,focused:document.activeElement===d.querySelector("summary"),text:d.querySelector("pre").textContent,visible:d.querySelector("pre").getBoundingClientRect().height>0}})()');
  assert.ok(disclosure.open&&disclosure.focused&&disclosure.visible);assert.deepEqual(JSON.parse(disclosure.text),want[which]);
  activations.push({which,tabs,open:disclosure.open,focused:disclosure.focused,sourceBytes:Buffer.byteLength(disclosure.text),sourceSha256:sha256(Buffer.from(disclosure.text))});
 }
 // Tab wraps through document chrome to the report's sole download link.
 const tabs=await tabTo('#download-json');const count=browser.downloadsStarted.length;await browser.key('Enter');
 const start=await until(()=>browser.downloadsStarted[count],'physical download start');
 const completed=await until(()=>{const p=browser.downloadsCompleted.get(start.guid);assert.notEqual(p?.state,'canceled');return p?.state==='completed'?p:false;},'physical download completion');
 const path=join(R,'downloads',start.guid);await until(async()=>{try{return(await stat(path)).isFile();}catch{return false;}},'physical download file');
 const actual=await readFile(path);assert.equal(start.suggestedFilename,'canvas-page-revisions-42-7-vs-19.json');assert.deepEqual(actual,expected);
 assert.equal(browser.downloadsStarted.length,1);assert.equal(browser.errors.length,0);
 assert.equal(browser.requests.filter(x=>!x.startsWith('file:')&&!x.startsWith('data:')).length,0);
 receipt.groups.push({name:'I6-independent-CLI-report-physical-payload',passed:true,keyboardDisclosures:activations,download:{path,suggestedFilename:start.suggestedFilename,bytes:actual.length,sha256:sha256(actual),completed,tabs},screenshot:await browser.screenshot('report-open-desktop.png')});
 receipt.requests=browser.requests;receipt.runtimeExceptions=browser.errors;receipt.downloadEvents=browser.downloadsStarted;receipt.passed=true;
}catch(error){receipt.failure={name:error.name,message:error.message,stack:error.stack};}
finally{
 if(browser){receipt.requests=browser.requests;receipt.runtimeExceptions=browser.errors;try{await browser.close();receipt.browserClosed=true;}catch(error){receipt.passed=false;receipt.closeFailure={message:error.message,stack:error.stack};}}
 try{await pins();assert.equal(sha256(await readFile(input)),cli.html.sha256);receipt.sourceAndInputUnchanged=true;}catch(error){receipt.passed=false;receipt.pinFailure=error.message;}
 receipt.finished=new Date().toISOString();await writeFile(join(R,'receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
}
console.log(JSON.stringify({passed:receipt.passed,groups:receipt.groups.length,failure:receipt.failure,path:join(R,'receipt.json'),sha256:sha256(await readFile(join(R,'receipt.json')))}));
process.exitCode=receipt.passed?0:1;
