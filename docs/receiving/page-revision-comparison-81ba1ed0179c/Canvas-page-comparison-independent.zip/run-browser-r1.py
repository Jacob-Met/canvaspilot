import pathlib,os,json,hashlib,subprocess,signal,shutil,datetime,time,traceback
B=pathlib.Path('/home/jacob/canvas-revision-comparison-independent-81ba1ed0179c');R=B/'browser-r1';T=B/'tmp-browser-r1';R.mkdir(mode=0o700);T.mkdir(mode=0o700)
def sha(b):return hashlib.sha256(b).hexdigest()
def jb(v):return (json.dumps(v,indent=2)+'\n').encode()
def pin(p):b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b)}
def owned():
 a=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:cmd=(p/'cmdline').read_bytes().split(b'\0')
  except (FileNotFoundError,PermissionError,ProcessLookupError):continue
  if any(x.startswith(('--user-data-dir='+str(B)+'/profile-').encode())for x in cmd):a.append(int(p.name))
 return a
v={'schema':'canvas.comparison.independent-browser-outer/1','wrapperPid':os.getpid(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':False};p=None
try:
 assert os.getuid()==1000 and os.uname().nodename=='hamon-thinkpad'
 memory=int(next(x.split()[1]for x in pathlib.Path('/proc/meminfo').read_text().splitlines()if x.startswith('MemAvailable:')))*1024
 free=shutil.disk_usage(B).free;footprint=sum(x.stat().st_size for x in B.rglob('*')if x.is_file())
 assert memory>=2147483648 and free>=268435456 and footprint<536870912
 assert not owned()and not list(B.glob('profile-*'))
 v['admission']={'memoryAvailable':memory,'diskFree':free,'namespaceBytes':footprint,'ownedBrowserCount':0}
 for name,h in [('receive-browser-r1.mjs','0cfd5c5538bd1c4ec3c533216800059d466db631a04ff46e651acb81c2aecc07'),('browser-transport.mjs','154831f3fc1a133a91eb490914e6c9e1b374852bb39ff7953a44e48af5185546')]:assert pin(B/name)['sha256']==h
 env={**os.environ,'TMPDIR':str(T),'TEMP':str(T),'TMP':str(T)}
 with(R/'stdout').open('xb')as out,(R/'stderr').open('xb')as err:
  p=subprocess.Popen(['/usr/bin/node',str(B/'receive-browser-r1.mjs')],cwd=B,env=env,stdout=out,stderr=err,start_new_session=True);v['nodePid']=p.pid
  try:p.wait(timeout=75)
  except subprocess.TimeoutExpired:
   v['timedOut']=True;os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno())
 v['exit']=p.returncode;v['stdout']=pin(R/'stdout');v['stderr']=pin(R/'stderr');v['nodeAbsent']=not pathlib.Path('/proc',str(p.pid)).exists()
 inner=R/'receipt.json'
 if inner.exists():v['inner']={'path':str(inner),**pin(inner)};v['innerPassed']=json.loads(inner.read_bytes())['passed']
 v['ownedBrowserPids']=owned();v['profiles']=[str(x)for x in B.glob('profile-*')]
 if not v['ownedBrowserPids']and not v['profiles']:shutil.rmtree(T);v['tmpRemoved']=not T.exists()
 v['passed']=p.returncode==0 and v.get('innerPassed')is True and v['nodeAbsent']and not v['ownedBrowserPids']and not v['profiles']and v.get('tmpRemoved')and not v.get('timedOut')
except BaseException as e:v['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
finally:
 if p is not None and p.poll()is None:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5);v['passed']=False
 v['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(R/'outer-receipt.json').open('xb')as f:f.write(jb(v));f.flush();os.fsync(f.fileno())
print(json.dumps(v));raise SystemExit(0 if v['passed']else 1)
