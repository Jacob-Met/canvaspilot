import pathlib,os,sys,hashlib,json,subprocess,time,signal,datetime
B=pathlib.Path('/home/jacob/canvas-page-comparison-81ba1ed0179c');D=B/'evidence/receive-browser-r1.mjs'
assert hashlib.sha256(D.read_bytes()).hexdigest()=='bd7d8560d746a3948bb57d2e82c177ea17cea728b97c6da787ad2291c2bdde9f'
assert hashlib.sha256(pathlib.Path('/usr/bin/node').read_bytes()).hexdigest()=='d0efb6fcb9d023ba4e2b160ec2384dc28fe4f17732141ef47f676828fa960505'
mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
v=os.statvfs(B);assert mem>=2*1024**3 and v.f_bavail*v.f_frsize>=256*1024**2
W=B/'browser-r1-wrapper';W.mkdir(mode=0o700)
rec={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapperPid':os.getpid(),'driverSha256':'bd7d8560d746a3948bb57d2e82c177ea17cea728b97c6da787ad2291c2bdde9f','memoryBefore':mem,'diskBefore':v.f_bavail*v.f_frsize,'passed':False};p=None
try:
 with (W/'stdout.txt').open('xb') as out,(W/'stderr.txt').open('xb') as err:
  p=subprocess.Popen(['/usr/bin/node',str(D)],stdout=out,stderr=err,start_new_session=True,env=dict(os.environ))
  rec['nodePid']=p.pid;t=time.monotonic();rec['exitCode']=p.wait(timeout=95);rec['elapsedSeconds']=time.monotonic()-t
 assert rec['exitCode']==0
 rr=B/'browser-r1/receipt.json';b=rr.read_bytes();r=json.loads(b);assert r['passed'] and len(r['groups'])==3 and len(r['downloads'])==1
 rec['result']={'path':str(rr),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'groups':len(r['groups']),'downloads':len(r['downloads'])};rec['passed']=True
except BaseException as e:
 rec['error']=repr(e)
finally:
 if p is not None and p.poll() is None:
  rec['forcedNodeCleanup']=True
  try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
  except BaseException as e:rec['cleanupError']=repr(e)
 rec['nodeAbsent']=p is None or not pathlib.Path('/proc/'+str(p.pid)).exists()
 rec['passed']=rec['passed'] and rec['nodeAbsent'] and not rec.get('forcedNodeCleanup')
 for n in ['stdout.txt','stderr.txt']:
  b=(W/n).read_bytes();rec[n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 b=(json.dumps(rec,indent=2)+'\n').encode()
 with (W/'receipt.json').open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 print(json.dumps(rec))
 if not rec['passed']:sys.exit(1)
