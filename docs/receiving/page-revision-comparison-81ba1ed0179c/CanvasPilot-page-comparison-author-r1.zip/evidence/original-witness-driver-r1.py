import pathlib,json,hashlib,subprocess,os,sys,datetime
from copy import deepcopy
from urllib.parse import quote
B=pathlib.Path('/home/jacob/canvas-page-comparison-81ba1ed0179c')
S=B/'source'
OUT=B/'evidence/original-witness-r1'
OUT.mkdir(mode=0o700)
def sha(x):return hashlib.sha256(x).hexdigest()
c=json.loads((B/'evidence/contract-before-candidate.json').read_text())
f=json.loads((B/'evidence/author-expectations-before-candidate.json').read_text())
before={r['path']:sha((S/r['path']).read_bytes()) for r in c['originalPins']}
assert all(before[r['path']]==r['sha256'] for r in c['originalPins'])
assert not (S/'src/canvaspilot/page_revision_comparison.py').exists()
mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
v=os.statvfs(B);assert mem>=2*1024**3 and v.f_bavail*v.f_frsize>=256*1024**2
rec={'at':datetime.datetime.now(datetime.UTC).isoformat(),'python':sys.executable,'pythonVersion':sys.version,'pythonExecutableSha256':sha(pathlib.Path(sys.executable).read_bytes()),'candidateAbsent':True,'memoryBefore':mem,'diskBefore':v.f_bavail*v.f_frsize,'passed':False}
try:
 argv=[sys.executable,'-B','-m','canvaspilot.cli','compare-page-revisions','42','week-one','--before','7','--after','9','--out',str(OUT/'must-not-exist.html')]
 p=subprocess.run(argv,cwd=S,env=dict(os.environ,PYTHONPATH=str(S/'src')),capture_output=True,timeout=15)
 for n,x in [('command.stdout',p.stdout),('command.stderr',p.stderr)]:
  with (OUT/n).open('xb') as z:z.write(x)
 assert p.returncode==2 and p.stdout==b'' and b"invalid choice: 'compare-page-revisions'" in p.stderr and not (OUT/'must-not-exist.html').exists()
 rec['missingCommand']={'argv':argv,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stderrBytes':len(p.stderr),'stderrSha256':sha(p.stderr)}
 sys.path.insert(0,str(S/'src'))
 from canvaspilot.page_revisions import read_page_revision
 class Recorded:
  def __init__(self):self.calls=[]
  def request(self,method,path,*,params):
   self.calls.append({'method':method,'path':path,'params':deepcopy(params)})
   assert method=='GET' and params=={'summary':False}
   stem='/api/v1/courses/42/pages/'+quote(f['selection']['page_url'],safe='')+'/revisions/'
   assert path in [stem+'7',stem+'9']
   return deepcopy(f['rawBefore'] if path.endswith('/7') else f['rawAfter'])
 client=Recorded()
 a=read_page_revision(client,'0042',f['selection']['page_url'],'0007',summary=False)
 z=read_page_revision(client,'0042',f['selection']['page_url'],9,summary=False)
 assert a['revision']==f['rawBefore'] and z['revision']==f['rawAfter']
 assert a['body_text']=='Start Keep Gone' and z['body_text']=='Start Keep Added'
 outputs={'attribution':'Unchanged original117 reader+original strip_html executed once per two manually authored fictional records; no comparison source or author test used.','before':a,'after':z,'calls':client.calls,'originalCode':c['originalPins']}
 x=(json.dumps(outputs,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
 with (OUT/'original-envelope-outputs.json').open('xb') as t:t.write(x);t.flush();os.fsync(t.fileno())
 assert len(client.calls)==2
 rec['originalEnvelopeOutputs']={'bytes':len(x),'sha256':sha(x),'calls':2,'completeRawRecordsExact':True,'bodyTexts':[a['body_text'],z['body_text']]}
 assert all(sha((S/p).read_bytes())==h for p,h in before.items())
 assert subprocess.check_output(['git','-C',str(S),'status','--porcelain','--untracked-files=no'])==b''
 rec['originalInputsUnchanged']=len(before);rec['passed']=True
except BaseException as e:rec['error']={'type':type(e).__name__,'message':str(e)}
finally:
 x=(json.dumps(rec,ensure_ascii=False,indent=2)+'\n').encode()
 with (OUT/'receipt.json').open('xb') as t:t.write(x);t.flush();os.fsync(t.fileno())
 print(json.dumps({'passed':rec['passed'],'receipt':str(OUT/'receipt.json'),'bytes':len(x),'sha256':sha(x),'error':rec.get('error')}))
 if not rec['passed']:sys.exit(1)
