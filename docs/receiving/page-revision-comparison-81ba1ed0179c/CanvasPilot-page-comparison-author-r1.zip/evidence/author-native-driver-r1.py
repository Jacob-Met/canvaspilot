import pathlib,hashlib,json,os,sys,subprocess,time,signal,shutil,datetime,importlib.util
B=pathlib.Path('/home/jacob/canvas-page-comparison-81ba1ed0179c')
S=B/'source'; O=B/'evidence/author-native-r1'; O.mkdir(mode=0o700)
P='/home/jacob/canvaspilot-enrollments-env-65ae877160f6/bin/python'
def sha(b):return hashlib.sha256(b).hexdigest()
def mem():
 return int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
def ownbytes():return sum(p.stat().st_size for p in B.rglob('*') if p.is_file() and not p.is_symlink())
def admit():
 r={'memoryAvailable':mem(),'diskFree':shutil.disk_usage(B).free,'ownBytes':ownbytes()}
 assert r['memoryAvailable']>=2147483648,r
 assert r['diskFree']>=268435456,r
 assert r['ownBytes']<=536870912,r
 return r
def groups(pgid):
 result=[]
 for p in pathlib.Path('/proc').iterdir():
  if p.name.isdigit():
   try:
    raw=(p/'stat').read_text();tail=raw.rsplit(')',1)[1].split()
    if int(tail[2])==pgid:result.append({'pid':int(p.name),'state':tail[0]})
   except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return result
files={}
for p in S.rglob('*'):
 if p.is_file() and '.git' not in p.relative_to(S).parts:files[str(p.relative_to(S))]=sha(p.read_bytes())
rec={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceBefore':files,'pythonSha256':sha(pathlib.Path(P).read_bytes()),'passed':False,'commands':[]}
env=dict(os.environ,PYTHONPATH=str(S/'src'),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',RUFF_NO_CACHE='1')
try:
 rec['admission']=admit()
 commands=[
  ('focused-tests',[P,'-B','-m','pytest','-q','-p','no:cacheprovider','tests/test_page_revision_comparison.py','tests/test_page_revision_comparison_process.py','--basetemp',str(O/'pytest-temp')]),
  ('ruff',[P,'-B','-m','ruff','check','--no-cache','src/canvaspilot/page_revision_comparison.py','src/canvaspilot/cli.py','tests/test_page_revision_comparison.py','tests/test_page_revision_comparison_process.py'])]
 for name,cmd in commands:
  row={'name':name,'command':cmd,'admission':admit()};rec['commands'].append(row)
  started=time.monotonic();p=subprocess.Popen(cmd,cwd=S,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);row['pid']=p.pid
  try:
   while True:
    try:out,err=p.communicate(timeout=.5);break
    except subprocess.TimeoutExpired:
     assert time.monotonic()-started<60,'command deadline'
     assert mem()>=2147483648,'memory floor'
     assert shutil.disk_usage(B).free>=268435456,'disk floor'
   row.update(exit=p.returncode,seconds=time.monotonic()-started,stdoutBytes=len(out),stderrBytes=len(err))
   (O/(name+'.stdout')).write_bytes(out);(O/(name+'.stderr')).write_bytes(err)
   row['stdoutSha256']=sha(out);row['stderrSha256']=sha(err)
   assert len(out)+len(err)<=2097152,'diagnostic cap'
  finally:
   remaining=groups(p.pid);row['remainingBeforeCleanup']=remaining
   if remaining:
    os.killpg(p.pid,signal.SIGKILL)
    p.communicate(timeout=5)
   row['remainingAfterCleanup']=groups(p.pid)
  assert not row['remainingBeforeCleanup'],'clean settlement'
  row['finalAdmission']=admit()
 rec['sourceUnchanged']=all(sha((S/k).read_bytes())==v for k,v in files.items())
 rec['pythonUnchanged']=sha(pathlib.Path(P).read_bytes())==rec['pythonSha256']
 rec['passed']=all(r.get('exit')==0 for r in rec['commands']) and rec['sourceUnchanged'] and rec['pythonUnchanged']
except BaseException as e:rec['error']=type(e).__name__+': '+str(e)
finally:
 data=(json.dumps(rec,ensure_ascii=False,indent=2)+'\n').encode();(O/'receipt.json').write_bytes(data)
 print(json.dumps({'passed':rec['passed'],'receipt':str(O/'receipt.json'),'bytes':len(data),'sha256':sha(data),'commands':[{k:r.get(k) for k in ('name','pid','exit','seconds')} for r in rec['commands']],'error':rec.get('error')}),flush=True)
sys.exit(0 if rec['passed'] else 1)
