import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import assert from "node:assert/strict";
import {spawn,spawnSync} from "node:child_process";
import {pathToFileURL} from "node:url";
const base="/home/jacob/canvas-page-comparison-81ba1ed0179c";
const root=path.join(base,"browser-r1"),profile="/home/jacob/cpc81-p",tmp="/home/jacob/cpc81-t";
const sha=b=>crypto.createHash("sha256").update(b).digest("hex"),sleep=ms=>new Promise(r=>setTimeout(r,ms));
const fixed=(p,h)=>{const b=fs.readFileSync(p);assert.equal(sha(b),h);return JSON.parse(b);};
const freezePath=path.join(base,"evidence/source-freeze-r1.json");
const freeze=fixed(freezePath,"d86096b6066c64f76162c28e434570c7290969d7eb14bbf975a42a50377373cc");
const inputPath=path.join(base,"evidence/browser-input-freeze-r1.json");
const inputs=fixed(inputPath,"438462a09dd0b437f4a260fd8be72cb064aab1d00f4b8fd8647693853a1e75d9");
const expectedBytes=fs.readFileSync(path.join(base,"browser-input/expected-report.json")),expected=JSON.parse(expectedBytes);
const page=path.join(base,"browser-input/page-revision-comparison.html");
const guardRows=[...freeze.files.map(x=>({...x,path:path.join(base,"source",x.path)})),...inputs.files,{path:freezePath,sha256:"d86096b6066c64f76162c28e434570c7290969d7eb14bbf975a42a50377373cc"},{path:inputPath,sha256:"438462a09dd0b437f4a260fd8be72cb064aab1d00f4b8fd8647693853a1e75d9"},{path:"/usr/bin/node",sha256:"d0efb6fcb9d023ba4e2b160ec2384dc28fe4f17732141ef47f676828fa960505"}];
const pre=guardRows.map(r=>{const b=fs.readFileSync(r.path),s=fs.statSync(r.path);assert.equal(sha(b),r.sha256);if(r.bytes!==undefined)assert.equal(b.length,r.bytes);return{...r,bytes:b.length,ino:s.ino,mtimeMs:s.mtimeMs};});
function used(p){if(!fs.existsSync(p))return 0;let n=0;for(const e of fs.readdirSync(p,{withFileTypes:true})){const f=path.join(p,e.name);if(e.isDirectory())n+=used(f);else if(e.isFile())n+=fs.statSync(f).size;}return n;}
function capacity(){const v=fs.statfsSync(base);return{memory:Number(fs.readFileSync("/proc/meminfo","utf8").match(/^MemAvailable:\s+(\d+)/m)[1])*1024,disk:v.bavail*v.bsize,owned:used(base)+used(profile)+used(tmp)};}
function admit(c){assert.ok(c.memory>=2*1024**3,"2GiB memory floor");assert.ok(c.disk>=256*1024**2,"256MiB ordinary disk floor");assert.ok(c.owned<=512*1024**2,"512MiB own namespace cap");}
for(const p of[root,profile,tmp])assert.ok(!fs.existsSync(p),"new exclusive "+p);
const before=capacity();admit(before);
const census=spawnSync("ps",["-eo","pid=,ppid=,stat=,comm=,args="],{encoding:"utf8"});assert.equal(census.status,0);
const foreignChrome=census.stdout.split("\n").filter(x=>["chrome","chromium"].includes(x.trim().split(/\s+/)[3]));
fs.mkdirSync(root,{mode:0o700});fs.mkdirSync(profile,{mode:0o700});fs.mkdirSync(tmp,{mode:0o700});
const downloads=path.join(root,"downloads");fs.mkdirSync(downloads);
const rec={schema:"canvaspilot.page-comparison.author-browser.v1",at:new Date().toISOString(),nodePid:process.pid,sourceFreezeSha256:sha(fs.readFileSync(freezePath)),method:"Ordinary passive generated report; DOM observations and trusted keyboard input. One actual complete JSON download. No injected product API or script.",foreignChromeObservedUntouched:foreignChrome,groups:[],downloads:[],choosers:[],requests:[],errors:[],capacityBefore:before,passed:false};
const chrome="/snap/chromium/current/usr/lib/chromium-browser/chrome",argv=["--headless=new","--disable-gpu","--no-first-run","--no-default-browser-check","--disable-background-networking","--disable-component-update","--disable-sync","--disable-extensions","--disable-dev-shm-usage","--remote-debugging-port=0","--user-data-dir="+profile,"--window-size=1280,1000","about:blank"];
const out=fs.openSync(path.join(root,"chrome.stdout"),"wx"),err=fs.openSync(path.join(root,"chrome.stderr"),"wx");
let child,exited=false,done,cdp,session,monitor,deadline,guardError=null;
class CDP{constructor(ws){this.ws=ws;this.id=0;this.pending=new Map();this.listeners=[];ws.addEventListener("message",ev=>{const m=JSON.parse(ev.data);if(m.id){const p=this.pending.get(m.id);if(!p)return;clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}else for(const f of this.listeners)f(m);});ws.addEventListener("close",()=>{for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(Error("CDP closed"));}this.pending.clear();});}call(method,params={},sessionId){return new Promise((resolve,reject)=>{const id=++this.id,timer=setTimeout(()=>{this.pending.delete(id);reject(Error("CDP timeout "+method));},10000);this.pending.set(id,{resolve,reject,timer});this.ws.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));});}}
const call=(m,p={})=>{if(guardError)throw guardError;return cdp.call(m,p,session);};
async function ev(expression){const r=await call("Runtime.evaluate",{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
async function wait(expression){const end=Date.now()+8000;while(Date.now()<end){if(await ev(expression))return;await sleep(40);}throw Error("condition deadline "+expression);}
async function click(s){const p=await ev("(()=>{const e=document.querySelector("+JSON.stringify(s)+");e.scrollIntoView({block:'center',behavior:'instant'});const r=e.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2,h=document.elementFromPoint(x,y);if(!(h===e||e.contains(h)))throw Error('obscured '+e.id);return{x,y};})()");for(const [type,rest]of[["mouseMoved",{}],["mousePressed",{button:"left",clickCount:1}],["mouseReleased",{button:"left",clickCount:1}]])await call("Input.dispatchMouseEvent",{type,...p,...rest});}
async function key(key,code,v,modifiers=0){for(const type of["keyDown","keyUp"])await call("Input.dispatchKeyEvent",{type,key,code,windowsVirtualKeyCode:v,nativeVirtualKeyCode:v,modifiers,...(key==="Enter"&&type==="keyDown"?{text:"\r",unmodifiedText:"\r"}:{})});}

async function shot(name){const r=await call("Page.captureScreenshot",{format:"png",captureBeyondViewport:false}),b=Buffer.from(r.data,"base64");fs.writeFileSync(path.join(root,name),b,{flag:"wx"});return{path:name,bytes:b.length,sha256:sha(b)};}
function pass(id,details){rec.groups.push({id,passed:true,...details});}
try{
 child=spawn(chrome,argv,{env:{...process.env,TMPDIR:tmp,TMP:tmp,TEMP:tmp},stdio:["ignore",out,err],detached:true});rec.chromePid=child.pid;rec.argv=[chrome,...argv];
 done=new Promise(resolve=>{child.on("exit",(code,signal)=>{exited=true;rec.chromeExit={code,signal};resolve();});child.on("error",e=>{rec.spawnError=String(e);resolve();});});
 const kill=()=>{if(child?.pid&&!exited)try{process.kill(-child.pid,"SIGTERM");}catch{}};
 deadline=setTimeout(()=>{guardError=Error("75s total receiving deadline");kill();},75000);monitor=setInterval(()=>{try{admit(capacity());}catch(e){guardError=e;kill();}},1000);
 const portFile=path.join(profile,"DevToolsActivePort"),end=Date.now()+20000;
 while(!fs.existsSync(portFile)){if(exited)throw Error("Chrome exited before CDP");if(Date.now()>end)throw Error("20s CDP startup");await sleep(50);}
 const [port,browserPath]=fs.readFileSync(portFile,"utf8").trim().split(/\r?\n/),ws=new WebSocket("ws://127.0.0.1:"+port+browserPath);
 await new Promise((resolve,reject)=>{ws.addEventListener("open",resolve,{once:true});ws.addEventListener("error",reject,{once:true});});cdp=new CDP(ws);rec.browser=await cdp.call("Browser.getVersion");
 const t=await cdp.call("Target.createTarget",{url:"about:blank"});session=(await cdp.call("Target.attachToTarget",{targetId:t.targetId,flatten:true})).sessionId;
 cdp.listeners.push(m=>{if(m.method==="Browser.downloadWillBegin")rec.downloads.push({...m.params,state:"started"});if(m.method==="Browser.downloadProgress"){const d=rec.downloads.find(d=>d.guid===m.params.guid);if(d)Object.assign(d,m.params);}if(m.sessionId!==session)return;if(m.method==="Page.fileChooserOpened")rec.choosers.push(m.params);if(m.method==="Network.requestWillBeSent")rec.requests.push(m.params.request.url);if(m.method==="Runtime.exceptionThrown")rec.errors.push(m.params);});
 await cdp.call("Browser.setDownloadBehavior",{behavior:"allowAndName",downloadPath:downloads,eventsEnabled:true});for(const m of["Page.enable","Runtime.enable","Network.enable"])await call(m);
 await call("Page.setInterceptFileChooserDialog",{enabled:true});await call("Network.setBlockedURLs",{urls:["http://*","https://*","ws://*","wss://*"]});
 await call("Emulation.setDeviceMetricsOverride",{width:1280,height:1000,deviceScaleFactor:1,mobile:false});

 await call("Page.navigate",{url:pathToFileURL(page).href});await wait("document.querySelector('#download-json') && document.readyState==='complete'");
 const observed=await ev("({heading:document.querySelector('h1').textContent,before:JSON.parse(document.querySelector('#before-source pre').textContent),after:JSON.parse(document.querySelector('#after-source pre').textContent),locator:JSON.parse(document.querySelector('#page-locator').textContent),rows:[...document.querySelectorAll('tbody tr')].map(r=>({kind:r.cells[0].textContent,before_line:r.cells[1].textContent==='—'?null:Number(r.cells[1].textContent),after_line:r.cells[2].textContent==='—'?null:Number(r.cells[2].textContent),text:JSON.parse(r.cells[3].textContent)})),activeTags:[...document.querySelectorAll('script,iframe,img,form,link')].map(x=>x.tagName),scroll:document.documentElement.scrollWidth,width:innerWidth})");
 assert.equal(observed.heading,"Page revision comparison");assert.deepEqual(observed.before,expected.before);assert.deepEqual(observed.after,expected.after);assert.equal(observed.locator,expected.selection.page_url);assert.deepEqual(observed.rows,expected.comparison.line_diff.rows);assert.deepEqual(observed.activeTags,[]);assert.ok(observed.scroll<=1280);
 pass("G1",{observed,screenshot:await shot("desktop-report.png")});
 async function tabToSelector(selector,back=false){for(let i=0;i<12;i++){if(await ev("document.activeElement===document.querySelector("+JSON.stringify(selector)+")"))return;await key("Tab","Tab",9,back?8:0);}throw Error("Keyboard target "+selector);}
 await tabToSelector("#before-source summary");await key("Enter","Enter",13);assert.equal(await ev("document.querySelector('#before-source').open"),true);
 await tabToSelector("#after-source summary");await key("Enter","Enter",13);assert.equal(await ev("document.querySelector('#after-source').open"),true);
 await tabToSelector("#download-json",true);assert.equal(await ev("document.activeElement.id"),"download-json");
 const n=rec.downloads.length;await key("Enter","Enter",13);
 const downloadEnd=Date.now()+6000;while(rec.downloads.length===n||rec.downloads.at(-1).state!=="completed"){if(Date.now()>downloadEnd)throw Error("physical JSON download deadline");await sleep(25);}
 assert.equal(rec.downloads.length,1);const actual=rec.downloads[0],actualPath=path.join(downloads,actual.guid),actualBytes=fs.readFileSync(actualPath);
 assert.equal(actual.suggestedFilename,"canvas-page-revisions-42-7-vs-9.json");assert.deepEqual(actualBytes,expectedBytes);assert.deepEqual(JSON.parse(actualBytes),expected);actual.bytes=actualBytes.length;actual.sha256=sha(actualBytes);
 fs.writeFileSync(path.join(root,"actual-comparison.json"),actualBytes,{flag:"wx",mode:0o600});
 pass("G2",{keyboardDisclosures:true,keyboardDownload:true,actual:{path:actualPath,bytes:actualBytes.length,sha256:sha(actualBytes),suggestedFilename:actual.suggestedFilename}});
 await click("#before-source summary");await click("#after-source summary");
 await call("Emulation.setDeviceMetricsOverride",{width:390,height:1000,deviceScaleFactor:1,mobile:false});
 await ev("scrollTo(0,0)");const layout=await ev("({width:innerWidth,scroll:document.documentElement.scrollWidth,tableWidth:document.querySelector('table').getBoundingClientRect().width,downloadWidth:document.querySelector('#download-json').getBoundingClientRect().width,body:document.body.innerText})");
 assert.equal(layout.width,390);assert.ok(layout.scroll<=390,"390px containment");const narrow=await shot("narrow-report.png");
 await call("Network.emulateNetworkConditions",{offline:true,latency:0,downloadThroughput:0,uploadThroughput:0});await call("Page.reload",{ignoreCache:true});await wait("document.querySelector('#download-json') && document.readyState==='complete'");
 assert.deepEqual(await ev("JSON.parse(document.querySelector('#before-source pre').textContent)"),expected.before);assert.deepEqual(await ev("JSON.parse(document.querySelector('#after-source pre').textContent)"),expected.after);
 await call("Emulation.setEmulatedMedia",{media:"print"});const print=await ev("({details:[...document.querySelectorAll('details')].map(e=>getComputedStyle(e).display),download:getComputedStyle(document.querySelector('#download-json')).display,table:getComputedStyle(document.querySelector('table')).display,policy:document.querySelector('.scope .note').textContent})");
 assert.deepEqual(print.details,["none","none"]);assert.equal(print.download,"none");assert.notEqual(print.table,"none");assert.ok(print.policy.includes("Printing includes"));await call("Emulation.setEmulatedMedia",{media:""});
 assert.deepEqual(rec.errors,[]);assert.ok(rec.requests.every(u=>u.startsWith("file:")||u.startsWith("data:")));assert.equal(rec.downloads.length,1);
 pass("G3",{layout,screenshot:narrow,offlineReload:true,printMedia:print,physicalPrint:false,externalRequests:rec.requests.filter(u=>!u.startsWith("file:")&&!u.startsWith("data:"))});rec.passed=true;
}catch(e){rec.error={name:e.name,message:e.message,stack:e.stack};if(cdp&&!guardError)try{rec.failureDOM=await ev("({title:document.title,body:document.body.innerText,focus:document.activeElement?.id,values:[...document.querySelectorAll('select,textarea')].map(e=>({id:e.id,value:e.value}))})");rec.failureScreenshot=await shot("failure.png");}catch(x){rec.failureCaptureError=String(x);}}
finally{
 clearTimeout(deadline);clearInterval(monitor);
 if(cdp)try{await cdp.call("Browser.close");}catch(e){rec.browserCloseError=String(e);}
 if(done&&!exited)await Promise.race([done,sleep(4000)]);
 if(child?.pid&&!exited){rec.forcedCleanup=true;try{process.kill(-child.pid,"SIGTERM");}catch{}await Promise.race([done,sleep(2000)]);}
 if(child?.pid&&!exited){try{process.kill(-child.pid,"SIGKILL");}catch{}await Promise.race([done,sleep(1000)]);}
 if(cdp)cdp.ws.close();fs.closeSync(out);fs.closeSync(err);
 try{const scan=spawnSync("ps",["-eo","pid=,args="],{encoding:"utf8"});assert.equal(scan.status,0);rec.profileProcesses=scan.stdout.split("\n").filter(x=>x.includes("--user-data-dir="+profile));rec.childExited=exited;assert.ok(exited&&rec.profileProcesses.length===0);if(fs.existsSync(profile))fs.rmSync(profile,{recursive:true});if(fs.existsSync(tmp))fs.rmSync(tmp,{recursive:true});rec.profileAbsent=!fs.existsSync(profile);rec.tmpAbsent=!fs.existsSync(tmp);for(const r of pre){const st=fs.statSync(r.path);assert.equal(st.ino,r.ino);assert.equal(st.mtimeMs,r.mtimeMs);assert.equal(sha(fs.readFileSync(r.path)),r.sha256);}rec.guardedFilesUnchanged=pre.length;rec.capacityFinal=capacity();admit(rec.capacityFinal);}catch(e){rec.settlementError=String(e);rec.passed=false;}
 rec.passed=rec.passed&&!guardError&&!rec.forcedCleanup&&exited&&rec.profileAbsent&&rec.tmpAbsent;rec.finished=new Date().toISOString();
 const b=Buffer.from(JSON.stringify(rec,null,2)+"\n");fs.writeFileSync(path.join(root,"receipt.json"),b,{flag:"wx",mode:0o600});
 console.log(JSON.stringify({passed:rec.passed,groups:rec.groups.length,downloads:rec.downloads.length,chooserAdmissions:rec.choosers.length,receipt:path.join(root,"receipt.json"),bytes:b.length,sha256:sha(b),chromePid:child?.pid,childExited:exited,profileAbsent:rec.profileAbsent,tmpAbsent:rec.tmpAbsent,error:rec.error,settlementError:rec.settlementError}));if(!rec.passed)process.exitCode=1;
}
