from pathlib import Path
import datetime,hashlib,io,json,os,stat,tarfile
ROOT=Path("/home/jacob/hamon-canvas-activity-independent-68094585a1c2")
OUT=ROOT/"capsule-v1"
def pin(raw):
    return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(raw)).encode()+bytes([0])+raw).hexdigest()}
def write_new(path,raw):
    with path.open("xb") as handle: handle.write(raw)
def encoded(value):return (json.dumps(value,indent=2,ensure_ascii=False)+"\n").encode()
assert not OUT.exists(),"Existing capsule must be reconciled, never silently regenerated."
review_bytes=(ROOT/"source-review-v1.json").read_bytes()
assert pin(review_bytes)["sha256"]=="ef1623bad5d7412ab572c49172b8fae7a1c2e66e96bec00853720e8ab9ddac4c"
review=json.loads(review_bytes)
receipt_bytes=(ROOT/"candidate-v1/receipt.json").read_bytes()
assert pin(receipt_bytes)["sha256"]=="ec1428fde471fc55ab66c1f10c5d0625f4d3a66fde5268a2255bd077afbca5e3"
old=(ROOT/"CONTINUATION.json").read_bytes()
write_new(ROOT/"continuation-at-baseline-v1.json",old)
continuation=json.loads(old)
continuation["at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
continuation["candidate"]={"read":True,"executed":True,"source":"candidate-source-v1","manifest":"candidate-product-manifest-v1.json","admission":"candidate-admission-v1.json","receipt":"candidate-v1/receipt.json","receiptPin":pin(receipt_bytes),"pid":1880962,"exit":0,"groups":13,"realLoopbackGetRequests":27,"sourceReview":"source-review-v1.json","sourceReviewPin":pin(review_bytes),"allProtectedExact":True,"authorTestsReadOnlyAfterIndependentCompleted":True}
continuation["state"]={"implementedCandidateByRoot":False,"rootCandidateQualified":True,"sourceReviewed":True,"publishedSource":False,"integrated":False,"actionsTriggered":False,"requiredGatesWaived":False}
continuation["next"]="Author prepares exact five-path source plus separate author/root evidence Git objects; root receives full current-parent tree/modes and workflow triggers before a possible nondefault branch without PR. Hosted gates and integration remain held. Do not repeat the completed native receiver."
continuation["newCapacityRelay"]="Jacob-Met/hamon#143/comment6069262182: reported new VMs/LA7 setup, placement/installed readiness still requires actual receiving; no Actions release."
(ROOT/"CONTINUATION.json").write_bytes(encoded(continuation))
OUT.mkdir()
payloads={}
modes={}
for path in sorted(ROOT.rglob("*")):
    if OUT in path.parents or path==OUT or path.is_dir():continue
    assert path.is_file() and not path.is_symlink(),str(path)
    relative=path.relative_to(ROOT).as_posix()
    payloads[relative]=path.read_bytes()
    modes[relative]=stat.S_IMODE(path.stat().st_mode)
assert len([x for x in payloads if x.startswith("original/")])==33
assert len([x for x in payloads if x.startswith("candidate-source-v1/")])==34
manifest={"schema":"hamon.canvaspilot.activity-independent-capsule/1","actor":"chatgpt:68094585a1c2 / root","sealedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sourceCommit":review["sourceCommit"],"sourceTree":review["sourceTree"],"files":{name:{**pin(raw),"mode":oct(modes[name])} for name,raw in payloads.items()},"originalSourceFiles":33,"candidateSourceFiles":34,"originalBaselineGroups":3,"candidateGroups":13,"candidateRealLoopbackGetRequests":27,"frozenBeforeCandidate":True,"negativeObserverPreserved":"observer-initial-sdk-probe.json","sourceReview":pin(review_bytes),"requiredHostedGatesUnrun":True,"liveCanvas":False,"mcpBoundary":"Installed registered tool dispatch; not stdio.","actionsUsed":False}
manifest_bytes=encoded(manifest)
write_new(OUT/"MANIFEST.json",manifest_bytes)
all_payloads=payloads|{"MANIFEST.json":manifest_bytes}
all_modes=modes|{"MANIFEST.json":0o644}
archive=OUT/"canvaspilot-activity-independent-capsule.tar.gz"
with tarfile.open(archive,"x:gz") as handle:
    for name,raw in all_payloads.items():
        info=tarfile.TarInfo(name)
        info.size=len(raw)
        info.mode=all_modes[name]
        info.mtime=0
        info.uid=os.getuid()
        info.gid=os.getgid()
        handle.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,"r:gz") as handle:
    members=handle.getmembers()
    assert len(members)==len(all_payloads)
    assert len({m.name for m in members})==len(members)
    for member in members:
        assert member.isfile() and member.name in all_payloads
        assert member.mode==all_modes[member.name]
        received=handle.extractfile(member).read()
        assert received==all_payloads[member.name],member.name
assert all((ROOT/name).read_bytes()==raw for name,raw in payloads.items()),"Source/evidence changed during sealing"
archive_pin=pin(archive.read_bytes())
capsule={"schema":"hamon.canvaspilot.activity-independent-capsule-receipt/1","actor":"chatgpt:68094585a1c2 / root","at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"archive":{"path":str(archive),**archive_pin},"manifest":{"path":str(OUT/"MANIFEST.json"),**pin(manifest_bytes)},"memberCount":len(all_payloads),"allMembersBytesAndModesVerified":True,"allInputsUnchanged":True,"nativeOriginalGroups":3,"nativeCandidateGroups":13,"candidateLoopbackGetRequests":27,"candidateExecution":{"pid":1880962,"exit":0,"receipt":pin(receipt_bytes)},"sourceReview":pin(review_bytes),"sourcePublished":False,"integrated":False,"requiredHostedGatesUnrun":True,"actionsUsed":False,"repackInstruction":"Transfer these exact bytes. Do not regenerate the archive and label it the original."}
capsule_bytes=encoded(capsule)
write_new(OUT/"CAPSULE.json",capsule_bytes)
print(json.dumps({"archive":archive_pin,"manifest":pin(manifest_bytes),"capsule":pin(capsule_bytes),"members":len(all_payloads),"root":str(OUT),"allMembersExact":True},ensure_ascii=False))
