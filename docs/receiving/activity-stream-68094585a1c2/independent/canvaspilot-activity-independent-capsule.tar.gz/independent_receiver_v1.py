#!/usr/bin/env python3
"""Independent native activity receiver; authored before candidate access."""
import argparse
import asyncio
import contextlib
import copy
import datetime
import hashlib
import io
import json
import logging
import os
from pathlib import Path
import socket
import subprocess
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest import mock

ROOT = Path(__file__).resolve().parent
FIXTURES = json.loads((ROOT / "fixtures-before-candidate.json").read_text())
CONTRACT = json.loads((ROOT / "contract-before-candidate.json").read_text())
ENDPOINT = FIXTURES["endpoint"]
TOKEN = FIXTURES["syntheticToken"]
CHILD = r"""
import socket,sys
port=int(sys.argv[1])
original_connect=socket.socket.connect
def connect(sock,address):
    if not isinstance(address,tuple) or address[:2]!=('127.0.0.1',port):
        raise RuntimeError('independent receiver refused non-fixture connection')
    return original_connect(sock,address)
socket.socket.connect=connect
sys.path.insert(0,sys.argv[2])
from canvaspilot.cli import main
main(sys.argv[3:])
"""

def digest(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}

def protected(source):
    result = {"source/" + row["path"]: digest(source / row["path"])
              for row in CONTRACT["source"]["pins"]}
    for name in ["author-public-contract.json", "contract-before-candidate.json",
                 "fixtures-before-candidate.json", Path(__file__).name]:
        result["receiver/" + name] = digest(ROOT / name)
    return result

class FixtureHTTP:
    def __init__(self, scenario="happy"):
        self.scenario = scenario
        self.requests = []
        self.blocked = []
        outer = self
        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            def log_message(self, *args):
                pass
            def do_GET(self):
                outer.respond(self)
            def do_POST(self):
                outer.respond(self)
            def do_DELETE(self):
                outer.respond(self)
            def do_PUT(self):
                outer.respond(self)
            def do_PATCH(self):
                outer.respond(self)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        self.port = self.server.server_address[1]
        self.origin = "http://127.0.0.1:" + str(self.port)
        self.thread = threading.Thread(
            target=lambda: self.server.serve_forever(poll_interval=0.02), daemon=True)

    def __enter__(self):
        self.thread.start()
        self.original_connect = socket.socket.connect
        outer = self
        def connect(sock, address):
            if not isinstance(address, tuple) or address[:2] != ("127.0.0.1", outer.port):
                outer.blocked.append(repr(address))
                raise RuntimeError("independent receiver refused non-fixture connection")
            return outer.original_connect(sock, address)
        self.guard = mock.patch.object(socket.socket, "connect", connect)
        self.guard.start()
        self.environment = mock.patch.dict(
            os.environ, {"NO_PROXY": "127.0.0.1,localhost", "no_proxy": "127.0.0.1,localhost"})
        self.environment.start()
        return self

    def __exit__(self, *args):
        self.environment.stop()
        self.guard.stop()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        assert not self.thread.is_alive(), "owned fixture server did not stop"
        assert not self.blocked, self.blocked

    def respond(self, handler):
        body_length = int(handler.headers.get("Content-Length", "0"))
        body = handler.rfile.read(body_length) if body_length else b""
        record = {"method": handler.command, "path": handler.path,
                  "authorization_matches_synthetic": handler.headers.get("Authorization") == "Bearer " + TOKEN,
                  "body_bytes": len(body)}
        self.requests.append(record)
        paths = FIXTURES["expectedPaths"]
        try:
            index = paths.index(handler.path)
        except ValueError:
            index = -1
        status = 200
        link = ""
        payload = None
        if handler.command != "GET" or index < 0:
            status, payload = 500, {"receiver_error": "unexpected request"}
        else:
            payload = copy.deepcopy(FIXTURES["pages"][index])
            if index < 2:
                link = "<" + self.origin + paths[index + 1] + '>; rel="next"'
            if self.scenario == "empty":
                payload, link = [], ""
            elif self.scenario == "single":
                payload, link = copy.deepcopy(FIXTURES["terminalSingle"]), ""
            elif self.scenario == "empty_between":
                payload = [FIXTURES["pages"][0], [],
                           FIXTURES["pages"][1] + FIXTURES["pages"][2]][index]
            for failure in FIXTURES["failureCases"]:
                if self.scenario == failure["name"] and index == failure["page"]:
                    status = failure.get("status", status)
                    payload = failure.get("body", {"synthetic": "read failed"} if status != 200 else payload)
                    if "link" in failure:
                        link = failure["link"]
                    if failure.get("repeat"):
                        link = "<" + self.origin + paths[index] + '>; rel="next"'
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        handler.send_response(status)
        handler.send_header("Content-Type", "application/json; charset=utf-8")
        handler.send_header("Content-Length", str(len(raw)))
        handler.send_header("Connection", "close")
        if link:
            handler.send_header("Link", link)
        handler.end_headers()
        handler.wfile.write(raw)
        handler.close_connection = True

    def assert_requests(self, count):
        assert len(self.requests) == count, self.requests
        for i, request in enumerate(self.requests):
            assert request == {"method": "GET", "path": FIXTURES["expectedPaths"][i],
                               "authorization_matches_synthetic": True, "body_bytes": 0}, request

def client_for(service):
    from canvaspilot.client import CanvasClient
    return CanvasClient(base_url=service.origin, token=TOKEN,
                        profile=ROOT / "never-created-profile", timeout=4)

def cli_process(source, service, extra=None):
    argv = ["activity", "--base-url", service.origin, "--profile",
            str(ROOT / "never-created-profile"), "--token", TOKEN]
    if extra:
        argv.extend(extra)
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["NO_PROXY"] = env["no_proxy"] = "127.0.0.1,localhost"
    completed = subprocess.run(
        [sys.executable, "-I", "-B", "-c", CHILD, str(service.port),
         str(source / "src"), *argv],
        cwd=ROOT, env=env, capture_output=True, text=True, encoding="utf-8", timeout=20)
    return {"returncode": completed.returncode, "stdout": completed.stdout,
            "stderr": completed.stderr}

def original_baseline(source, receipt):
    from canvaspilot.api import CanvasAPI
    with FixtureHTTP() as service, client_for(service) as client:
        result = client.get_paginated(ENDPOINT)
        assert result == FIXTURES["expectedComplete"]
        service.assert_requests(3)
        receipt["groups"].append({"name": "original_paginator_complete_control",
                                  "result": result, "requests": service.requests})
    with FixtureHTTP() as service, client_for(service) as client:
        result = CanvasAPI(client).activity_stream()
        assert result == FIXTURES["pages"][0]
        service.assert_requests(1)
        receipt["groups"].append({"name": "original_activity_omits_advertised_later_pages",
                                  "result": result, "requests": service.requests,
                                  "missing_rows": 3, "negative_witness": True})
    with FixtureHTTP() as service:
        result = cli_process(source, service)
        assert result["returncode"] == 2 and result["stdout"] == ""
        assert "invalid choice" in result["stderr"] and "'activity'" in result["stderr"]
        assert service.requests == []
        receipt["groups"].append({"name": "original_cli_has_no_activity",
                                  **result, "requests": [], "negative_witness": True})

def candidate_receive(source, receipt):
    from canvaspilot.api import CanvasAPI
    from canvaspilot.client import CanvasClient
    from canvaspilot import cli
    for scenario, expected, count in [
        ("happy", FIXTURES["expectedComplete"], 3),
        ("empty_between", FIXTURES["expectedComplete"], 3),
        ("empty", [], 1),
        ("single", [FIXTURES["terminalSingle"]], 1),
    ]:
        with FixtureHTTP(scenario) as service, client_for(service) as client:
            actual = CanvasAPI(client).activity_stream()
            assert actual == expected, (scenario, actual, expected)
            service.assert_requests(count)
            receipt["groups"].append({"name": "api_" + scenario, "result": actual,
                                      "requests": service.requests})
    with FixtureHTTP() as service:
        result = cli_process(source, service)
        assert result == {"returncode": 0, "stdout": json.dumps(
            FIXTURES["expectedComplete"], indent=2, default=str) + "\n", "stderr": ""}, result
        service.assert_requests(3)
        receipt["groups"].append({"name": "actual_cli_complete_exact_json", **result,
                                  "requests": service.requests})
    for failure in FIXTURES["failureCases"]:
        with FixtureHTTP(failure["name"]) as service:
            result = cli_process(source, service)
            assert result["returncode"] == 1 and result["stdout"] == "", result
            error = json.loads(result["stderr"])
            assert error["ok"] is False and error["error"] == failure["error"], error
            assert isinstance(error["message"], str) and error["message"]
            service.assert_requests(failure["expectedRequests"])
            receipt["groups"].append({"name": "actual_cli_" + failure["name"],
                                      **result, "requests": service.requests})
    lifetime = []
    logger = logging.getLogger("httpx")
    original_level = logger.level
    native_close = CanvasClient.close
    for scenario, expected_exit in [("happy", 0), ("later_503", 1)]:
        closes = []
        messages = []
        class Capture(logging.Handler):
            def emit(self, record):
                messages.append(record.getMessage())
        capture = Capture()
        logger.addHandler(capture)
        logger.setLevel(logging.INFO)
        def close(client):
            native_close(client)
            closes.append(client._http is None)
        try:
            with FixtureHTTP(scenario) as service:
                stdout, stderr = io.StringIO(), io.StringIO()
                exit_code = 0
                with mock.patch.object(CanvasClient, "close", close), \
                        contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                    try:
                        cli.main(["activity", "--base-url", service.origin, "--token", TOKEN,
                                  "--profile", str(ROOT / "never-created-profile")])
                    except SystemExit as error:
                        exit_code = error.code
                assert exit_code == expected_exit
                assert logger.level == logging.INFO
                assert closes == [True], closes
                assert messages == [], messages
                service.assert_requests(3 if scenario == "happy" else 2)
                lifetime.append({"scenario": scenario, "exit": exit_code, "closed": closes,
                                 "logger_level_restored": True, "httpx_messages": messages,
                                 "requests": service.requests})
        finally:
            logger.removeHandler(capture)
            logger.setLevel(original_level)
    receipt["groups"].append({"name": "native_cli_lifetime_and_logging", "cases": lifetime})
    with FixtureHTTP() as service:
        with mock.patch.object(CanvasClient, "__init__", side_effect=AssertionError(
                "constructor reached before invalid argument refusal")) as constructor:
            out, err = io.StringIO(), io.StringIO()
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                try:
                    cli.main(["activity", "--limit", "3"])
                except SystemExit as error:
                    assert error.code == 2
                else:
                    raise AssertionError("unsupported activity flag accepted")
            assert constructor.call_count == 0 and service.requests == [] and out.getvalue() == ""
        receipt["groups"].append({"name": "unknown_flag_refused_before_client",
                                  "stderr": err.getvalue(), "constructor_calls": 0, "requests": []})
    from canvaspilot import mcp_server
    with FixtureHTTP() as service, client_for(service) as client:
        prior = mcp_server._api
        mcp_server._api = CanvasAPI(client)
        try:
            result = asyncio.run(mcp_server.mcp.call_tool("canvas_activity_stream", {}))
            actual_result = result.model_dump(mode="json", exclude_none=True)
            text_parts = [part.text for part in result.content if part.type == "text"]
            assert len(text_parts) == 1
            assert json.loads(text_parts[0]) == FIXTURES["expectedComplete"]
            assert text_parts[0] == json.dumps(FIXTURES["expectedComplete"], indent=2, default=str)
            service.assert_requests(3)
            receipt["groups"].append({"name": "native_registered_mcp_tool",
                                      "result": actual_result, "requests": service.requests,
                                      "boundary": "Installed MCPServer2.3 registered tool dispatch; not stdio or live Canvas"})
        finally:
            mcp_server._api = prior

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=["original", "candidate"], required=True)
    args = parser.parse_args()
    source = args.source.resolve()
    args.output.mkdir(parents=False, exist_ok=False)
    sys.path.insert(0, str(source / "src"))
    before = protected(source)
    if args.mode == "original":
        for row in CONTRACT["source"]["pins"]:
            assert before["source/" + row["path"]]["git_blob"] == row["sha"]
    receipt = {"schema": "hamon.canvaspilot.activity-independent-native/1",
               "actor": "chatgpt:68094585a1c2 / root", "mode": args.mode,
               "startedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "source": str(source), "python": sys.version, "executable": sys.executable,
               "receiver": digest(Path(__file__)), "protectedBefore": before, "groups": [],
               "sourceProductEdited": False, "liveCanvasUsed": False, "actionsUsed": False}
    passed = False
    try:
        if args.mode == "original":
            original_baseline(source, receipt)
        else:
            candidate_receive(source, receipt)
        assert not (ROOT / "never-created-profile").exists()
        passed = True
    except BaseException as error:
        receipt["failure"] = {"type": type(error).__name__, "message": str(error),
                              "traceback": traceback.format_exc()}
    finally:
        after = protected(source)
        receipt["protectedAfter"] = after
        receipt["allProtectedExact"] = before == after
        receipt["complete"] = passed and before == after
        receipt["endedAt"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        raw = (json.dumps(receipt, ensure_ascii=False, indent=2) + "\n").encode()
        (args.output / "receipt.json").write_bytes(raw)
        print(json.dumps({"complete": receipt["complete"], "mode": args.mode,
                          "groups": len(receipt["groups"]), "allProtectedExact": before == after,
                          "receipt": str(args.output / "receipt.json"),
                          "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                          "failure": receipt.get("failure")}, ensure_ascii=False))
    return 0 if receipt["complete"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
