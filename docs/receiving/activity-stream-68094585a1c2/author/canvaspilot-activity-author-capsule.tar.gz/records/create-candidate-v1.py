from pathlib import Path
import datetime,hashlib,json,shutil
ROOT=Path('/home/jacob/hamon-canvas-activity-68094585a1c2')
SOURCE=ROOT/'source'
CANDIDATE=ROOT/'candidate-v1'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def snapshot(base):
    return {str(p.relative_to(base)):sha(p) for p in sorted(base.rglob('*')) if p.is_file() and '.git' not in p.relative_to(base).parts and '__pycache__' not in p.relative_to(base).parts and '.pytest_cache' not in p.relative_to(base).parts}
assert not CANDIDATE.exists(), 'Do not overwrite or duplicate an uncertain candidate'
assert sha(ROOT/'public-contract.json')=='5ff5e39438db240fb2a1867df01c52218a0e4eed9df2a6dd9f071e2ff2373bc5'
assert sha(ROOT/'original-native-baseline.json')=='bfd57a719c7705d17aab26f98c845b3a4f2bad4671e6952abcebdd324c0590d7'
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
before=snapshot(SOURCE)
assert len(before)==134
shutil.copytree(SOURCE,CANDIDATE,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'))
assert snapshot(CANDIDATE)==before
old_api='        return self.client.request("GET", "/api/v1/users/self/activity_stream")\n'
new_api='        return self.client.get_paginated("/api/v1/users/self/activity_stream")\n'
parser_anchor='    find_announcements = sub.add_parser(\n'
new_parser='''    activity = sub.add_parser(
        "activity", help="Read all available current-user activity-stream pages",
    )
    add_common(activity)

'''
dispatch_anchor='        elif args.cmd == "planner":\n'
new_dispatch='''        elif args.cmd == "activity":
            import httpx

            from canvaspilot.client import CanvasAuthError, CanvasPaginationError

            http_log = logging.getLogger("httpx")
            previous_level = http_log.level
            http_log.setLevel(max(http_log.getEffectiveLevel(), logging.WARNING))
            try:
                result = api.activity_stream()
            except (CanvasAuthError, CanvasPaginationError, httpx.HTTPError, ValueError) as error:
                print(json.dumps({
                    "ok": False, "error": type(error).__name__, "message": str(error),
                }), file=sys.stderr)
                raise SystemExit(1) from None
            finally:
                http_log.setLevel(previous_level)
            print(json.dumps(result, indent=2, default=str))
'''
readme_anchor='Read your reported enrollment roles, states and grades with `canvaspilot enrollments`.\n'
new_readme='''Read your available global activity stream with `canvaspilot activity`.
The [activity-stream guide](docs/activity-stream.md) explains complete page traversal,
preserved returned records, JSON failures and the feed's content limits.

'''
for relative,old,new in [
 ('src/canvaspilot/api.py',old_api,new_api),
 ('src/canvaspilot/cli.py',parser_anchor,new_parser+parser_anchor),
 ('src/canvaspilot/cli.py',dispatch_anchor,new_dispatch+dispatch_anchor),
 ('README.md',readme_anchor,new_readme+readme_anchor),
]:
 p=CANDIDATE/relative
 data=p.read_text()
 assert data.count(old)==1,(relative,old)
 p.write_text(data.replace(old,new))
after=snapshot(CANDIDATE)
changed=[p for p in before if before[p]!=after[p]]
assert changed==['README.md','src/canvaspilot/api.py','src/canvaspilot/cli.py'],changed
assert snapshot(SOURCE)==before
record={'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(SOURCE),'candidate':str(CANDIDATE),'originalCommit':'56a72a2e2cee5ec04671d12ebe5bc2484afb8026','sourceFiles':len(before),'sourceUnchanged':True,'changed':changed,'before':before,'candidateAfterRuntimeAndReadmeEdits':after,'fence':{'oldAPI':old_api,'newAPI':new_api,'parserAddition':new_parser,'parserAnchor':parser_anchor,'dispatchAddition':new_dispatch,'dispatchAnchor':dispatch_anchor,'readmeAddition':new_readme,'readmeAnchor':readme_anchor}}
out=ROOT/'candidate-creation-v1.json'
out.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'record':str(out),'sha256':sha(out),'changed':changed,'sourceUnchanged':True,'candidate':str(CANDIDATE)},indent=2))
