from pathlib import Path
import ast, datetime, hashlib, json, os, subprocess, sys, time
ROOT=Path('/home/jacob/hamon-canvas-activity-68094585a1c2')
SOURCE=ROOT/'source'
CANDIDATE=ROOT/'candidate-v1'
OUT=ROOT/'author-native-v1'
PYTHON='/home/jacob/canvaspilot-enrollments-env-65ae877160f6/bin/python'
MODULES=['tests/test_activity_stream.py','tests/test_token_pagination.py','tests/test_enrollments_cli.py','tests/test_planner_cli.py','tests/test_terminal_page_shape_receiving.py']
def digest(path):
 data=path.read_bytes()
 return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
def snapshot(base):
 return {str(p.relative_to(base)):digest(p) for p in sorted(base.rglob('*')) if p.is_file() and '.git' not in p.relative_to(base).parts}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 assert not OUT.exists(), 'Do not rerun or overwrite an uncertain attempt'
 before=snapshot(CANDIDATE)
 original=snapshot(SOURCE)
 assert len(original)==134
 created=json.loads((ROOT/'candidate-creation-v1.json').read_text())
 fence=created['fence']
 for relative,changes in {
  'src/canvaspilot/api.py':[(fence['newAPI'],fence['oldAPI'])],
  'src/canvaspilot/cli.py':[(fence['parserAddition'],''),(fence['dispatchAddition'],'')],
  'README.md':[(fence['readmeAddition'],'')],
 }.items():
  text=(CANDIDATE/relative).read_text()
  for old,new in changes:
   assert text.count(old)==1,(relative,old)
   text=text.replace(old,new)
  assert text.encode()==(SOURCE/relative).read_bytes(),relative
 changed=[p for p in original if original[p]!=before[p]]
 assert changed==['README.md','src/canvaspilot/api.py','src/canvaspilot/cli.py'],changed
 assert sorted(set(before)-set(original))==['docs/activity-stream.md','tests/test_activity_stream.py']
 for relative in ['src/canvaspilot/api.py','src/canvaspilot/cli.py','tests/test_activity_stream.py']:
  ast.parse((CANDIDATE/relative).read_bytes(),filename=relative)
 env={k:v for k,v in os.environ.items() if not k.lower().endswith('_proxy') and not k.startswith(('CANVAS_','PYTHON'))}
 env.update(PYTHONPATH=str(CANDIDATE/'src'),PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',TMPDIR=str(ROOT/'tmp'),NO_PROXY='127.0.0.1',LANG='C.UTF-8')
 command=[PYTHON,'-B','-m','pytest','-q','-ra','--durations=10','-p','no:cacheprovider',*MODULES]
 OUT.mkdir()
 start=now()
 frozen={'startedAt':start,'candidate':str(CANDIDATE),'original':str(SOURCE),'command':command,'timeoutSeconds':600,'candidateInputs':before,'originalInputs':original,'publicContract':digest(ROOT/'public-contract.json'),'fenceExact':True,'qualificationDriver':digest(Path(__file__))}
 (OUT/'inputs-before.json').write_text(json.dumps(frozen,indent=2)+'\n')
 print(json.dumps({'startedAt':start,'command':command,'candidateFiles':len(before),'fenceExact':True}),flush=True)
 clock=time.monotonic()
 failure=None
 try:
  result=subprocess.run(command,cwd=CANDIDATE,env=env,capture_output=True,timeout=600)
  stdout,stderr,code=result.stdout,result.stderr,result.returncode
 except subprocess.TimeoutExpired as error:
  stdout,stderr,code=error.stdout or b'',error.stderr or b'',None
  failure={'kind':'TimeoutExpired','message':str(error)}
 (OUT/'stdout.log').write_bytes(stdout)
 (OUT/'stderr.log').write_bytes(stderr)
 after=snapshot(CANDIDATE)
 after_original=snapshot(SOURCE)
 receipt={'startedAt':start,'completedAt':now(),'elapsedSeconds':time.monotonic()-clock,'sourceCommit':'56a72a2e2cee5ec04671d12ebe5bc2484afb8026','exitCode':code,'failure':failure,'allCandidateInputsUnchanged':before==after,'allOriginalInputsUnchanged':original==after_original,'candidateFiles':len(before),'originalFiles':len(original),'sourceFenceExact':True,'command':command,'timeoutSeconds':600,'inputsBefore':digest(OUT/'inputs-before.json'),'candidateAfter':after,'originalAfter':after_original,'stdout':stdout.decode('utf-8','replace'),'stderr':stderr.decode('utf-8','replace'),'logPins':{'stdout.log':digest(OUT/'stdout.log'),'stderr.log':digest(OUT/'stderr.log')},'environment':{'device':'d55b2499-5e82-4805-819a-d0d7ddea1efe','python':PYTHON,'install':False,'transport':'owned loopback HTTP, synthetic broker, existing fixture/MockTransport; no live Canvas account'}}
 (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:receipt[k] for k in ['startedAt','completedAt','elapsedSeconds','exitCode','failure','allCandidateInputsUnchanged','allOriginalInputsUnchanged','stdout','stderr']},indent=2))
 print(json.dumps({'receipt':str(OUT/'receipt.json'),**digest(OUT/'receipt.json')}))
 raise SystemExit(0 if code==0 and original==after_original and before==after else 1)
if __name__=='__main__':main()
