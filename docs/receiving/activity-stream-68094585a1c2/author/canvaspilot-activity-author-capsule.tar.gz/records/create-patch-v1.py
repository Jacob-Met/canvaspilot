from pathlib import Path
import difflib,hashlib,json,subprocess,datetime
ROOT=Path('/home/jacob/hamon-canvas-activity-68094585a1c2')
SOURCE=ROOT/'source'
CANDIDATE=ROOT/'candidate-v1'
PATHS=['README.md','docs/activity-stream.md','src/canvaspilot/api.py','src/canvaspilot/cli.py','tests/test_activity_stream.py']
def pin(path):
 data=path.read_bytes()
 return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
def snapshot(base):
 return {str(p.relative_to(base)):pin(p) for p in sorted(base.rglob('*')) if p.is_file() and '.git' not in p.relative_to(base).parts}
out=ROOT/'activity-stream-v1.patch'
assert not out.exists()
before=snapshot(SOURCE)
patch=[]
files=[]
for relative in PATHS:
 old=SOURCE/relative
 new=CANDIDATE/relative
 old_lines=old.read_text().splitlines(keepends=True) if old.exists() else []
 new_lines=new.read_text().splitlines(keepends=True)
 patch.append('diff --git a/'+relative+' b/'+relative+'\n')
 if not old.exists():patch.append('new file mode 100644\n')
 patch.extend(difflib.unified_diff(old_lines,new_lines,fromfile='a/'+relative if old.exists() else '/dev/null',tofile='b/'+relative))
 files.append({'path':relative,'nativePath':str(new),'before':pin(old) if old.exists() else None,'after':pin(new)})
out.write_text(''.join(patch))
command=['/usr/bin/git','-C',str(SOURCE),'apply','--check',str(out)]
result=subprocess.run(command,capture_output=True,text=True)
after=snapshot(SOURCE)
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':'56a72a2e2cee5ec04671d12ebe5bc2484afb8026','sourceTree':'a07c3e941219ff80968e1ff20528a63541bb7400','patch':{'path':str(out),**pin(out)},'files':files,'check':{'command':command,'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr},'sourceUnchanged':before==after}
target=ROOT/'patch-manifest-v1.json'
target.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'manifest':{'path':str(target),**pin(target)},'patch':receipt['patch'],'check':receipt['check'],'sourceUnchanged':receipt['sourceUnchanged'],'files':files},indent=2))
assert result.returncode==0 and before==after
