from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
ROOT=Path('/home/jacob/hamon-canvas-activity-68094585a1c2')
PYTHON='/home/jacob/canvaspilot-enrollments-env-65ae877160f6/bin/python'
MODULES=['tests/test_token_pagination.py','tests/test_enrollments_cli.py','tests/test_planner_cli.py','tests/test_terminal_page_shape_receiving.py']
def snapshot(source):
    return {str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file() and '.git' not in p.relative_to(source).parts and '__pycache__' not in p.relative_to(source).parts and '.pytest_cache' not in p.relative_to(source).parts}
def main():
    source=ROOT/sys.argv[1]
    label=sys.argv[2]
    assert source.is_dir()
    out=ROOT/(label+'.json')
    assert not out.exists(), str(out)
    env={k:v for k,v in os.environ.items() if not k.lower().endswith('_proxy') and not k.startswith(('CANVAS_','PYTHON'))}
    env.update(PYTHONPATH=str(source/'src'),PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',TMPDIR=str(ROOT/'tmp'),NO_PROXY='127.0.0.1',LANG='C.UTF-8')
    before=snapshot(source)
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    t=time.monotonic()
    command=[PYTHON,'-B','-m','pytest','-q','-p','no:cacheprovider',*MODULES]
    result=subprocess.run(command,cwd=source,env=env,capture_output=True,timeout=180)
    end=datetime.datetime.now(datetime.timezone.utc).isoformat()
    after=snapshot(source)
    receipt={'kind':'existing focused native regression','source':str(source),'startedAt':start,'completedAt':end,'elapsedSeconds':time.monotonic()-t,'command':command,'exitCode':result.returncode,'stdout':result.stdout.decode('utf-8','replace'),'stderr':result.stderr.decode('utf-8','replace'),'before':before,'after':after,'allInputsUnchanged':before==after,'python':PYTHON}
    out.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:receipt[k] for k in ['kind','source','startedAt','completedAt','elapsedSeconds','exitCode','stdout','stderr','allInputsUnchanged']},indent=2))
    print(json.dumps({'receiptPath':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
    raise SystemExit(result.returncode if before==after else 3)
if __name__=='__main__':main()
