from pathlib import Path
import datetime,hashlib,json,shutil
ROOT=Path('/home/jacob/hamon-canvas-activity-68094585a1c2')
CANDIDATE=ROOT/'candidate-v1'
OUT=ROOT/'candidate-for-independent-v1'
PATHS=['README.md','docs/activity-stream.md','src/canvaspilot/api.py','src/canvaspilot/cli.py']
def pin(path):
 data=path.read_bytes()
 return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
assert not OUT.exists(), 'Do not overwrite sealed admission'
receipt=json.loads((ROOT/'author-native-v1/receipt.json').read_text())
assert receipt['exitCode']==0 and receipt['allCandidateInputsUnchanged'] and receipt['allOriginalInputsUnchanged']
assert pin(ROOT/'author-native-v1/receipt.json')['sha256']=='e2b88e3c39afbd29e06c374844d5571254578cf18eeb6cef0f339905952bec92'
files=[]
for relative in PATHS:
 source=CANDIDATE/relative
 assert pin(source)==receipt['candidateAfter'][relative]
 target=OUT/relative
 target.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(source,target)
 assert pin(target)==pin(source)
 original=ROOT/'source'/relative
 files.append({'path':relative,'nativePath':str(target),**pin(target),'original':pin(original) if original.exists() else None})
manifest={'kind':'qualified product-only independent admission','author':'chatgpt:68094585a1c2 / levenshtein_receiving','sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':'56a72a2e2cee5ec04671d12ebe5bc2484afb8026','sourceTree':'a07c3e941219ff80968e1ff20528a63541bb7400','sourceRoot':str(ROOT/'source'),'candidateRoot':str(OUT),'publicContract':{'path':str(ROOT/'public-contract.json'),**pin(ROOT/'public-contract.json')},'authorNativeQualification':{'path':str(ROOT/'author-native-v1/receipt.json'),**pin(ROOT/'author-native-v1/receipt.json'),'pytestTests':69,'existingTests':39,'newActivityTests':30,'existingSubtests':14,'exitCode':0},'files':files,'protectedOriginalRuntime':{path:value for path,value in receipt['originalAfter'].items() if path.startswith('src/')},'noAuthorTestsOrAnswerControlsIncluded':True,'actions':'No push, PR, merge, dispatch, rerun or workflow mutation'}
target=OUT/'MANIFEST.json'
target.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest':str(target),**pin(target),'files':files,'qualificationReceipt':manifest['authorNativeQualification']},indent=2))
