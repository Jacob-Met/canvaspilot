from pathlib import Path
import os, sys, json, hashlib, subprocess, threading, datetime
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlsplit, parse_qs

ROOT = Path('/home/jacob/hamon-canvas-activity-68094585a1c2')
SOURCE = ROOT / 'source'
for key in ['HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy', 'all_proxy']:
    os.environ.pop(key, None)
os.environ['NO_PROXY'] = '127.0.0.1,localhost'
sys.path.insert(0, str(SOURCE / 'src'))
from canvaspilot.api import CanvasAPI
from canvaspilot.client import CanvasClient

def digest(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(SOURCE)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(('blob ' + str(len(data)) + chr(0)).encode() + data).hexdigest()}

tracked = [SOURCE / name for name in subprocess.check_output(
    ['git', '-C', str(SOURCE), 'ls-files', '-z']).decode().split(chr(0)) if name]
before = [digest(path) for path in tracked if path.is_file()]
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
events = []
mode = 'chain'
first = [{'id': 41, 'type': 'Message', 'title': 'Lab α', 'read_state': False,
          'metadata': {'value': 0, 'unknown': None, 'text': '<literal & data>'}}]
second = [{'id': 42, 'type': 'Conversation', 'message': 'Second recorded page'}]

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def do_GET(self):
        events.append({'method': 'GET', 'path': self.path, 'mode': mode})
        query = parse_qs(urlsplit(self.path).query)
        later = query.get('cursor') == ['later&opaque']
        status = 401 if mode == 'first-auth-error' else 503 if mode == 'later-error' and later else 200
        data = {'error': 'authored failure'} if status != 200 else [] if mode == 'empty' else second if later else first
        raw = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(raw)))
        if status == 200 and mode != 'empty' and not later:
            self.send_header('Link', '<http://127.0.0.1:' + str(self.server.server_port) +
                             '/api/v1/users/self/activity_stream?cursor=later%26opaque>; rel="next"')
        self.end_headers()
        self.wfile.write(raw)

server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
base = 'http://127.0.0.1:' + str(server.server_port)
observations = []
try:
    for scenario in ['chain', 'later-error', 'first-auth-error', 'empty']:
        mode = scenario
        events.clear()
        client = CanvasClient(base_url=base, token='authored-loopback-token',
                              profile=ROOT / 'unused-authored-profile')
        api = CanvasAPI(client)
        try:
            result = api.activity_stream()
            observed = {'result': result, 'error': None}
        except Exception as error:
            observed = {'result': None, 'error': {'class': type(error).__name__, 'message': str(error)}}
        finally:
            api.close()
        observations.append({'scenario': scenario, 'configured_pages': 1 if scenario in ['empty','first-auth-error'] else 2,
                             'requests': list(events), **observed})
    mode = 'chain'
    events.clear()
    env = os.environ.copy()
    env['PYTHONPATH'] = str(SOURCE / 'src')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['TMPDIR'] = str(ROOT / 'tmp')
    command = [sys.executable, '-B', '-c', 'from canvaspilot.cli import main; main()',
               'activity', '--base-url', base, '--token', 'authored-loopback-token',
               '--profile', str(ROOT / 'unused-authored-profile')]
    child = subprocess.run(command, env=env, cwd=SOURCE, capture_output=True, text=True, timeout=30)
    observations.append({'scenario': 'missing-cli', 'argv': command, 'exit': child.returncode,
                         'stdout': child.stdout, 'stderr': child.stderr, 'requests': list(events)})
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=3)
after = [digest(SOURCE / item['path']) for item in before]
assert after == before
assert observations[0]['result'] == first and len(observations[0]['requests']) == 1
assert observations[1]['result'] == first and len(observations[1]['requests']) == 1
assert observations[2]['error']['class'] == 'CanvasAuthError'
assert observations[3]['result'] == [] and len(observations[3]['requests']) == 1
assert child.returncode == 2 and child.stdout == '' and observations[-1]['requests'] == []
assert not (ROOT / 'unused-authored-profile').exists()
receipt = {
    'schema': 'hamon.canvaspilot.activity-stream.original-native-baseline/1',
    'startedAt': start, 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'actor': 'chatgpt:68094585a1c2 / levenshtein_receiving',
    'sourceCommit': '56a72a2e2cee5ec04671d12ebe5bc2484afb8026',
    'sourceTree': 'a07c3e941219ff80968e1ff20528a63541bb7400',
    'python': sys.version, 'executable': sys.executable,
    'fixture': {'first': first, 'second': second, 'allDataAuthored': True},
    'observations': observations,
    'interpretation': {
        'original_single_request_observed': True,
        'configured_second_page_not_requested': True,
        'configured_later_error_not_requested_or_observed_as_response': True,
        'original_auth_error_propagates': True,
        'terminal_empty_control': True,
        'activity_cli_absent_exit2': True,
        'no_candidate_executed': True,
        'liveCanvasOrAccountUse': False,
        'sourceFilesUnchanged': len(before),
        'authoredProfileCreated': False
    },
    'sourceBefore': before, 'sourceAfter': after
}
data = (json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode()
with (ROOT / 'original-native-baseline.json').open('xb') as handle:
    handle.write(data)
print(json.dumps({'pass': True, 'baseline': str(ROOT / 'original-native-baseline.json'),
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'sourceFilesUnchanged': len(before),
                  'observations': [{'scenario': x['scenario'], 'requests': len(x['requests']),
                                    'result_count': len(x['result']) if isinstance(x.get('result'), list) else None,
                                    'error': x.get('error', {}).get('class') if x.get('error') else None,
                                    'exit': x.get('exit')} for x in observations]}))
