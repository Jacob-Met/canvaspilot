"""Real CLI/HTTP boundary; every response and credential is an authored fixture."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit

import pytest

FIXTURE = Path(__file__).parent / "fixtures" / "page_packet.json"


@pytest.fixture
def loopback():
    source = FIXTURE.read_bytes()
    data = json.loads(source)
    routes = {"/api/v1/courses/42": data["course"]}
    routes.update({
        f"/api/v1/courses/42/pages/{quote(locator, safe='')}": row
        for locator, row in data["pages"].items()
    })
    state = {"routes": routes, "overrides": {}, "requests": [], "before_reply": None}

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlsplit(self.path)
            state["requests"].append({
                "method": self.command, "path": parsed.path,
                "query": parse_qs(parsed.query),
                "authored_token": self.headers.get("Authorization") == "Bearer authored-page-packet-token",
            })
            if state["before_reply"]:
                state["before_reply"](parsed.path)
            if parsed.path in state["overrides"]:
                status, value = state["overrides"][parsed.path]
            elif parsed.path in routes:
                status, value = 200, routes[parsed.path]
            else:
                status, value = 404, {"error": "unrequested fixture route"}
            payload = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def log_message(self, *_args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    state["base_url"] = f"http://127.0.0.1:{server.server_port}"
    state["data"] = data
    try:
        yield state
    finally:
        server.shutdown()
        server.server_close()
        worker.join(timeout=5)
        assert not worker.is_alive()
        assert FIXTURE.read_bytes() == source


def run_cli(loopback, target, *pages, course="42", file_size_limit=None):
    # Keep the chosen test interpreter/package path, but never inherit a Canvas
    # account, broker configuration, pytest option or proxy for the loopback run.
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(("CANVAS_", "CANVASPILOT_", "PYTEST_"))
           and not key.lower().endswith("_proxy")}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["NO_PROXY"] = "127.0.0.1,localhost"
    entry = ["-m", "canvaspilot.cli"]
    if file_size_limit is not None:
        # The OS limit is installed inside this child, never in the test/server
        # process or another worker. Ignore SIGXFSZ so Python reports OSError.
        entry = ["-c", (
            "import resource, signal; "
            f"resource.setrlimit(resource.RLIMIT_FSIZE, ({file_size_limit}, {file_size_limit})); "
            "signal.signal(signal.SIGXFSZ, signal.SIG_IGN); "
            "from canvaspilot.cli import main; main()"
        )]
    return subprocess.run([
        sys.executable, "-B", *entry, "export-pages", course, *pages,
        "--base-url", loopback["base_url"], "--token", "authored-page-packet-token",
        "--profile", str(target.parent / "unused-authored-profile"), "--out", str(target),
    ], env=env, text=True, capture_output=True, timeout=30, check=False)


def error_report(process):
    # The unchanged transport can log HTTP diagnostics before the command's
    # final JSON error. Keep those diagnostics visible and reject tracebacks.
    lines = process.stderr.splitlines()
    assert lines and all(line.startswith("HTTP Request: GET http://127.0.0.1:") for line in lines[:-1])
    return json.loads(lines[-1])


def test_real_cli_reads_only_selected_pages_and_publishes_complete_packet(loopback, tmp_path):
    target = tmp_path / "reading.html"
    process = run_cli(loopback, target, "7", "page_id:7", "intro")
    assert process.returncode == 0, process.stderr
    assert all(line.startswith("HTTP Request: GET http://127.0.0.1:") for line in process.stderr.splitlines())
    report = json.loads(process.stdout)
    assert report["ok"] is True and report["output"] == str(target)
    assert [row["page_id"] for row in report["pages"]] == [8, 7, 9007199254740993]
    assert [row["requested"] for row in report["pages"]] == ["7", "page_id:7", "intro"]
    assert report["sha256"] == hashlib.sha256(target.read_bytes()).hexdigest()
    assert report["bytes"] == target.stat().st_size
    assert [row["path"] for row in loopback["requests"]] == [
        "/api/v1/courses/42", "/api/v1/courses/42/pages/7",
        "/api/v1/courses/42/pages/page_id%3A7", "/api/v1/courses/42/pages/intro",
    ]
    assert all(row["method"] == "GET" and row["authored_token"] for row in loopback["requests"])
    assert all(row["query"] == {"per_page": ["50"]} for row in loopback["requests"])
    assert not (tmp_path / "unused-authored-profile").exists()
    assert not list(tmp_path.glob(".canvaspilot-pages-*.tmp"))


@pytest.mark.parametrize("status", [401, 403, 404, 500])
def test_later_http_failure_never_publishes_an_earlier_partial_page(loopback, tmp_path, status):
    target = tmp_path / "reading.html"
    loopback["overrides"]["/api/v1/courses/42/pages/7"] = (status, {"error": "authored refusal"})
    result = run_cli(loopback, target, "intro", "7")
    assert result.returncode == 1 and result.stdout == ""
    assert error_report(result)["ok"] is False
    assert len(loopback["requests"]) == 3
    assert not target.exists()
    assert not list(tmp_path.glob(".canvaspilot-pages-*.tmp"))


def test_later_invalid_json_never_creates_a_packet(loopback, tmp_path):
    target = tmp_path / "reading.html"
    loopback["overrides"]["/api/v1/courses/42/pages/7"] = (200, b"{authored invalid JSON")
    result = run_cli(loopback, target, "intro", "7")
    assert result.returncode == 1 and result.stdout == ""
    assert error_report(result)["error"] == "JSONDecodeError"
    assert not target.exists()


def test_wrong_course_reply_is_refused_before_page_reads(loopback, tmp_path):
    target = tmp_path / "reading.html"
    loopback["overrides"]["/api/v1/courses/42"] = (200, {"id": 43, "name": "Other authored course"})
    result = run_cli(loopback, target, "intro")
    assert result.returncode == 1 and error_report(result)["error"] == "ValueError"
    assert len(loopback["requests"]) == 1 and not target.exists()


@pytest.mark.parametrize("kind", ["file", "symlink", "dangling", "hardlink", "directory"])
def test_existing_entries_refuse_before_requests_and_preserve_inputs(loopback, tmp_path, kind):
    source = tmp_path / "authored-source.json"
    source.write_bytes(FIXTURE.read_bytes())
    original = source.read_bytes()
    target = tmp_path / "reading.html"
    if kind == "file":
        target.write_bytes(b"existing packet")
    elif kind == "symlink":
        target.symlink_to(source)
    elif kind == "dangling":
        target.symlink_to(tmp_path / "missing")
    elif kind == "hardlink":
        os.link(source, target)
    else:
        target.mkdir()
    before = target.lstat()
    result = run_cli(loopback, target, "intro")
    assert result.returncode == 1 and result.stdout == ""
    assert error_report(result)["error"] == "FileExistsError"
    assert loopback["requests"] == []
    assert source.read_bytes() == original
    after = target.lstat()
    # Reads may update access time; identity, contents, metadata and links stay.
    for field in ("st_dev", "st_ino", "st_mode", "st_size", "st_mtime_ns", "st_ctime_ns", "st_nlink"):
        assert getattr(after, field) == getattr(before, field)
    if kind == "file":
        assert target.read_bytes() == b"existing packet"


def test_destination_created_during_reads_is_never_replaced(loopback, tmp_path):
    target = tmp_path / "reading.html"

    def create_competing_file(path):
        if path.endswith("/intro"):
            target.write_bytes(b"created by another authored writer")

    loopback["before_reply"] = create_competing_file
    result = run_cli(loopback, target, "intro")
    assert result.returncode == 1 and result.stdout == ""
    assert error_report(result)["error"] == "FileExistsError"
    assert target.read_bytes() == b"created by another authored writer"
    assert not list(tmp_path.glob(".canvaspilot-pages-*.tmp"))


@pytest.mark.parametrize("pages", [["intro", "intro"], ["page_id:0"], ["../intro"], ["intro"] * 21])
def test_invalid_selection_refuses_before_any_http(loopback, tmp_path, pages):
    target = tmp_path / "reading.html"
    result = run_cli(loopback, target, *pages)
    assert result.returncode == 1 and error_report(result)["error"] == "ValueError"
    assert loopback["requests"] == [] and not target.exists()


def test_missing_destination_parent_is_not_created(loopback, tmp_path):
    target = tmp_path / "missing" / "reading.html"
    result = run_cli(loopback, target, "intro")
    assert result.returncode == 1 and result.stdout == ""
    assert error_report(result)["error"] == "FileNotFoundError"
    assert not target.parent.exists()


def test_actual_child_file_size_limit_leaves_inputs_and_existing_output_intact(loopback, tmp_path):
    resource = pytest.importorskip("resource")
    if not hasattr(resource, "RLIMIT_FSIZE"):
        pytest.skip("This OS does not expose a process-local file size limit")
    target = tmp_path / "reading.html"
    protected = tmp_path / "existing.html"
    protected.write_bytes(b"an existing authored reading packet")
    result = run_cli(loopback, target, "intro", file_size_limit=128)
    assert result.returncode == 1 and result.stdout == ""
    assert error_report(result)["error"] == "OSError"
    assert not target.exists()
    assert protected.read_bytes() == b"an existing authored reading packet"
    assert not list(tmp_path.glob(".canvaspilot-pages-*.tmp"))
