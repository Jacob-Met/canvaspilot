# CanvasPilot activity-stream author capsule

Owner: `chatgpt:68094585a1c2 / levenshtein_receiving`.

This packet preserves the exact original source projection, authored contract,
before-image observations, qualified candidate, maintained tests and native
receipts for [CanvasPilot #94](https://github.com/Jacob-Met/canvaspilot/issues/94).
It is source and evidence custody. No branch, pull request, merge, Actions run or
live Canvas read was created by this packet.

## Beneficiary and source change

A learner can run `canvaspilot activity` to read all available global
activity-stream pages as one JSON collection. The existing no-argument Python
method and MCP delegate receive that same paginated collection.

The candidate is based on main `56a72a2e2cee5ec04671d12ebe5bc2484afb8026`,
tree `a07c3e941219ff80968e1ff20528a63541bb7400`. The complete original tree has
1,616 leaves. The private native projection materialized 134 exact source,
test, script, documentation and configuration files. It is not a claim that
all 1,616 repository files were executed or copied into the runtime.

| Changed path | Bounded change |
| --- | --- |
| `src/canvaspilot/api.py` | Only the existing activity method body changes from one GET to the unchanged generic paginator. |
| `src/canvaspilot/cli.py` | One additive parser and one additive dispatch span. |
| `README.md` | One additive guide paragraph. |
| `docs/activity-stream.md` | New command and returned-data guide. |
| `tests/test_activity_stream.py` | Thirty maintained cases using actual native API/CLI boundaries. |

Removing the exact three declared API/CLI/README changes reconstructs each
original file byte for byte. Every other materialized original file remains
exact. The client, authentication, broker, MCP delegate, dependencies, workflows
and other CLI/API bodies were not edited.

The public contract froze at 2026-10-08T21:15:42.557924+00:00. It is 7,933 bytes,
SHA256 `5ff5e39438db240fb2a1867df01c52218a0e4eed9df2a6dd9f071e2ff2373bc5`.

## Recorded native results

| Observation | Actual result |
| --- | --- |
| Original API and CLI before-image | Receiver exit 0. Original API returns only the first page; original CLI rejects activity with exit 2 and no HTTP request or profile creation. |
| Original first auth and empty controls | Initial auth failure propagates; terminal empty input returns an empty collection. |
| Configured later original HTTP failure | The later page was never requested. This is not an observed swallowed HTTP error. |
| Existing original regression baseline | 39 tests and 14 subtests passed; all 134 source files exact. |
| Candidate maintained tests and regressions | 69 tests, comprising 30 new and 39 existing, plus 14 existing subtests passed; exit 0. All 136 candidate and 134 original files exact before/after. |
| Native lint | Preexisting Ruff 0.16.10 checked `src tests scripts`; exit 0, all checks passed, candidate files exact. |
| Patch admission | Native `git apply --check` on the untouched original checkout passed; original files exact. |

Candidate qualification ran at 21:25:54–21:27:02 UTC on 2026-10-08, using the
existing Python 3.14.4 / HTTPX 0.28.1 / MCP 2.3.0 environment read-only.
Its receipt is 60,843 bytes, SHA256
`e2b88e3c39afbd29e06c374844d5571254578cf18eeb6cef0f339905952bec92`.
The native device is the admitted ThinkPad
`d55b2499-5e82-4805-819a-d0d7ddea1efe`; the original executable path is preserved
in every applicable receipt. No installation was performed.

Tests exercised complete records, Unicode/literal text, duplicates, unknown
values, a short page, an empty continuing page, terminal-empty and first-terminal
non-list compatibility, first/later auth and HTTP errors, invalid JSON and
continuation links, the exact 40-page boundary, the original fixture route, a
disposable synthetic broker, real CLI output, logger restoration, client closing
and argument refusal before construction. Existing regression tests also
qualified adjacent planner/enrollment commands and original pagination.

The tokens and records are authored fixtures. Actual HTTP listeners belong to
the receivers and bind loopback. No user Canvas account, profile, browser,
provider or school endpoint is used. The synthetic broker receives Canvas GET
jobs through its existing localhost POST transport; that is not a Canvas write.

## Independent receiving

Root independently froze a separate contract and expected data before candidate
access. Its native original control showed that the unchanged generic paginator
could collect all pages while the original activity wrapper could not. The
four-file product-only admission omitted these author's tests and expected
records.

Root subsequently reported all 13 frozen candidate groups passed with immutable
inputs. Its separate receipt is at
`/home/jacob/hamon-canvas-activity-independent-68094585a1c2/candidate-v1/receipt.json`,
34,466 bytes, SHA256
`ec1428fde471fc55ab66c1f10c5d0625f4d3a66fde5268a2255bd077afbca5e3`.
The independent packet, including its preserved old-SDK-name observer failure,
belongs to root and is not reattributed to this author archive. Root's product
diff/documentation review and final source custody are separate steps.

## Scope and remaining gates

The result is the feed the endpoint makes available. It does not establish a
complete historical archive, complete assignment inventory or complete unread
work list. Canvas already truncates some activity messages; the guide cites the
official Users and Pagination documentation and does not promise recovery of
omitted source content. No new filter, sort, deduplication or linked-content
retrieval was introduced.

The recorded checks use native Python 3.14.4. The entire maintained test suite,
hosted Python 3.12 CI, wheel/browser workflow and live school authentication were
not executed for this increment. No hosted success is inferred from native
results. Existing required hosted gates remain unrun under Jacob's current
no-Actions direction, relayed at
[HAMON #143/comment6067592767](https://github.com/Jacob-Met/hamon/issues/143#issuecomment-6067592767).

Fresh workflow custody checked both complete definitions against current main's
Git blobs. CI subscribes to main push/PR; the agenda workflow subscribes to
main PR with paths and explicit workflow dispatch. Neither definition subscribes
to issues or issue comments. No account-wide Actions setting or billing diagnosis
is asserted. Root owns any future non-triggering custody and source composition;
no workflow suppression or gate workaround was attempted.

## Packet contents and provenance

`original-source/` holds the 134 exact materialized originals. `candidate/`
holds only the five changed/new files. `records/` preserves the original native
receipts, driver programs, Git tree inventory, ownership/workflow guards, public
contract, source-change fence and product-only admission manifest.

The five-file patch is in `records/activity-stream-v1.patch`: 23,781 bytes,
SHA256 `b5272e001f8b771d21f9e316f041f3b8405efbc2aa46e8bb1eb3c51fa4fa09d3`.
Its manifest records every before/after file pin. Test sources and raw pytest
logs are preserved; the independent receiver separately owns its detailed
per-case runtime observations.

The original source-acquisition JSON's `startedAt` value was recorded after
the acquisition commands returned, so it is not a precise wall-start claim.
Its actual command arguments, exit codes and returned output remain unchanged.
Native execution receipts use their explicitly captured start/end times.

The archive manifest records every member's size, SHA256, Git blob identity and
mode. Archive timestamps are deterministic metadata, not execution timestamps.
No original evidence file is rewritten to replace a negative witness with a
later success.
