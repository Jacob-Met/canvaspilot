from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'baseline'
EVIDENCE = ROOT / 'evidence/original-native'
EVIDENCE.mkdir()
FIXTURE = ROOT / 'evidence/representative-calendars.json'
records = json.loads(FIXTURE.read_text())
requests = []

class Calendar(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_GET(self):
        target = urlsplit(self.path)
        query = parse_qs(target.query)
        requests.append({'method': 'GET', 'path': target.path, 'query': query})
        kind = query.get('type', [''])[0]
        if target.path != '/api/v1/calendar_events' or kind not in records:
            self.send_response(404)
            self.end_headers()
            return
        body = json.dumps(records[kind]).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

def source_hashes():
    return {str(p.relative_to(SOURCE)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in SOURCE.rglob('*') if p.is_file()}

before = source_hashes()
server = ThreadingHTTPServer(('127.0.0.1', 0), Calendar)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
base = f'http://127.0.0.1:{server.server_port}'
env = {k: v for k, v in os.environ.items() if not k.lower().endswith('_proxy')}
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['PYTHONPATH'] = '/dev/shm/e827-canvaspilot-agenda-runtime:' + str(SOURCE / 'src')
results = []
try:
    with tempfile.TemporaryDirectory(prefix='agenda-view-original-') as directory:
        scratch = Path(directory)
        for command in ['agenda', 'export-agenda']:
            requests.clear()
            args = [sys.executable, '-B', '-m', 'canvaspilot.cli', command, '42', '77',
                    '--start', '2026-10-08', '--end', '2026-10-15', '--base-url', base,
                    '--token', 'authored-agenda-view-fixture', '--profile', str(scratch / 'unused-profile')]
            if command == 'export-agenda':
                args += ['--out', str(scratch / 'agenda.html')]
            run = subprocess.run(args, cwd=SOURCE, env=env, capture_output=True, timeout=25)
            (EVIDENCE / f'{command}.stdout').write_bytes(run.stdout)
            (EVIDENCE / f'{command}.stderr').write_bytes(run.stderr)
            trace = json.loads(json.dumps(requests))
            if command == 'agenda':
                assert run.returncode == 0, run.stderr
                report = json.loads(run.stdout)
                assert report['counts'] == {'total': 4, 'timed': 2, 'all_day': 1, 'timing_unavailable': 1}
                assert len(trace) == 2
                assert [r['query']['type'] for r in trace] == [['event'], ['assignment']]
                assert report['timed'][0]['record']['id'] == 901
                assert report['timed'][1]['record']['id'] == 'evt-07'
            else:
                assert run.returncode == 2
                assert b'invalid choice' in run.stderr and b'export-agenda' in run.stderr
                assert run.stdout == b'' and trace == []
            assert not (scratch / 'agenda.html').exists()
            assert not (scratch / 'unused-profile').exists()
            results.append({'command': command, 'exit': run.returncode, 'requests': trace,
                            'stdout_bytes': len(run.stdout), 'stdout_sha256': hashlib.sha256(run.stdout).hexdigest(),
                            'stderr_bytes': len(run.stderr), 'stderr_sha256': hashlib.sha256(run.stderr).hexdigest(),
                            'html_created': False, 'profile_created': False})
finally:
    server.shutdown()
    server.server_close()
    thread.join()
after = source_hashes()
assert after == before
receipt = {'recorded_at': datetime.now(timezone.utc).isoformat(),
           'source_commit': '0480cbce421bae532e3e909899fc8fb83789e878',
           'source_tree': 'f9ecaa4311d93cfe3a1fd1c9cc140834e2449341',
           'fixture_sha256': hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),
           'runs': results, 'source_before': before, 'source_after': after,
           'boundary': 'Actual native CLI/client over authored loopback HTTP. Healthy normalized agenda and absent standalone human-view route. No browser or live Canvas operation.'}
(EVIDENCE / 'receiving.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'source': receipt['source_commit'], 'runs': results, 'source_unchanged': True}))
