

### Offline course-agenda view

Use `canvaspilot export-agenda 42 77 --start 2026-10-08 --end 2026-10-15 --out agenda.html` to retain an agenda with course/source-date/search controls, distinct timing groups and a printable current view. The original native report remains available byte-identically. [Review and print a saved agenda](docs/agenda-export.md).
