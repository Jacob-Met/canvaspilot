from pathlib import Path
import hashlib,json,time,subprocess,sys,os
root=Path('/Users/me/hamon-canvas-syllabus-receiving-cd1df0f1ee24')
author=Path('/Users/me/Developer/canvaspilot-syllabus-cd1df0f1ee24')
parent_raw=(author/'inputs/composition-6c4d5d2e-manifest.json').read_bytes()
assert hashlib.sha256(parent_raw).hexdigest()=='277089aca747f1ae2bcfe6274461b34e5fb5aea253793b340f255c6aa924e427'
parent_manifest=json.loads(parent_raw)
records={item['path']:item for item in parent_manifest['parent_source']}
assert len(records)==19
payload_raw=(author/'inputs/composition-6c4d5d2e-v4-manifest.json').read_bytes()
assert hashlib.sha256(payload_raw).hexdigest()=='36ad92910ffed1c5f0d4896cf5348b28d35e66cf5f462ec7f22904b05c880b05'
payload=json.loads(payload_raw)
assert payload['parent']=='6c4d5d2e7526cddc1aa6c90bfbef2d1188382ad3'
sources=[item for item in payload['files'] if not item['path'].startswith('tests/')]
assert {item['path'] for item in sources}=={'README.md','docs/syllabus-packet.md','src/canvaspilot/cli.py','src/canvaspilot/syllabus_packet.py'}
records.update({item['path']:item for item in sources});assert len(records)==21
destination=root/'candidate-current-print-v4';assert not destination.exists();destination.mkdir()
for path,item in records.items():
 p=Path(path);assert not p.is_absolute() and '..' not in p.parts and not path.startswith('tests/')
 data=(author/'composition-6c4d5d2e-print-v4'/p).read_bytes()
 assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],path
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['git_blob'],path
 target=destination/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
manifest={'schema':'hamon.canvaspilot.independent-current-print-source.v4','parent':payload['parent'],'parent_tree':payload['parent_tree'],'parentManifestSHA256':hashlib.sha256(parent_raw).hexdigest(),'payloadManifestSHA256':hashlib.sha256(payload_raw).hexdigest(),'authorTestsRead':False,'files':sorted(records.values(),key=lambda i:i['path'])}
raw=(json.dumps(manifest,indent=2)+'\n').encode();(root/'candidate-current-print-v4-manifest.json').write_bytes(raw)
(root/'author-current-v4-payload-manifest.json').write_bytes(payload_raw)
(root/'author-current-parent-manifest.json').write_bytes(parent_raw)
adapter=root/'receiver-v3/invoke-cli.py';adapter_raw=adapter.read_bytes()
assert hashlib.sha256(adapter_raw).hexdigest()=='9e62d291fe951bc218129913d0653940f9539ff8bba1ae2afc11923ab2d48b5b'
case_raw=(root/'candidate-v3-run-01/normal-selected/case.json').read_bytes()
output=root/'current-print-v4-run-01';output.mkdir()
(output/'case.json').write_bytes(case_raw)
stage={'at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'sourceManifestSHA256':hashlib.sha256(raw).hexdigest(),'files':21,'parent':payload['parent'],'parentTree':payload['parent_tree'],'adapterSHA256':hashlib.sha256(adapter_raw).hexdigest(),'caseSHA256':hashlib.sha256(case_raw).hexdigest(),'browserDriverSHA256':hashlib.sha256((root/'receive-print-v4.mjs').read_bytes()).hexdigest(),'authorTestsRead':False,'scope':'Only original actual normal-selected CLI flow and final print; no complete gate reruns.'}
(root/'current-print-v4-stage-receipt.json').write_text(json.dumps(stage,indent=2)+'\n')
command=[sys.executable,str(adapter),str(destination),str(root/'receiver-v3/fixtures.json'),str(root/'receiver-v3/public-interface.json'),str(output/'case.json'),str(output/'requests.json'),str(output/'syllabus.html')]
completed=subprocess.run(command,cwd=output,capture_output=True,timeout=30,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','CANVAS_API_TOKEN':'receiver-fixture-not-a-credential','PYTHONPATH':str(destination/'src')})
(output/'stdout.txt').write_bytes(completed.stdout);(output/'stderr.txt').write_bytes(completed.stderr)
assert completed.returncode==0 and not completed.stderr,(completed.returncode,completed.stderr.decode())
report=json.loads(completed.stdout);assert report['ok'] is True and report['course_ids']==[41002,41001] and report['output']==str(output/'syllabus.html')
trace=json.loads((output/'requests.json').read_bytes());assert [row['path'] for row in trace['requests']]==['/api/v1/courses/41002','/api/v1/courses/41001']
for path,item in records.items():assert hashlib.sha256((destination/path).read_bytes()).hexdigest()==item['sha256']
stage['cliPassed']=True;stage['requestCount']=2;(root/'current-print-v4-stage-receipt.json').write_text(json.dumps(stage,indent=2)+'\n')
browser=subprocess.run(['/opt/homebrew/bin/node',str(root/'receive-print-v4.mjs')],capture_output=True,timeout=90)
(root/'current-print-v4-launch.stdout.txt').write_bytes(browser.stdout);(root/'current-print-v4-launch.stderr.txt').write_bytes(browser.stderr)
print(json.dumps(stage));print(browser.stdout.decode());print(browser.stderr.decode());raise SystemExit(browser.returncode)
