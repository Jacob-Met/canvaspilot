from pathlib import Path
import json,hashlib,os,stat,tarfile,io,gzip,base64,re,time
root=Path('/Users/me/hamon-canvas-syllabus-receiving-cd1df0f1ee24')
def meta(p):
 b=p.read_bytes()
 return {'path':str(p.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
links=[]
for p in sorted(root.rglob('*')):
 if p.is_symlink():links.append({'path':str(p.relative_to(root)),'target':os.readlink(p),'kind':'symlink','targetExists':p.exists(),'archivedAsSymlink':False})
(root/'filesystem-link-observations.json').write_text(json.dumps({'schema':'hamon.canvaspilot.syllabus.link-observations.v1','links':links,'boundary':'The exact native targets are observations only. Tar archive includes regular files and this JSON, with no symlink entries.'},indent=2)+'\n')
baseline=json.loads((root/'baseline-run-v3-01/cli-receiving.json').read_bytes())
candidate=json.loads((root/'candidate-v3-run-01/cli-receiving.json').read_bytes())
browser=json.loads((root/'browser-v3-run-01/browser-receiving.json').read_bytes())
final=json.loads((root/'current-print-v4-run-01/print-receiving.json').read_bytes())
visual=json.loads((root/'print-v4-inspection/visual-receiving.json').read_bytes())
assert baseline['passed'] and baseline['passedCases']==2
assert candidate['passed'] and candidate['passedCases']==29
assert browser['passed'] and browser['passedGroups']==9 and len(browser['downloads'])==5 and len(browser['screenshots'])==3
assert final['passed'] and visual['passed'] and visual['finalPages']==3
assert (root/'print-v4-inspection/page-2.png').read_bytes()==(root/'print-v3-inspection/page-2.png').read_bytes()
assert (root/'print-v4-inspection/page-3.png').read_bytes()==(root/'print-v3-inspection/page-3.png').read_bytes()
key_paths=['baseline-current-manifest.json','candidate-v3-manifest.json','candidate-current-print-v4-manifest.json','baseline-run-v1-01/cli-receiving.json','baseline-run-v3-01/cli-receiving.json','candidate-v3-run-01/cli-receiving.json','browser-v3-run-01/browser-receiving.json','print-v3-inspection/visual-receiving.json','current-print-v4-run-01/print-receiving.json','print-v4-inspection/visual-receiving.json','receiver-correction-v2.json','receiver-correction-v3.json','receiver-v3/input-manifest.json','browser-driver-v1-freeze.json','current-print-v4-stage-receipt.json']
receipt={'schema':'hamon.canvaspilot.syllabus.independent-receiving.v4','sealedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'custody':'https://github.com/Jacob-Met/canvaspilot/issues/65','authorWorker':'estate_source','receiverWorker':'estate_coordination','rootFamily':'estate-cd1df0f1ee24','accepted':True,'baseline':{'head':'c744bb5b79f23457f4dd9070f762100bc6ad91ad','tree':'abec51ddc40ab44d9e405857469736550d08b4f2','files':18,'controls':2,'passed':2,'missingFeatureObserved':True},'candidateV3':{'files':20,'cliCases':29,'cliPassed':29,'browserGroups':9,'browserPassed':9,'actualDownloads':browser['downloads'],'captures':browser['screenshots'],'httpAttempts':len(browser['attemptedNetwork']),'runtimeErrors':len(browser['runtimeErrors']),'consoleErrors':len(browser['consoleErrors']),'dialogs':len(browser['dialogs']),'printVisualAccepted':False,'printFailure':'Generated navigation footer alone on fourth page'},'finalCurrentPrintV4':{'parent':final['parent'],'parentTree':final['parentTree'],'files':21,'sourceManifestSHA256':final['sourceBefore']['manifestSHA256'],'moduleSHA256':final['moduleSHA256'],'actualOrderedCourseIds':[41002,41001],'completeHtmlEqualityAfterTwoPrintSubstitutionsAndTimestamp':True,'html':{'bytes':final['sourceBefore']['htmlBytes'],'sha256':final['sourceBefore']['htmlSHA256']},'pdf':final['pdf'],'pages':3,'allPagesVisuallyInspected':True,'coursePage2And3PixelsIdenticalToV3':True,'noFullGateRerun':True,'httpAttempts':len(final['networkAttempts']),'runtimeErrors':len(final['runtimeErrors']),'consoleErrors':len(final['consoleErrors']),'dialogs':len(final['dialogs'])},'runtime':{'python':candidate['python'],'browser':browser['browser'],'node':browser['node'],'httpx':'0.28.1','puppeteer':'25.12.0'},'failedAttemptsPreserved':['Initial ENOSPC receiver-archive transport; missing-input launch before product execution','v1 baseline empty-stderr assertion on inherited HTTPX INFO line','v2 receiver edit SyntaxError before execution','v3 generated-footer-only fourth print page','Initial diskless PDF renderer closed stdin before parsing'],'independence':{'contractAndCasesFrozenBeforeSourceImplementationInspection':True,'authoredTestBodiesRead':False,'productSourceEditedByReceiver':False,'liveCanvasAccountUsed':False,'networkSocketsUsedByFixtureTransport':False,'publicationClaim':False},'keyEvidence':[meta(root/p) for p in key_paths]}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
archive_name='native-receiving-v4.tar.gz'
excluded={archive_name,archive_name+'.b64','native-receiving-v4-export.json','artifact-manifest.json'}
paths=[p for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink() and p.name not in excluded and not p.name.endswith('.b64')]
entries=[meta(p) for p in paths]
manifest={'schema':'hamon.canvaspilot.syllabus.packet-manifest.v4','files':entries,'regularFilesExcludingManifest':len(entries),'regularBytesExcludingManifest':sum(i['bytes'] for i in entries),'symlinksRepresentedAsData':len(links),'transportBase64CopiesExcluded':True}
manifest_raw=(json.dumps(manifest,indent=2)+'\n').encode()
(root/'artifact-manifest.json').write_bytes(manifest_raw)
paths.append(root/'artifact-manifest.json')
broken=[]
for href in re.findall(r'\[[^\]]*\]\(([^)]+)\)',(root/'README.md').read_text()):
 if '://' in href or href.startswith('#'):continue
 target=(root/href).resolve()
 if not target.is_relative_to(root) or not target.exists():broken.append(href)
assert not broken,broken
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0,compresslevel=9) as compressed:
 with tarfile.open(fileobj=compressed,mode='w') as tar:
  for p in paths:
   info=tarfile.TarInfo(str(p.relative_to(root)));info.size=p.stat().st_size;info.mode=stat.S_IMODE(p.stat().st_mode);info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname=''
   with p.open('rb') as handle:tar.addfile(info,handle)
raw=buf.getvalue()
expected={item['path']:item for item in entries};expected['artifact-manifest.json']={'bytes':len(manifest_raw),'sha256':hashlib.sha256(manifest_raw).hexdigest()}
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
 names=tar.getnames();assert set(names)==set(expected) and len(names)==len(expected)
 for item in tar.getmembers():
  assert item.isfile() and not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
  data=tar.extractfile(item).read();pin=expected[item.name]
  assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],item.name
(root/archive_name).write_bytes(raw)
encoded=base64.b64encode(raw).decode()
(root/(archive_name+'.b64')).write_text('\n'.join(encoded[i:i+12000] for i in range(0,len(encoded),12000))+'\n')
export={'schema':'hamon.canvaspilot.syllabus.packet-export.v4','root':str(root),'archive':str(root/archive_name),'archiveBytes':len(raw),'archiveSHA256':hashlib.sha256(raw).hexdigest(),'manifestSHA256':hashlib.sha256(manifest_raw).hexdigest(),'receiptSHA256':hashlib.sha256((root/'receipt.json').read_bytes()).hexdigest(),'readmeSHA256':hashlib.sha256((root/'README.md').read_bytes()).hexdigest(),'filesIncludingManifest':len(paths),'rawBytesIncludingManifest':sum(p.stat().st_size for p in paths),'base64File':str(root/(archive_name+'.b64')),'base64Lines':(len(encoded)+11999)//12000,'readback':'Every archived regular file was read back, counted, and SHA-256 verified from the completed in-memory archive before saving. No symlinks or unsafe paths are in the tar.','topReadmeLinksValid':True}
(root/'native-receiving-v4-export.json').write_text(json.dumps(export,indent=2)+'\n')
print(json.dumps(export,indent=2))
