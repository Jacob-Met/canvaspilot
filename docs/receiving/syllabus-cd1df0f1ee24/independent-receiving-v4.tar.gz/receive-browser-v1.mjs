import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import assert from "node:assert/strict";
import {pathToFileURL} from "node:url";
import puppeteer from "/Users/me/.npm/_npx/4b4c857f6efdfb61/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js";

const root="/Users/me/hamon-canvas-syllabus-receiving-cd1df0f1ee24";
const output=path.join(root,"browser-v3-run-01");
await fs.mkdir(output);
const downloadRoot=path.join(output,"downloads");
await fs.mkdir(downloadRoot);
const hash=b=>crypto.createHash("sha256").update(b).digest("hex");
const fixtureRaw=await fs.readFile(path.join(root,"receiver-v3/fixtures.json"));
assert.equal(hash(fixtureRaw),"b5a9ad2970562a22107e734f32b8ab5dd230b67580bc6e2bbab5d0601fde1560");
const addendumRaw=await fs.readFile(path.join(root,"receiver-v3/public-interface.json"));
assert.equal(hash(addendumRaw),"9331294d3bbcf7ca5df7adc9c39e312f5278a96e210a25f1113917438f25b266");
const fixtures=JSON.parse(fixtureRaw), addendum=JSON.parse(addendumRaw);
const reportRaw=await fs.readFile(path.join(root,"candidate-v3-run-01/cli-receiving.json"));
const report=JSON.parse(reportRaw);
assert.equal(report.passed,true);assert.equal(report.passedCases,29);
assert.equal(report.sourceManifestSHA256,"9ed01815bb617c3059cc76abc7f948107d3520bbb99c0dcbc9e2d6d1dfe3f621");
const sourceManifestRaw=await fs.readFile(path.join(root,"candidate-v3-manifest.json"));
assert.equal(hash(sourceManifestRaw),report.sourceManifestSHA256);
const sourceManifest=JSON.parse(sourceManifestRaw);
const caseNames=["normal-selected","passive-html","line-endings-source","explicit-empty","missing-body","null-body"];
const inputRecords=[];
for(const name of caseNames){
 const row=report.cases.find(c=>c.name===name);assert.equal(row.passed,true);
 assert.equal(row.exitCode,0);
 const file=path.join(root,"candidate-v3-run-01",name,"syllabus.html");
 const bytes=await fs.readFile(file);assert.equal(hash(bytes),row.after.sha256);assert.equal(bytes.length,row.after.bytes);
 inputRecords.push({name,path:file,bytes:bytes.length,sha256:hash(bytes)});
}
async function verifySources(){
 for(const item of sourceManifest.files){
  const bytes=await fs.readFile(path.join(root,"candidate-v3",item.path));
  assert.equal(bytes.length,item.bytes,item.path);assert.equal(hash(bytes),item.sha256,item.path);
 }
 for(const item of inputRecords){const bytes=await fs.readFile(item.path);assert.equal(hash(bytes),item.sha256,item.name);}
 return {sourceFiles:sourceManifest.files.length,packetInputs:inputRecords.length,sourceManifestSHA256:hash(sourceManifestRaw),cliReceiptSHA256:hash(reportRaw)};
}
const result={schema:"hamon.canvaspilot.syllabus.independent-browser.v1",at:new Date().toISOString(),candidateVersion:"v3",sourceBefore:await verifySources(),inputs:inputRecords,groups:[],downloads:[],screenshots:[],attemptedNetwork:[],runtimeErrors:[],consoleErrors:[],dialogs:[],downloadEvents:[],claimBoundary:"Fictional HTTPX transport fixtures and native direct-file browser/print receiving; no live Canvas account or school-data claim."};
const browser=await puppeteer.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",headless:true,args:["--disable-background-networking","--no-first-run","--disable-component-update","--disable-default-apps","--disable-sync","--metrics-recording-only"],defaultViewport:{width:1280,height:900,deviceScaleFactor:1}});
result.browser=await browser.version();result.node=process.version;
const page=await browser.newPage();
const client=await page.target().createCDPSession();
await client.send("Browser.setDownloadBehavior",{behavior:"allow",downloadPath:downloadRoot,eventsEnabled:true});
client.on("Browser.downloadWillBegin",event=>result.downloadEvents.push({type:"begin",...event}));
client.on("Browser.downloadProgress",event=>{if(event.state==="completed"||event.state==="canceled")result.downloadEvents.push({type:"progress",...event});});
page.on("pageerror",error=>result.runtimeErrors.push(String(error)));
page.on("console",message=>{if(message.type()==="error")result.consoleErrors.push(message.text());});
page.on("dialog",async dialog=>{result.dialogs.push({type:dialog.type(),message:dialog.message()});await dialog.dismiss();});
await page.setRequestInterception(true);
page.on("request",request=>{
 const url=request.url();
 if(/^https?:/i.test(url)){result.attemptedNetwork.push({url,type:request.resourceType()});void request.abort();}
 else void request.continue();
});
async function openCase(name){
 const item=inputRecords.find(item=>item.name===name);
 await page.goto(pathToFileURL(item.path).href,{waitUntil:"load"});
 await page.waitForSelector("main");
 assert.equal(await page.title(),"Syllabus reading packet");
}
async function group(name,action){
 try{const details=await action();result.groups.push({name,passed:true,...details});}
 catch(error){result.groups.push({name,passed:false,error:String(error),stack:error.stack});}
}
async function capture(filename){
 const file=path.join(output,filename);await page.screenshot({path:file,fullPage:false});
 const bytes=await fs.readFile(file);const record={file:filename,bytes:bytes.length,sha256:hash(bytes)};
 result.screenshots.push(record);return record;
}
async function actualSourceDownload(course){
 const filename="course-"+course.id+"-syllabus-source.txt";
 const details="#course-"+course.id+" details.packet-source";
 const opened=await page.$eval(details,node=>node.open);
 if(!opened){await page.focus(details+" summary");await page.keyboard.press("Enter");}
 await page.waitForSelector(details+"[open]");
 const selector=details+' a[download="'+filename+'"]';
 const descriptor=await page.$eval(selector,node=>({href:node.getAttribute("href"),download:node.download}));
 assert.match(descriptor.href,/^data:text\/plain;base64,/);
 assert.equal(descriptor.download,filename);
 const expected=Buffer.from(course.syllabus_body,"utf8");
 assert.deepEqual(Buffer.from(descriptor.href.split(",")[1],"base64"),expected);
 await page.click(selector);
 const target=path.join(downloadRoot,filename);
 const started=Date.now();let raw;
 while(Date.now()-started<10000){
  try{const candidate=await fs.readFile(target);if(candidate.length===expected.length&&hash(candidate)===hash(expected)){raw=candidate;break;}}catch{}
  await new Promise(resolve=>setTimeout(resolve,30));
 }
 assert.ok(raw,"actual browser download completed: "+filename);
 assert.deepEqual(raw,expected);
 const record={courseId:course.id,filename,bytes:raw.length,sha256:hash(raw),exactUtf8:true,actualNativeClick:true};
 result.downloads.push(record);return record;
}
async function passiveDOM(){
 return page.evaluate(names=>{
  const badElements=[...document.querySelectorAll("script,iframe,object,embed,img,video,audio,source,track,svg,math,form,input,button,link,base")].map(n=>n.outerHTML);
  const badAttributes=[...document.querySelectorAll("*")].flatMap(node=>[...node.attributes].filter(a=>/^on/i.test(a.name)||["src","srcset","poster","action","formaction","style"].includes(a.name)).map(a=>({tag:node.tagName,name:a.name,value:a.value})));
  const unsafeLinks=[...document.querySelectorAll("a[href]")].map(a=>({href:a.getAttribute("href"),download:a.getAttribute("download")})).filter(a=>!a.href.startsWith("#")&&!/^https?:\/\//i.test(a.href)&&!(a.href.startsWith("data:text/plain;base64,")&&/^course-[0-9]+-syllabus-source\.txt$/.test(a.download||"")));
  const sentinels=Object.fromEntries(names.map(name=>[name,typeof window[name]]));
  return {badElements,badAttributes,unsafeLinks,sentinels,refreshCount:document.querySelectorAll('meta[http-equiv="refresh" i]').length,styleElements:document.querySelectorAll("style").length};
 },fixtures.expected.activeSentinels);
}
try{
 await group("ordered-course-identity-and-semantic-reading",async()=>{
  await openCase("normal-selected");
  const observed=await page.evaluate(()=>{
   const courses=[...document.querySelectorAll("section.course")].map(s=>({id:Number(s.dataset.courseId),status:s.dataset.syllabusStatus,heading:s.querySelector("h2").textContent,meta:Object.fromEntries([...s.querySelectorAll("dl.meta dt")].map(dt=>[dt.textContent,dt.nextElementSibling.textContent]))}));
   return {courses,headings:[...document.querySelectorAll(".syllabus h1,.syllabus h2,.syllabus h3")].map(n=>n.textContent),ordered:[...document.querySelectorAll("#course-41001 .syllabus ol li")].map(n=>n.textContent),unordered:[...document.querySelectorAll("#course-41001 .syllabus ul li")].map(n=>n.textContent),rows:[...document.querySelectorAll("#course-41001 .syllabus tr")].map(tr=>[...tr.children].map(cell=>cell.textContent)),caption:document.querySelector("#course-41001 .syllabus caption").textContent,code:document.querySelector("#course-41002 .syllabus pre code").textContent,reading:[...document.querySelectorAll(".syllabus")].map(n=>n.innerText).join("\n"),notice:document.querySelector(".notice").innerText,configured:document.querySelector(".packet-header .small").innerText,links:[...document.querySelectorAll("#course-41001 .syllabus a")].map(a=>({label:a.textContent,href:a.getAttribute("href")}))};
  });
  assert.deepEqual(observed.courses.map(c=>c.id),fixtures.expected.selectedCourseIdsExactly);
  for(const c of observed.courses){assert.equal(c.heading,fixtures.courseResponses[c.id].name);assert.equal(c.status,"supplied");assert.equal(c.meta["Course ID"],String(c.id));assert.equal(c.meta["Course code"],fixtures.courseResponses[c.id].course_code);}
  assert.deepEqual(observed.headings,fixtures.expected.normalHeadings);
  assert.deepEqual(observed.ordered,fixtures.expected.orderedListItems);assert.deepEqual(observed.unordered,fixtures.expected.unorderedListItems);
  assert.deepEqual(observed.rows,fixtures.expected.assessmentRows);assert.equal(observed.caption,"Assessment plan");assert.equal(observed.code,fixtures.expected.visibleCode);
  for(const text of fixtures.expected.visibleUnicode)assert.ok(observed.reading.includes(text),text);
  assert.match(observed.configured,/Configured Canvas base URL: https:\/\/campus\.example\.test/);
  assert.match(observed.notice,/sequential course reads/);assert.match(observed.notice,/not a verified response origin/);
  assert.deepEqual(observed.links,[{label:"Field-note page",href:"https://campus.example.test/courses/41001/pages/field-notes"},{label:"External reading",href:"https://reference.example.test/reading?chapter=2&lang=en"}]);
  return {observed};
 });
 await group("local-navigation-keyboard-source-and-two-real-downloads",async()=>{
  await openCase("normal-selected");
  await page.click('nav a[href="#course-41001"]');
  assert.equal(await page.evaluate(()=>location.hash),"#course-41001");
  const source41001=await actualSourceDownload(fixtures.courseResponses["41001"]);
  const source41002=await actualSourceDownload(fixtures.courseResponses["41002"]);
  await page.$eval("#course-41001 .syllabus",n=>n.scrollIntoView());
  const image=await capture("normal-course-desktop.png");
  return {downloads:[source41001,source41002],image,keyboardDisclosure:true};
 });
 await group("passive-html-text-resources-and-escaped-metadata",async()=>{
  await openCase("passive-html");
  const observed=await page.evaluate(()=>({heading:document.querySelector(".course>h2").textContent,reading:document.querySelector(".syllabus").innerText,omissions:[...document.querySelectorAll(".syllabus .omission")].map(n=>n.textContent),unsafeLabels:[...document.querySelectorAll(".syllabus span")].filter(n=>["Unsafe link label remains readable","Encoded unsafe link label","Data link label"].includes(n.textContent)).map(n=>n.textContent),ordinary:document.querySelector(".syllabus p[onclick]")}));
  assert.equal(observed.heading,fixtures.courseResponses["41009"].name);
  for(const text of fixtures.expected.passiveVisible)assert.ok(observed.reading.includes(text),text);
  for(const resource of ["img","iframe","script","style","video","audio","svg","form"])assert.ok(observed.omissions.some(t=>t.includes(resource+" element not embedded")),resource);
  assert.ok(observed.reading.includes("Field diagram available in Canvas"));
  const dom=await passiveDOM();assert.deepEqual(dom.badElements,[]);assert.deepEqual(dom.badAttributes,[]);assert.deepEqual(dom.unsafeLinks,[]);assert.equal(dom.refreshCount,0);assert.equal(dom.styleElements,1);
  for(const type of Object.values(dom.sentinels))assert.equal(type,"undefined");
  const sentence=await page.$$("p");for(const element of sentence){if((await element.evaluate(n=>n.textContent)).trim()==="Keep this ordinary sentence."){await element.click();break;}}
  const afterClick=await passiveDOM();for(const type of Object.values(afterClick.sentinels))assert.equal(type,"undefined");
  await page.$eval(".syllabus",n=>n.scrollIntoView());
  return {observed,dom,image:await capture("passive-reading-desktop.png")};
 });
 await group("passive-original-source-is-a-real-inert-text-download",async()=>{
  await openCase("passive-html");return {download:await actualSourceDownload(fixtures.courseResponses["41009"])};
 });
 await group("original-crlf-cr-lf-and-unicode-source-bytes",async()=>{
  await openCase("line-endings-source");const download=await actualSourceDownload(addendum.sourceFixture);
  const raw=await fs.readFile(path.join(downloadRoot,download.filename));
  const text=raw.toString("utf8");assert.ok(text.includes("\r\n")&&text.includes("\r<")&&text.includes("\n</pre>"));
  assert.ok(text.includes("café")&&text.includes("μm"));
  return {download,lineEndingsPreserved:true};
 });
 await group("empty-missing-and-null-remain-distinct",async()=>{
  const observations=[];
  for(const [name,id,state] of [["explicit-empty",41004,"empty"],["missing-body",41003,"not_supplied"],["null-body",41005,"unavailable"]]){
   await openCase(name);const observed=await page.$eval(".course",s=>({id:Number(s.dataset.courseId),state:s.dataset.syllabusStatus,status:s.querySelector(".status").textContent,downloads:s.querySelectorAll("a[download]").length}));
   assert.equal(observed.id,id);assert.equal(observed.state,state);
   if(state==="empty"){assert.match(observed.status,/explicitly empty/);assert.match(observed.status,/zero bytes/);assert.equal(observed.downloads,1);await actualSourceDownload(fixtures.courseResponses[id]);}
   else{assert.match(observed.status,/unknown/);assert.equal(observed.downloads,0);}
   observations.push(observed);
  }
  return {observations};
 });
 await group("narrow-viewport-readable-course-and-table",async()=>{
  await page.setViewport({width:390,height:844,deviceScaleFactor:1});await openCase("normal-selected");
  await page.$eval("#course-41001 .syllabus",n=>n.scrollIntoView());
  const layout=await page.evaluate(()=>({width:innerWidth,documentWidth:document.documentElement.scrollWidth,tableWidth:document.querySelector("#course-41001 .table-wrap").getBoundingClientRect().width,courseWidth:document.querySelector("#course-41001").getBoundingClientRect().width}));
  assert.ok(layout.documentWidth<=layout.width+1);assert.ok(layout.tableWidth<=layout.courseWidth);
  return {layout,image:await capture("normal-course-phone.png")};
 });
 await group("native-print-to-pdf-of-the-readable-selected-packet",async()=>{
  await page.setViewport({width:1280,height:900,deviceScaleFactor:1});await openCase("normal-selected");
  await page.emulateMediaType("print");
  const printState=await page.evaluate(()=>({navigation:getComputedStyle(document.querySelector("nav")).display,rawSources:[...document.querySelectorAll(".packet-source")].map(n=>getComputedStyle(n).display),courses:[...document.querySelectorAll(".course")].map(n=>({id:n.dataset.courseId,display:getComputedStyle(n).display}))}));
  assert.equal(printState.navigation,"none");assert.deepEqual(printState.rawSources,["none","none"]);for(const c of printState.courses)assert.notEqual(c.display,"none");
  const file=path.join(output,"selected-syllabus-reading.pdf");
  await page.pdf({path:file,format:"A4",printBackground:true,preferCSSPageSize:true,tagged:true});
  const raw=await fs.readFile(file);assert.equal(raw.subarray(0,5).toString(),"%PDF-");
  await page.emulateMediaType("screen");
  return {printState,pdf:{file:path.basename(file),bytes:raw.length,sha256:hash(raw)},visualInspectionPending:true};
 });
 await group("no-automatic-network-no-executed-source",async()=>{
  await new Promise(resolve=>setTimeout(resolve,200));
  assert.deepEqual(result.attemptedNetwork,[]);assert.deepEqual(result.runtimeErrors,[]);assert.deepEqual(result.consoleErrors,[]);assert.deepEqual(result.dialogs,[]);
  return {attemptedHttpRequests:0,runtimeErrors:0,consoleErrors:0,dialogs:0};
 });
 result.sourceAfter=await verifySources();assert.deepEqual(result.sourceAfter,result.sourceBefore);
}finally{
 await browser.close();
 result.finishedAt=new Date().toISOString();result.passed=result.groups.every(g=>g.passed);result.passedGroups=result.groups.filter(g=>g.passed).length;
 await fs.writeFile(path.join(output,"browser-receiving.json"),JSON.stringify(result,null,2)+"\n");
}
console.log(JSON.stringify({passed:result.passed,groups:result.groups.length,passedGroups:result.passedGroups,downloads:result.downloads.length,screenshots:result.screenshots.length,failed:result.groups.filter(g=>!g.passed).map(g=>({name:g.name,error:g.error})),output}));
process.exitCode=result.passed?0:1;
