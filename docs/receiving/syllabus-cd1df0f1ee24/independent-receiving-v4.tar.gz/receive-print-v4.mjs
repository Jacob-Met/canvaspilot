import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import assert from "node:assert/strict";
import {pathToFileURL} from "node:url";
import puppeteer from "/Users/me/.npm/_npx/4b4c857f6efdfb61/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js";
const root="/Users/me/hamon-canvas-syllabus-receiving-cd1df0f1ee24";
const source=path.join(root,"candidate-current-print-v4");
const output=path.join(root,"current-print-v4-run-01");
const hash=b=>crypto.createHash("sha256").update(b).digest("hex");
const manifestRaw=await fs.readFile(path.join(root,"candidate-current-print-v4-manifest.json"));
const manifest=JSON.parse(manifestRaw);
const stage=JSON.parse(await fs.readFile(path.join(root,"current-print-v4-stage-receipt.json")));
assert.equal(hash(manifestRaw),stage.sourceManifestSHA256);
assert.equal(manifest.parent,"6c4d5d2e7526cddc1aa6c90bfbef2d1188382ad3");
const newModule=await fs.readFile(path.join(source,"src/canvaspilot/syllabus_packet.py"));
assert.equal(hash(newModule),"005a837c10bb185edf0bcc75c3ab50609f6afbe49d38161e841380116ab97bd7");
const oldModule=await fs.readFile(path.join(root,"candidate-v3/src/canvaspilot/syllabus_packet.py"));
assert.equal(hash(oldModule),"7e60d8b5b1598078ca28a1e11bd458acdcff180cfe28ad126360cae38cf8f0ce");
const substitutions=[["nav,.top-link,.packet-source{display:none}","nav,.top-link,.packet-source,.packet-footer{display:none}"],['<footer>Saved by CanvasPilot.','<footer class="packet-footer">Saved by CanvasPilot.']];
function twoPrintChanges(text){
 for(const [before,after] of substitutions){assert.equal(text.split(before).length,2);text=text.replace(before,after);}
 return text;
}
assert.equal(newModule.toString(),twoPrintChanges(oldModule.toString()));
const oldCli=JSON.parse(await fs.readFile(path.join(root,"candidate-v3-run-01/normal-selected/stdout.txt")));
const newCli=JSON.parse(await fs.readFile(path.join(output,"stdout.txt")));
assert.equal(newCli.ok,true);assert.deepEqual(newCli.course_ids,[41002,41001]);
const html=await fs.readFile(path.join(output,"syllabus.html"));
const oldHtml=await fs.readFile(path.join(root,"candidate-v3-run-01/normal-selected/syllabus.html"));
let expected=twoPrintChanges(oldHtml.toString());
assert.equal(expected.split(oldCli.captured_at).length,2);
expected=expected.replace(oldCli.captured_at,newCli.captured_at);
assert.equal(html.toString(),expected);
async function verify(){
 for(const item of manifest.files){const b=await fs.readFile(path.join(source,item.path));assert.equal(b.length,item.bytes,item.path);assert.equal(hash(b),item.sha256,item.path);}
 assert.equal(hash(await fs.readFile(path.join(output,"syllabus.html"))),hash(html));
 return {files:manifest.files.length,manifestSHA256:hash(manifestRaw),htmlSHA256:hash(html),htmlBytes:html.length};
}
const result={schema:"hamon.canvaspilot.syllabus.current-parent-print-receiving.v1",startedAt:new Date().toISOString(),parent:manifest.parent,parentTree:manifest.parent_tree,moduleSHA256:hash(newModule),sourceBefore:await verify(),priorSource:"candidate-v3",changes:"Exactly two generated-footer print substitutions; complete normal HTML equal after only those substitutions and capture timestamp update.",fixture:"Original normal-selected, ordered 41002 then 41001, adapter/fixtures/case unchanged.",networkAttempts:[],runtimeErrors:[],consoleErrors:[],dialogs:[],pdfVisualInspectionPending:true};
const browser=await puppeteer.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",headless:true,args:["--disable-background-networking","--no-first-run","--disable-component-update","--disable-default-apps","--disable-sync","--metrics-recording-only"],defaultViewport:{width:1280,height:900,deviceScaleFactor:1}});
result.browser=await browser.version();result.node=process.version;
try{
 const page=await browser.newPage();
 page.on("pageerror",e=>result.runtimeErrors.push(String(e)));
 page.on("console",m=>{if(m.type()==="error")result.consoleErrors.push(m.text());});
 page.on("dialog",async d=>{result.dialogs.push(d.message());await d.dismiss();});
 await page.setRequestInterception(true);
 page.on("request",r=>{if(/^https?:/i.test(r.url())){result.networkAttempts.push(r.url());void r.abort();}else void r.continue();});
 await page.goto(pathToFileURL(path.join(output,"syllabus.html")).href,{waitUntil:"load"});
 await page.emulateMediaType("print");
 result.printState=await page.evaluate(()=>({footerCount:document.querySelectorAll("footer.packet-footer").length,footer:getComputedStyle(document.querySelector("footer.packet-footer")).display,navigation:getComputedStyle(document.querySelector("nav")).display,sources:[...document.querySelectorAll(".packet-source")].map(n=>getComputedStyle(n).display),courseIds:[...document.querySelectorAll(".course")].map(n=>Number(n.dataset.courseId))}));
 assert.equal(result.printState.footerCount,1);assert.equal(result.printState.footer,"none");assert.equal(result.printState.navigation,"none");assert.deepEqual(result.printState.sources,["none","none"]);assert.deepEqual(result.printState.courseIds,[41002,41001]);
 const pdf=path.join(output,"selected-syllabus-reading.pdf");
 await page.pdf({path:pdf,format:"A4",printBackground:true,preferCSSPageSize:true,tagged:true});
 const b=await fs.readFile(pdf);assert.equal(b.subarray(0,5).toString(),"%PDF-");
 result.pdf={file:path.basename(pdf),bytes:b.length,sha256:hash(b)};
 assert.deepEqual(result.networkAttempts,[]);assert.deepEqual(result.runtimeErrors,[]);assert.deepEqual(result.consoleErrors,[]);assert.deepEqual(result.dialogs,[]);
 result.sourceAfter=await verify();assert.deepEqual(result.sourceBefore,result.sourceAfter);result.passed=true;
}catch(error){result.passed=false;result.error=String(error);result.stack=error.stack;}
finally{await browser.close();result.finishedAt=new Date().toISOString();await fs.writeFile(path.join(output,"print-receiving.json"),JSON.stringify(result,null,2)+"\n");}
console.log(JSON.stringify(result));
process.exitCode=result.passed?0:1;
