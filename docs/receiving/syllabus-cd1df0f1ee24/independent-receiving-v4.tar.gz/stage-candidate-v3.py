from pathlib import Path
import hashlib,json,time,subprocess,sys,os
root=Path('/Users/me/hamon-canvas-syllabus-receiving-cd1df0f1ee24')
author=Path('/Users/me/Developer/canvaspilot-syllabus-cd1df0f1ee24')
baseline_raw=(root/'baseline-current-manifest.json').read_bytes()
assert hashlib.sha256(baseline_raw).hexdigest()=='e5ead774db7575dae827d1db85c370945453250173ea3c92193126b5e34aec2b'
payload_raw=(author/'inputs/candidate-v3-manifest.json').read_bytes()
assert hashlib.sha256(payload_raw).hexdigest()=='e29410667866ae6e8387c18ee0eb270fbe0baf4c8a2a3749be9dbc4eb5a32ddb'
payload=json.loads(payload_raw);baseline=json.loads(baseline_raw)
records={item['path']:item for item in baseline['files']}
payload_sources=[i for i in payload['files'] if not i['path'].startswith('tests/')]
assert {i['path'] for i in payload_sources}=={'README.md','docs/syllabus-packet.md','src/canvaspilot/cli.py','src/canvaspilot/syllabus_packet.py'}
records.update({item['path']:item for item in payload_sources})
assert len(records)==20
destination=root/'candidate-v3';assert not destination.exists();destination.mkdir()
for path,item in records.items():
 p=Path(path);assert not p.is_absolute() and '..' not in p.parts and not str(p).startswith('tests/')
 data=(author/'candidate-v3'/p).read_bytes()
 assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],path
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['git_blob'],path
 target=destination/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
manifest={'schema':'hamon.canvaspilot.independent-candidate-source.v3','baseline':baseline['head'],'baselineTree':baseline['tree'],'sourcePayloadManifestSHA256':hashlib.sha256(payload_raw).hexdigest(),'sourceBaselineManifestSHA256':hashlib.sha256(baseline_raw).hexdigest(),'authorTestsRead':False,'files':sorted(records.values(),key=lambda i:i['path'])}
raw=(json.dumps(manifest,indent=2)+'\n').encode();mpath=root/'candidate-v3-manifest.json';mpath.write_bytes(raw)
(root/'author-candidate-v3-payload-manifest.json').write_bytes(payload_raw)
receipt={'at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'sourceFiles':20,'sourceManifestSHA256':hashlib.sha256(raw).hexdigest(),'sourcePayloadManifestSHA256':hashlib.sha256(payload_raw).hexdigest(),'sourceRoot':str(destination),'unchangedBaselineFiles':16,'payloadSourceFiles':4,'authorTestsRead':False}
(root/'candidate-v3-stage-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
cmd=[sys.executable,str(root/'receiver-v3/receive-cli.py'),str(destination),str(mpath),receipt['sourceManifestSHA256'],str(root/'receiver-v3'),str(root/'candidate-v3-run-01'),'candidate']
completed=subprocess.run(cmd,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
(root/'candidate-v3-launch.stdout.txt').write_bytes(completed.stdout);(root/'candidate-v3-launch.stderr.txt').write_bytes(completed.stderr)
print(json.dumps(receipt));print(completed.stdout.decode());print(completed.stderr.decode());raise SystemExit(completed.returncode)
