from pathlib import Path
import base64,hashlib,json,tarfile,io,shutil,time,subprocess,sys,os
root=Path('/Users/me/hamon-canvas-syllabus-receiving-cd1df0f1ee24')
author=Path('/Users/me/Developer/canvaspilot-syllabus-cd1df0f1ee24')
raw=base64.b64decode((root/'receiver-v1.tar.gz.b64').read_bytes())
assert hashlib.sha256(raw).hexdigest()=='34716714421c50f148e321f663898765433b1ab36da0b4635d7f19af649e8608'
(root/'receiver-v1.tar.gz').write_bytes(raw)
receiver=root/'receiver-v1';receiver.mkdir()
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
 for entry in tar.getmembers():
  assert entry.isfile() and '/' not in entry.name and entry.name not in {'.','..'}
  (receiver/entry.name).write_bytes(tar.extractfile(entry).read())
manifest_raw=(receiver/'input-manifest.json').read_bytes()
assert hashlib.sha256(manifest_raw).hexdigest()=='11ea4768fcf8b381b170a4a89d75b999506ba9255da152bf0d3a1f2e742546f1'
for item in json.loads(manifest_raw)['files']:
 data=(receiver/item['path']).read_bytes()
 assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
source_raw=(author/'inputs/source-current-manifest.json').read_bytes()
assert hashlib.sha256(source_raw).hexdigest()=='e5ead774db7575dae827d1db85c370945453250173ea3c92193126b5e34aec2b'
source_manifest=json.loads(source_raw);destination=root/'baseline-current';destination.mkdir()
for item in source_manifest['files']:
 p=Path(item['path']);assert not p.is_absolute() and '..' not in p.parts and not str(p).startswith('tests/')
 data=(author/'baseline-current'/p).read_bytes()
 assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['git_blob']
 target=destination/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
(root/'baseline-current-manifest.json').write_bytes(source_raw)
receipt={'stage':'baseline-current','at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'sourceManifestSHA256':hashlib.sha256(source_raw).hexdigest(),'sourceFiles':len(source_manifest['files']),'receiverManifestSHA256':hashlib.sha256(manifest_raw).hexdigest(),'receiverArchiveSHA256':hashlib.sha256(raw).hexdigest(),'receiverFiles':len(json.loads(manifest_raw)['files']),'authorTestsRead':False}
(root/'baseline-stage-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
command=[sys.executable,str(receiver/'receive-cli.py'),str(destination),str(root/'baseline-current-manifest.json'),receipt['sourceManifestSHA256'],str(receiver),str(root/'baseline-run-v1-01'),'baseline']
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
completed=subprocess.run(command,env=env,capture_output=True)
(root/'baseline-launch.stdout.txt').write_bytes(completed.stdout);(root/'baseline-launch.stderr.txt').write_bytes(completed.stderr)
print(json.dumps(receipt));print(completed.stdout.decode());print(completed.stderr.decode())
raise SystemExit(completed.returncode)
