# Independent receiving contract: CanvasPilot offline syllabus packet

This contract and its fictional fixtures are frozen before the receiver inspects the new exporter implementation or authored tests. Existing CLI/client contracts may determine the adapter syntax; they do not change these outcome requirements. The receiver owns no production files.

## Selection and fetch boundary

The user selects courses explicitly. The export must use the existing get_course consumer for exactly those course identities, with the documented syllabus inclusion. It must not expand the selection into unrelated courses or require a list-all-courses request. A successful packet identifies each selected course once and does not substitute a response with a different ID. Preserve selection order unless an existing documented project convention explicitly defines another deterministic order.

If any selected-course fetch fails, the operation must fail as a whole and must not leave a partial packet claiming a successful complete selection. A failed fetch is not an empty syllabus. Invalid selection and returned course identity are refused before producing a successful artifact.

## Availability and output preservation

An explicit empty-string syllabus body is a successfully received empty body and needs an honest visible statement. An omitted field or explicit null must never be silently relabeled as an authored empty body: either refuse the export with a clear reason or retain a visibly distinct unavailable state. A non-string, non-null body is malformed and must be refused. These alternatives are fixed before implementation: a visible unavailability diagnosis is acceptable; silently collapsing unavailable into empty is not.

An existing output file must be refused without changing its bytes. The receiver will also create an output sentinel during a selected fetch to challenge a check-then-write race. Existing directories or symlink entries at the output path must not be followed or replaced. All such fixtures stay inside the receiver's own temporary directory.

## Reading, identity and passive HTML

Preserve useful semantic structure and content from normal HTML: headings, paragraphs, emphasis, ordered and unordered lists, tables with correct cell relationships, block quotations and preformatted examples. The fixture includes literal angle brackets, ampersands, quotes, Unicode and line breaks. Do not silently lose substantive text while removing active markup.

The document identifies its configured Canvas source and each course's exact ID, name and code without treating metadata as markup. Any retained source/navigation links must point to the intended source and use safe schemes. Relative source links need correct source resolution or an explicit unavailable-link treatment; they must not accidentally resolve inside the local output directory.

Imported content is passive. Inline scripts, event handlers, frames, embedded objects, form submissions, refresh navigation, external style/resource loading and active URL schemes must not execute or trigger automatic network activity. Source-provided CSS is not trusted. Safe explicit links may remain for deliberate navigation, with the offline boundary clear. Removal of remote images/media must be explicit enough that a reader does not mistake omitted material for a complete local copy. The output is a reading packet, not a course backup or restoration artifact.

## Actual receiving route

Use the actual project CLI entrypoint and existing client seam against controlled fictional responses; record selected get_course calls and full exit/output behavior. Run the unchanged acceptance against the qualified baseline and candidate. Do not read authored tests to obtain expected values.

Open the actual generated output in a fresh native Chrome profile with all page HTTP/HTTPS requests intercepted and blocked. A passing passive output must attempt none. Check the HTML structure, visible fixture content, source identity, script sentinels and retained links. Any runtime dialog or injection sentinel is a failure. Preserve errors and first attempts.

If existing output conventions support browser printing, print the actual HTML to a PDF using native Chromium. Inspect extracted text and render every resulting page for visual review of headings, table rows, pagination and legibility. This print route is separate from the CLI's output format and is not a request to introduce a PDF dependency into the product. Use installed tools only.

## Independent fixture outcomes

- Courses 41002 and 41001: successful selected-course packet; all expected headings, lists, table relationships, code and Unicode remain readable.
- Course 41009: ordinary headings/list/table text survives while its active sentinels and external resource attempts remain absent.
- Course 41004: explicit empty body is honestly identified.
- Courses 41003 and 41005: omitted/null availability is not silently converted to explicit empty.
- Course 41006: malformed body refused.
- Course 41008: mismatched returned identity refused.
- Selection 41001 + 41007: failure leaves no successful partial output.
- Existing output and output created during fetch: exact sentinel bytes preserved.

The fixtures contain no live learner information, credentials or real course content. All remote URLs are example or invalid test domains; the browser receiver will not navigate them.

## Primary API reference

The Canvas Course object documents syllabus_body as optional user-generated HTML. The single-course endpoint accepts the syllabus_body include option inherited from the course-list endpoint. This is why field absence and an explicitly returned empty string need distinct handling. Reference: https://canvas.instructure.com/doc/api/courses.html (single-course and Course-object sections), with the current official portal at https://developerdocs.instructure.com/services/canvas. The project source remains the authority for its existing get_course interface.
