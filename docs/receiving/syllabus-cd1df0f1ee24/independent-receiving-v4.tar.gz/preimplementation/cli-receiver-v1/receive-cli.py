"""Frozen independent CLI cases. Baseline runs reader control plus the missing command once."""
from __future__ import annotations
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

source, source_manifest_path, source_manifest_sha, receiver, output, stage = sys.argv[1:]
source, source_manifest_path, receiver, output = map(Path, (source, source_manifest_path, receiver, output))
assert stage in {"baseline", "candidate"}
assert not output.exists()
output.mkdir(parents=True)
fixtures_path = receiver / "fixtures.json"
addendum_path = receiver / "public-interface.json"
case_path = receiver / "cases.json"
assert hashlib.sha256(fixtures_path.read_bytes()).hexdigest() == "b5a9ad2970562a22107e734f32b8ab5dd230b67580bc6e2bbab5d0601fde1560"
assert hashlib.sha256(addendum_path.read_bytes()).hexdigest() == "9331294d3bbcf7ca5df7adc9c39e312f5278a96e210a25f1113917438f25b266"
fixtures = json.loads(fixtures_path.read_text())
sentinel = fixtures["expected"]["outputSentinel"].encode()
cases = json.loads(case_path.read_text())
if stage == "baseline":
    cases = cases[:2]
result = {"schema": "hamon.canvaspilot.syllabus.independent-cli-receiving.v1", "stage": stage, "startedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "sourceRoot": str(source), "sourceManifestSHA256": source_manifest_sha, "python": sys.version, "cases": []}

def verify_source():
    raw = source_manifest_path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == source_manifest_sha
    manifest = json.loads(raw)
    for item in manifest["files"]:
        body = (source / item["path"]).read_bytes()
        assert len(body) == item["bytes"], item["path"]
        assert hashlib.sha256(body).hexdigest() == item["sha256"], item["path"]
    return manifest

def artifact(path):
    if path.is_symlink():
        return {"kind": "symlink", "target": os.readlink(path)}
    if path.is_dir():
        return {"kind": "directory", "files": sorted(str(p.relative_to(path)) for p in path.rglob("*"))}
    if path.exists():
        b = path.read_bytes()
        return {"kind": "file", "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}
    return {"kind": "absent"}

result["sourceBefore"] = verify_source()
for case in cases:
    directory = output / case["name"]
    directory.mkdir()
    path = directory / "syllabus.html"
    target = directory / "target.txt"
    if case.get("setup") == "file":
        path.write_bytes(sentinel)
    elif case.get("setup") == "directory":
        path.mkdir()
        (path / "sentinel.txt").write_bytes(sentinel)
    elif case.get("setup") == "symlink":
        target.write_bytes(sentinel)
        path.symlink_to(target)
    elif case.get("setup") == "dangling-symlink":
        path.symlink_to(target)
    before = artifact(path)
    raw_case = directory / "case.json"
    raw_case.write_text(json.dumps(case, indent=2) + "\n")
    trace_path = directory / "requests.json"
    command = [sys.executable, str(receiver / "invoke-cli.py"), str(source), str(fixtures_path), str(addendum_path), str(raw_case), str(trace_path), str(path)]
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE="1", CANVAS_API_TOKEN="receiver-fixture-not-a-credential", PYTHONPATH=str(source / "src"))
    completed = subprocess.run(command, env=env, cwd=directory, capture_output=True, timeout=30)
    (directory / "stdout.txt").write_bytes(completed.stdout)
    (directory / "stderr.txt").write_bytes(completed.stderr)
    trace = json.loads(trace_path.read_text())
    after = artifact(path)
    row = {"name": case["name"], "expected": case["expected"], "exitCode": completed.returncode, "stdout": completed.stdout.decode("utf-8", "replace"), "stderr": completed.stderr.decode("utf-8", "replace"), "requests": trace["requests"], "before": before, "after": after, "browser": case.get("browser", False), "command": command}
    try:
        calls = [int(call["path"].rsplit("/", 1)[1]) for call in trace["requests"]]
        if stage == "baseline" and case["name"] == "normal-selected":
            assert completed.returncode == 2
            assert "invalid choice" in row["stderr"] and "export-syllabus" in row["stderr"]
            assert calls == [] and after["kind"] == "absent" and not completed.stdout.strip()
            row["expectedFeatureGapObserved"] = True
        else:
            assert calls == case["calls"], (calls, case["calls"])
            if case["expected"] == "reader":
                assert completed.returncode == 0
                assert json.loads(row["stdout"]) == {"readerControl": True, "id": 41001, "bodyExact": True}
                assert not row["stderr"]
            elif case["expected"] == "success" or (case["expected"] == "availability" and completed.returncode == 0):
                assert completed.returncode == 0
                response = json.loads(row["stdout"])
                assert response["ok"] is True and response["output"] == str(path)
                assert not row["stderr"]
                assert after["kind"] == "file" and after["bytes"] > 0
                assert "<html" in path.read_text().lower()
                row["report"] = response
            elif case["expected"] == "invalid":
                assert completed.returncode in (1, 2)
                assert not completed.stdout.strip() and completed.stderr.strip()
                assert after["kind"] == "absent"
            else:
                assert completed.returncode == 1
                response = json.loads(row["stderr"])
                assert response["ok"] is False
                assert not completed.stdout.strip()
                row["report"] = response
                if case.get("setup"):
                    assert after == before
                    if case["setup"] == "symlink":
                        assert target.read_bytes() == sentinel
                    elif case["setup"] == "dangling-symlink":
                        assert not target.exists()
                    elif case["setup"] == "directory":
                        assert (path / "sentinel.txt").read_bytes() == sentinel
                elif case.get("race") == "file":
                    assert path.read_bytes() == sentinel
                elif case.get("race") == "dangling-symlink":
                    assert path.is_symlink()
                    assert os.readlink(path) == str(directory / "never-create-race-target.txt")
                    assert not (directory / "never-create-race-target.txt").exists()
                else:
                    assert after["kind"] == "absent"
            assert not [p for p in directory.iterdir() if p.name.startswith(".syllabus.html.")], "no leaked publication temporary"
        row["passed"] = True
    except Exception as error:
        row["passed"] = False
        row["assertion"] = repr(error)
    result["cases"].append(row)
result["sourceAfter"] = verify_source()
assert result["sourceBefore"] == result["sourceAfter"]
result["finishedAt"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
result["passed"] = all(case["passed"] for case in result["cases"])
result["passedCases"] = sum(case["passed"] for case in result["cases"])
(output / "cli-receiving.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"stage": stage, "passed": result["passed"], "cases": len(result["cases"]), "passedCases": result["passedCases"], "expectedMissingCommand": stage == "baseline", "output": str(output), "failures": [case["name"] for case in result["cases"] if not case["passed"]]}))
raise SystemExit(0 if result["passed"] else 1)
