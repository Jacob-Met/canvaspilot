"""Independent transport adapter: real CanvasPilot CLI and HTTPX, fictional responses only."""
from __future__ import annotations
import json
import os
from pathlib import Path
import runpy
import sys
import httpx

source, fixtures_path, addendum_path, case_path, trace_path, output_path = map(Path, sys.argv[1:])
sys.dont_write_bytecode = True
sys.path.insert(0, str(source / "src"))
fixtures = json.loads(fixtures_path.read_text())
addendum = json.loads(addendum_path.read_text())
case = json.loads(case_path.read_text())
calls = []
expected_base = fixtures["canvasBaseUrl"]
bodies = dict(fixtures["courseResponses"])
bodies[str(addendum["sourceFixture"]["id"])] = addendum["sourceFixture"]
recipes = addendum["budgetRecipes"]
for label in ("individualOver", "individualExact"):
    recipe = recipes[label]
    body = recipe["bodyPrefix"] + recipe["repeat"] * recipe["count"] + recipe["bodySuffix"]
    assert len(body.encode("utf-8")) == recipe["expectedUtf8Bytes"]
    identity = recipe["id"]
    bodies[str(identity)] = {"id": identity, "name": label, "course_code": label, "syllabus_body": body}
for label in ("totalOver", "totalExact"):
    recipe = recipes[label]
    assert len(recipe["repeat"].encode("utf-8")) * recipe["countPerBody"] * len(recipe["ids"]) == recipe["expectedTotalUtf8Bytes"]
    for identity in recipe["ids"]:
        bodies[str(identity)] = {"id": identity, "name": label + " " + str(identity), "course_code": str(identity), "syllabus_body": recipe["repeat"] * recipe["countPerBody"]}
sentinel = fixtures["expected"]["outputSentinel"].encode("utf-8")
original_client = httpx.Client

def handler(request: httpx.Request) -> httpx.Response:
    record = {"method": request.method, "origin": str(request.url.copy_with(path="", query=None, fragment=None)).rstrip("/"), "path": request.url.path, "query": list(request.url.params.multi_items()), "syntheticAuthorizationPresent": request.headers.get("authorization") == "Bearer receiver-fixture-not-a-credential"}
    calls.append(record)
    assert record["method"] == "GET", "receiver forbids any mutation request"
    assert record["origin"] == expected_base
    assert request.url.path.startswith("/api/v1/courses/")
    identity = request.url.path.rsplit("/", 1)[1]
    assert identity.isascii() and identity.isdigit()
    assert request.url.params.get_list("include[]") == ["syllabus_body", "term", "total_scores"]
    assert request.url.params.get("per_page") == "50"
    assert record["syntheticAuthorizationPresent"]
    if case.get("race") and len(calls) == 1:
        if case["race"] == "file":
            output_path.write_bytes(sentinel)
        elif case["race"] == "dangling-symlink":
            output_path.symlink_to(output_path.parent / "never-create-race-target.txt")
        else:
            raise AssertionError("unknown independent race fixture")
    if case.get("responseMode") == "empty-response":
        return httpx.Response(200, content=b"", headers={"content-type": "application/json"})
    if case.get("responseMode") == "non-json":
        return httpx.Response(200, text="<p>Fixture sign-in HTML is not a course object.</p>", headers={"content-type": "text/html"})
    if case.get("responseMode") == "array":
        return httpx.Response(200, json=[])
    if case.get("responseMode") == "missing-id":
        return httpx.Response(200, json={"name": "Missing returned ID", "syllabus_body": "<p>Do not attribute this to a selected ID.</p>"})
    if identity in fixtures["fetchErrors"]:
        failure = fixtures["fetchErrors"][identity]
        return httpx.Response(failure["status"], json={"error": failure["message"]})
    assert identity in bodies, "unexpected course selection"
    return httpx.Response(200, json=bodies[identity])

class FixtureHTTPXClient(original_client):
    def __init__(self, *args, **kwargs):
        assert "transport" not in kwargs
        kwargs["transport"] = httpx.MockTransport(handler)
        kwargs["trust_env"] = False
        super().__init__(*args, **kwargs)

httpx.Client = FixtureHTTPXClient
try:
    if case.get("readerControl"):
        from canvaspilot.api import CanvasAPI
        from canvaspilot.client import CanvasClient
        with CanvasAPI(CanvasClient(base_url=expected_base, token="receiver-fixture-not-a-credential", profile=output_path.parent / "unused-profile")) as api:
            result = api.get_course(41001)
        assert result == fixtures["courseResponses"]["41001"]
        print(json.dumps({"readerControl": True, "id": result["id"], "bodyExact": True}))
    else:
        sys.argv = ["canvaspilot", "export-syllabus", *case["ids"], "--out", str(output_path), "--base-url", expected_base, "--profile", str(output_path.parent / "unused-profile"), "--token", "receiver-fixture-not-a-credential"]
        runpy.run_module("canvaspilot.cli", run_name="__main__")
finally:
    Path(trace_path).write_text(json.dumps({"schema": "hamon.canvaspilot.syllabus.request-trace.v1", "case": case["name"], "requests": calls, "transport": "actual HTTPX request construction with a MockTransport; no network socket is opened", "sourceRoot": str(source)}, indent=2) + "\n")
