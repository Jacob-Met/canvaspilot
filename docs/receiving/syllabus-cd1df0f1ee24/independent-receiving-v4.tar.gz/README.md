# CanvasPilot syllabus packet — independent receiving

**Final result:** the current-parent print v4 candidate is accepted for the bounded source, CLI, offline reading, exact-download and print requirements below. This packet preserves the original baseline, receiver calibration failures, v3 qualification and its print defect, and the final v4 correction. It does not claim publication, installation, live-school access or a learner outcome.

Custody is the existing [CanvasPilot issue 65](https://github.com/Jacob-Met/canvaspilot/issues/65). The source author is the family’s estate_source worker; this packet was produced by estate_coordination as an independent receiver. The receiver did not edit production source or inspect the author’s test bodies. Payload manifests include test filenames and hashes only.

## Evidence to read first

- [Compact receiving receipt](receipt.json) and [complete artifact manifest](artifact-manifest.json).
- [Original independent contract](preimplementation/receiving-contract-v1/README.md), [fictional fixtures](preimplementation/receiving-contract-v1/fixtures.json), [public-interface addendum](preimplementation/receiving-addendum-v1/public-interface.json), and [original 29 cases](preimplementation/cli-receiver-v1/cases.json).
- [Final baseline witness](baseline-run-v3-01/cli-receiving.json): the existing reader works and the new command is absent.
- [V3 CLI outcomes](candidate-v3-run-01/cli-receiving.json): 29 of 29 cases pass.
- [V3 native browser outcomes](browser-v3-run-01/browser-receiving.json): 9 of 9 automated groups pass, five actual text downloads, three captures. The subsequent visual print check found a separate defect.
- [Original four-page print inspection](print-v3-inspection/visual-receiving.json), [original PDF](browser-v3-run-01/selected-syllabus-reading.pdf), and [footer-only page](print-v3-inspection/page-4.png).
- [Current-parent actual CLI and print receipt](current-print-v4-run-01/print-receiving.json), [final three-page PDF](current-print-v4-run-01/selected-syllabus-reading.pdf), and [final visual acceptance](print-v4-inspection/visual-receiving.json).

## Exact source boundaries

| Receiving stage | Input identity | Actual execution |
| --- | --- | --- |
| Baseline | c744bb5b79f23457f4dd9070f762100bc6ad91ad; tree abec51ddc40ab44d9e405857469736550d08b4f2; 18 production/configuration files | Existing get_course transport control and one absent export-syllabus command witness |
| Candidate v3 | Four production/documentation payload files over that baseline; complete 20-file source closure | 29 independent CLI cases and 9 native browser groups |
| Current-parent print v4 | Parent 6c4d5d2e7526cddc1aa6c90bfbef2d1188382ad3; tree 50b0e4001ccad72078b073e2cc3606b619e064ff; complete 21-file source closure | Original normal-selected CLI route, complete HTML equivalence, and final offline print only |

[Baseline source manifest](baseline-current-manifest.json): e5ead774db7575dae827d1db85c370945453250173ea3c92193126b5e34aec2b.

[V3 receiving source manifest](candidate-v3-manifest.json): 9ed01815bb617c3059cc76abc7f948107d3520bbb99c0dcbc9e2d6d1dfe3f621. The v3 module is Git blob b121e1e61a12fbfcc6c9dcd53359bb05a55f6cab, SHA-256 7e60d8b5b1598078ca28a1e11bd458acdcff180cfe28ad126360cae38cf8f0ce.

[Final current source manifest](candidate-current-print-v4-manifest.json): 294b441fb1690104003e4991b300cb5c5aca9c4a5dee7f8bc7db29be136c5403. The final module is Git blob 1faf3448c391fdb76b8cf38fe5854906614443b1, SHA-256 005a837c10bb185edf0bcc75c3ab50609f6afbe49d38161e841380116ab97bd7. The final composed CLI is Git blob 4da09c80c41ad9ee99a8dce229280877c7e4850a, SHA-256 dea49a6bd83b6212af8c2a1bc9b820adef29497b655a60b9cae3841e1646bc83.

Every staged source file was verified by byte count, SHA-256 and Git blob before copying. Each execution then checked its complete receiving source closure before and after. The 20-file v3 closure preserves 16 baseline files; the 21-file final closure preserves 17 current-parent files. Broader current-parent command-preservation checks belong to the author/root’s separate packet, and are not counted as executions here.

## What the independent CLI receiver proves

The [transport adapter](receiver-v3/invoke-cli.py) runs the real CanvasPilot CLI through runpy, the real CanvasAPI.get_course and real CanvasClient request construction. It substitutes only an HTTPX MockTransport, supplies an explicit fictional token and base URL, and refuses mutation methods or unexpected requests. No socket is opened and no signed-in broker is probed.

The exact get_course request includes syllabus_body, term and total_scores, with the inherited per_page=50. The selected normal order is 41002 then 41001. Each case retains its command, actual stdout/stderr, request trace, output and before/after observation.

The 29 cases cover the working reader control; selected-source success; semantic and passive HTML; mixed original line endings; explicit empty, absent and null bodies; wrong body/response types; missing or mismatched course identity; a late fetch failure; selection validation before any GET; existing files/directories/symlinks; a file or dangling symlink appearing during the fetch; and individual/combined UTF-8 size admission.

The individual exact case is 524,288 bytes and the over case is 524,289 bytes. The total exact case is 2,097,152 bytes and the over case is 2,097,155 bytes. These deliberately include multibyte source, so a character-count implementation cannot satisfy the individual boundary. Refusal publishes no partial packet. Existing or racing outputs retain their sentinel bytes or symlink target, and the writer leaves no publication temporary.

[Filesystem-link observations](filesystem-link-observations.json) preserve the exact native symlink targets. The archive stores those observations as data and does not recreate absolute native symlinks when extracted.

## Actual offline reading and downloads

The [frozen browser driver](receive-browser-v1.mjs) uses native Chromium 154.0.8037.98, Node 26.3.0 and the already available Puppeteer installation. It opens the actual CLI-produced HTML directly by file URL. Page HTTP requests are intercepted, recorded and refused; none were attempted. Runtime errors, console errors and dialogs were also zero.

The normal packet preserves course identity and order, exact returned name/code, headings, ordered and unordered lists, table headers/rows/caption, code, Unicode, ordinary links and the configured-context notice. Local navigation and keyboard disclosure work. The 390 × 844 viewport has no document overflow, and its course table remains readable. This is a narrow desktop-browser viewport check, not a physical-phone claim.

The passive fixture contains source-supplied scripts, event handlers, styles, remote images/media/frames, forms, SVG, refresh/base markup and unsafe links. The live DOM contains none of those active elements/attributes. Readable prose, emphasis, lists and table cells remain; omitted resources and inert destinations are visible. All execution sentinels stay undefined, including after a real click.

The five actual browser downloads are retained under [downloads](browser-v3-run-01/downloads/). They cover both normal courses, the passive source, mixed CRLF/CR/LF with Unicode, and an explicitly empty zero-byte source. Each downloaded file matches the original UTF-8 fixture bytes and SHA-256. Absent/null bodies have no invented source download. Source previews are not used as the byte oracle.

Actual captures:

- [Desktop normal course](browser-v3-run-01/normal-course-desktop.png).
- [Desktop passive reading and omitted-resource markers](browser-v3-run-01/passive-reading-desktop.png).
- [390-pixel course and table](browser-v3-run-01/normal-course-phone.png).

All three captures were visually inspected. Text, lists, tables and destinations are legible; the boundary-heavy fixture is deliberately dense.

## Print defect and accepted correction

V3’s automated print group confirmed PDF generation and print visibility, but visual inspection of all four pages found a generated navigation footer alone on page 4. That is preserved as a real production presentation failure, separate from the passing automated groups.

The author’s v4 module changes exactly two strings: the generated final footer receives packet-footer, and that class joins the existing print-hidden selector. Source-authored footer elements remain in the passive projection; their source classes are not copied. The guide also explains that the generated navigation footer is omitted from print.

The [bounded final driver](receive-print-v4.mjs) uses the original normal-selected fixture, original transport adapter and the current-parent composed source. The actual normal HTML is byte-for-byte equal to v3 after exactly those two substitutions and the new capture timestamp. No other reading content or embedded source bytes changed.

Final PDF: 264,380 bytes, SHA-256 64228420a59046c6ac7d17b906e73d85281461d3505db8a11a9a6cda0c78fbea. It has exactly three tagged A4 pages, with no PDF JavaScript. All three were rendered with Poppler at 110 dpi and visually inspected:

- [Page 1: identity and complete reading boundary](print-v4-inspection/page-1.png).
- [Page 2: reasoning course](print-v4-inspection/page-2.png).
- [Page 3: studio course and assessment table](print-v4-inspection/page-3.png).

Final pages 2 and 3 are byte-identical PNGs to their v3 counterparts. The fourth page is gone. Page 1 preserves its full content with the new timestamp. No clipped text, missing Unicode glyphs, split table rows or raw-source controls were observed.

The earlier 29 cases and 9 browser groups remain v3 executions. They are not relabeled as v4 reruns.

## Preserved receiver and transport failures

The first baseline reader returned the exact expected object and request, but the original receiver required empty stderr. Inherited HTTPX INFO logging violated that receiver assumption. Its [raw baseline result](baseline-run-v1-01/cli-receiving.json) and request/stderr files remain unchanged.

The intended receiver correction separates only the exact baseline-observed HTTPX request-line form, preserving raw stderr. Its first edit was transported with JavaScript replacement-string semantics around a dollar anchor, producing invalid Python. The [v2 launch stderr](baseline-v2-launch.stderr.txt) and [v2 source](receiver-v2/receive-cli.py) are retained; no case ran in that attempt. Literal insertion and a compile check produced the [final corrected receiver](receiver-v3/receive-cli.py). Fixtures, cases, transport assertions and output expectations were unchanged. [Correction receipt](receiver-correction-v3.json).

Initial native archive transport returned ENOSPC; the subsequent launcher stopped at the absent archive before source staging or product execution. A later capacity check allowed the identical archive to transfer and verify. No broad cleanup was performed. The [transport/first calibration note](receiver-correction-v2.json) records this boundary.

Local storage was too small to copy the PDF for inspection. The first diskless renderer attempt encountered a closed stdin pipe before parsing. A raw PTY transport then verified the exact PDF SHA and rendered every page from memory. The final PDFs, all page PNGs and inspection receipts are retained; this transport change did not alter product output.

## Scope and reuse

This is reproducible receiving evidence for a local export consumer. The inputs are fictional and contain no live school account, student records or credentials. The configured Canvas URL is context, not proof of upstream response origin. Sequential reads are not a simultaneous snapshot; omitted linked content is not reproduced offline.

The source snapshots and original/corrected receiver files are retained with exact pins. Large boundary HTML outputs are included intact in the compressed archive. The artifact manifest covers every regular archived file, mode and hash; symlink observations are explicit data. Publication and final repository-tree preservation belong to the root integration lane.
