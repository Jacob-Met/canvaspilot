from pathlib import Path
import hashlib,json,subprocess,time,sys,shutil
root=Path('/Users/me/hamon-canvas-syllabus-receiving-cd1df0f1ee24')
driver=root/'receive-browser-v1.mjs'
raw=driver.read_bytes()
receipt={'at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'driver':str(driver),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'frozenContracts':['b85cad13dc6f0295e6d02dbb8d4c55a9b98308d1ba81e9ff47a137e803b42c9e','430675a1d6527f9ec038f898a3e254b9bdce8ff537518954c2dd4d932b81ed57'],'sourceManifestSHA256':'9ed01815bb617c3059cc76abc7f948107d3520bbb99c0dcbc9e2d6d1dfe3f621','authorTestsRead':False,'freeBytes':shutil.disk_usage(root).free}
(root/'browser-driver-v1-freeze.json').write_text(json.dumps(receipt,indent=2)+'\n')
completed=subprocess.run(['/opt/homebrew/bin/node',str(driver)],capture_output=True,timeout=180)
(root/'browser-v1-launch.stdout.txt').write_bytes(completed.stdout);(root/'browser-v1-launch.stderr.txt').write_bytes(completed.stderr)
print(json.dumps(receipt));print(completed.stdout.decode());print(completed.stderr.decode());raise SystemExit(completed.returncode)
