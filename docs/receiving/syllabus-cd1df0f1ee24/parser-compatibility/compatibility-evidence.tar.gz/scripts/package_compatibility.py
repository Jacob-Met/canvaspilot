from pathlib import Path
import gzip,hashlib,io,json,tarfile

r=Path("/dev/shm/hamon-canvas-parser-compat-cd1df0f1ee24")
def pin(path,data):
 return {"path":path,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
files={str(p.relative_to(r)):p.read_bytes() for p in r.rglob("*") if p.is_file() and p.name not in {"archive-manifest.json","compatibility-evidence.tar.gz","archive-receipt.json"}}
assert pin("module",files["src/canvaspilot/syllabus_packet.py"])["git_blob"]=="1faf3448c391fdb76b8cf38fe5854906614443b1"
assert pin("test",files["tests/test_syllabus_packet.py"])["git_blob"]=="fbd71a3aeb546ae77aad32d8e13e56495b19781e"
manifest={"schema":"canvaspilot-parser-compatibility-archive/1","baseline_head":"60986834820abbe6b5a51b4d2cc6b6b80559409a","product_module_unchanged":True,"test_only_replacement":"tests/test_syllabus_packet.py","files":[pin(n,b) for n,b in sorted(files.items())],"primary_sources":[{"tag":v,"url":"https://github.com/python/cpython/blob/v"+v+"/Lib/html/parser.py","archive_path":"inputs/parser-"+v+".py"} for v in ["3.12.8","3.12.15"]],"license_files":["inputs/LICENSE-3.12.8","inputs/LICENSE-3.12.15"],"native_scope":"Local Python3.12.14, selected maintained assertion bodies with explicit stdlib adapter; no pytest run, no different interpreter, no product mutation."}
m=(json.dumps(manifest,indent=2)+"\n").encode();files["archive-manifest.json"]=m
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode="w") as t:
 for n,b in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0
  t.addfile(info,io.BytesIO(b))
archive=gzip.compress(buf.getvalue(),mtime=0)
with tarfile.open(fileobj=io.BytesIO(archive),mode="r:gz") as t:
 assert len(t.getmembers())==len(files)
 for member in t.getmembers():
  assert member.isfile() and t.extractfile(member).read()==files[member.name]
(r/"archive-manifest.json").write_bytes(m)
(r/"compatibility-evidence.tar.gz").write_bytes(archive)
receipt={**pin("compatibility-evidence.tar.gz",archive),"members":len(files),"every_member_readback_exact":True,"manifest":pin("archive-manifest.json",m)}
(r/"archive-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
