"""Execute selected regression assertions with a stdlib adapter, not pytest.

Each compatibility profile uses this same Python 3.12.14 interpreter. The
versioned profiles substitute only the explicitly pinned html.parser and
_markupbase sources. They are not executions of Python 3.12.8 or 3.12.15.
"""
from __future__ import annotations

import ast
import base64
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
PARSERS = Path("/dev/shm/hamon-canvas-root-recovery-cd1df0f1ee24/compatibility")
BODY = "<![unrecognized]>Visible course text"
PORTABLE = "test_malformed_marked_declaration_matches_supported_parser_behavior"
INJECTED = "test_parser_assertion_has_a_handled_whole_packet_refusal"
ORIGINAL = "test_malformed_marked_declaration_has_a_handled_whole_packet_refusal"


def pin(path):
    b = path.read_bytes()
    return {
        "path": str(path), "bytes": len(b),
        "sha256": hashlib.sha256(b).hexdigest(),
        "git_blob": hashlib.sha1(b"blob " + str(len(b)).encode() + b"\0" + b).hexdigest(),
    }


def load_source(name, path, replacement=None):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    source = path.read_text()
    if replacement is not None:
        old, new = replacement
        assert source.count(old) == 1
        source = source.replace(old, new, 1)
    exec(compile(source, str(path), "exec"), module.__dict__)
    return module


class Raises:
    """Only the raises/context/value semantics used by these two test bodies."""
    def __init__(self, expected, match=None):
        self.expected = expected
        self.match = match
        self.value = None

    def __enter__(self):
        return self

    def __exit__(self, kind, value, traceback):
        if kind is None:
            raise AssertionError("DID NOT RAISE " + self.expected.__name__)
        if not issubclass(kind, self.expected):
            return False
        if self.match is not None and re.search(self.match, str(value)) is None:
            raise AssertionError("Exception did not match " + self.match) from value
        self.value = value
        return True


def selected_test_namespace(path, selected):
    tree = ast.parse(path.read_text(), filename=str(path))
    names = {"API", "course", "build", "Elements", *selected}
    nodes = []
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            if isinstance(node, ast.Import) and any(a.name == "pytest" for a in node.names):
                continue
            nodes.append(node)
        elif isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == "STAMP" for t in node.targets
        ):
            nodes.append(node)
        elif isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names:
            assert not node.decorator_list
            nodes.append(node)
    namespace = {"pytest": SimpleNamespace(raises=Raises)}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec"), namespace)
    return namespace


def run_injected(namespace):
    with contextlib.ExitStack() as stack:
        monkeypatch = SimpleNamespace(
            setattr=lambda obj, key, value: stack.enter_context(patch.object(obj, key, value))
        )
        namespace[INJECTED](monkeypatch)


def observed(call):
    try:
        call()
    except Exception as error:
        return {"passed": False, "error": type(error).__name__, "message": str(error)}
    return {"passed": True}


def profile(name):
    import html
    import html.parser

    substituted = []
    if name != "ambient":
        base_path = PARSERS / "_markupbase-3.12.8.py"
        parser_path = PARSERS / f"parser-{name}.py"
        assert pin(base_path)["sha256"] == "cb14dd6f2e2439eb70b806cd49d19911363d424c2b6b9f4b73c9c08022d47030"
        expected_parser = {
            "3.12.8": "ab5a0a2fce2bec75d969dbe057b490ef574f9ac57cce9e0eaaf7a220b301e838",
            "3.12.15": "a4c5558209ffe6d677dbe18e4a4b2d34672c73aee46e39b1d118846afa62a9ff",
        }[name]
        assert pin(parser_path)["sha256"] == expected_parser
        load_source("_markupbase", base_path)
        html.parser = load_source("html.parser", parser_path)
        substituted = [pin(base_path), pin(parser_path)]

    parser_class = html.parser.HTMLParser
    probe = observed(lambda: (lambda p: (p.feed(BODY), p.close()))(parser_class()))
    if name == "3.12.8":
        assert probe.get("error") == "AssertionError"
    if name == "3.12.15":
        assert probe["passed"]

    package = ModuleType("canvaspilot")
    package.__path__ = [str(ROOT / "src/canvaspilot")]
    sys.modules["canvaspilot"] = package
    source_path = ROOT / "src/canvaspilot/syllabus_packet.py"
    source_pin = pin(source_path)
    assert source_pin["git_blob"] == "1faf3448c391fdb76b8cf38fe5854906614443b1"
    package.syllabus_packet = load_source("canvaspilot.syllabus_packet", source_path)
    assert package.syllabus_packet.HTMLParser is parser_class

    original_ns = selected_test_namespace(ROOT / "baseline/test_syllabus_packet.py", [ORIGINAL])
    original_result = observed(original_ns[ORIGINAL])
    assert original_result["passed"] is (not probe["passed"])
    if probe["passed"]:
        assert original_result["message"] == "DID NOT RAISE ValueError"

    ns = selected_test_namespace(ROOT / "tests/test_syllabus_packet.py", [INJECTED, PORTABLE])
    candidate_results = {
        INJECTED: observed(lambda: run_injected(ns)),
        PORTABLE: observed(ns[PORTABLE]),
    }
    assert all(x["passed"] for x in candidate_results.values()), candidate_results

    package.syllabus_packet = load_source(
        "canvaspilot.syllabus_packet", source_path,
        ("except AssertionError as error:", "except RuntimeError as error:"),
    )
    broken_ns = selected_test_namespace(ROOT / "tests/test_syllabus_packet.py", [INJECTED, PORTABLE])
    catch_control = observed(lambda: run_injected(broken_ns))
    assert catch_control == {
        "passed": False, "error": "AssertionError",
        "message": "synthetic declaration parser failure",
    }
    controls = {"removed_assertion_handler_detected": catch_control}

    if probe["passed"]:
        package.syllabus_packet = load_source("canvaspilot.syllabus_packet", source_path)
        for label, before, after in [
            (
                "changed_projection_detected",
                '<div class="syllabus">Visible course text</div>',
                '<div class="syllabus">Changed reading</div>',
            ),
            (
                "changed_source_download_detected",
                base64.b64encode(BODY.encode()).decode(),
                base64.b64encode(b"changed source").decode(),
            ),
        ]:
            bad_ns = selected_test_namespace(ROOT / "tests/test_syllabus_packet.py", [PORTABLE])
            actual_build = bad_ns["build"]

            def changed(*args, **kwargs):
                data, report = actual_build(*args, **kwargs)
                assert data.count(before.encode()) == 1
                return data.replace(before.encode(), after.encode(), 1), report

            bad_ns["build"] = changed
            result = observed(bad_ns[PORTABLE])
            assert not result["passed"] and result["error"] == "AssertionError", result
            controls[label] = result

    assert pin(source_path) == source_pin
    return {
        "profile": name,
        "interpreter": sys.version,
        "execution_kind": "selected maintained assertion bodies through explicitly bounded stdlib adapter; not pytest",
        "substitution_limit": "Only pinned html.parser and _markupbase are substituted; the interpreter and other stdlib modules remain local.",
        "substituted_sources": substituted,
        "actual_parser_probe": probe,
        "original_test_result": original_result,
        "candidate_assertions": candidate_results,
        "deliberate_defect_controls": controls,
        "product_source_unchanged": source_pin,
        "candidate_test": pin(ROOT / "tests/test_syllabus_packet.py"),
    }


if __name__ == "__main__":
    if len(sys.argv) == 2:
        print(json.dumps(profile(sys.argv[1]), indent=2))
    else:
        results = []
        for name in ["ambient", "3.12.8", "3.12.15"]:
            run = subprocess.run(
                [sys.executable, str(Path(__file__).resolve()), name],
                text=True, capture_output=True, timeout=30, check=False,
                env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
            )
            (ROOT / f"evidence/compatibility-{name}.stdout.json").write_text(run.stdout)
            (ROOT / f"evidence/compatibility-{name}.stderr.txt").write_text(run.stderr)
            assert run.returncode == 0, (name, run.returncode, run.stderr)
            assert not run.stderr
            results.append(json.loads(run.stdout))
        receipt = {
            "baseline_head": "60986834820abbe6b5a51b4d2cc6b6b80559409a",
            "original_hosted_checkout": "dd93da752adce9a77619c1f8cd2179fb360f887b",
            "original_hosted_python": "3.12.15",
            "original_hosted_result": "1 failed, 1026 passed, 1 skipped, 54 subtests passed; Ruff passed",
            "original_hosted_log": pin(ROOT / "evidence/original-hosted-job-113457378013.log"),
            "maintained_assertion_bodies_passed": 6,
            "profile_count": 3,
            "deliberate_defect_controls_detected": sum(len(x["deliberate_defect_controls"]) for x in results),
            "profiles": results,
            "limitations": [
                "No pytest, Ruff, HTTPX or other package was installed.",
                "No whole-repository test run or different Python interpreter is claimed.",
                "The official _markupbase.py bodies at v3.12.8 and v3.12.15 were fetched and compared equal before using the single pinned copy.",
                "The original failed CI and earlier native 3.12.8 receiving remain separately attributed.",
            ],
        }
        (ROOT / "evidence/compatibility-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps({
            "profiles": len(results), "maintained_assertion_bodies_passed": 6,
            "negative_controls_detected": receipt["deliberate_defect_controls_detected"],
            "receipt": pin(ROOT / "evidence/compatibility-receipt.json"),
        }, indent=2))
