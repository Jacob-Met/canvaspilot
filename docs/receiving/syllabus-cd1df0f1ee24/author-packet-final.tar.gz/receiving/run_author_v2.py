from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/Users/me/Developer/canvaspilot-syllabus-cd1df0f1ee24')
out=root/'receiving/author-v2';out.mkdir(exist_ok=False)
runtime='/Users/me/canvaspilot-announcements-3dcb83a1/.venv/bin/python'
env={k:v for k,v in os.environ.items() if not k.startswith('CANVAS_')}
env['PYTHONDONTWRITEBYTECODE']='1'
env['PYTHONPATH']=str(root/'candidate-v2/src')
results=[]
commands=[
 ('pytest',[runtime,'-m','pytest','-p','no:cacheprovider','--basetemp',str(out/'pytest-temp'),'-q','tests/test_syllabus_packet.py','tests/test_syllabus_packet_cli.py']),
 ('ruff',[runtime,'-m','ruff','check','--no-cache','--config','pyproject.toml','src','tests']),
]
for label,command in commands:
    start=time.monotonic()
    with (out/(label+'.stdout.log')).open('wb') as stdout,(out/(label+'.stderr.log')).open('wb') as stderr:
        p=subprocess.run(command,cwd=root/'candidate-v2',env=env,stdout=stdout,stderr=stderr,timeout=240)
    results.append({'label':label,'command':command,'exit':p.returncode,'seconds':time.monotonic()-start})
    print(json.dumps(results[-1]),flush=True)
pins=json.loads((root/'inputs/candidate-v2-manifest.json').read_text())
for f in pins['files']:
    assert hashlib.sha256((root/'candidate-v2'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
data=(json.dumps({'source_manifest':'inputs/candidate-v2-manifest.json','results':results,'source_unchanged':True},indent=2)+'\n').encode()
(out/'receipt.json').write_bytes(data)
print(json.dumps({'receipt_sha256':hashlib.sha256(data).hexdigest()}),flush=True)
