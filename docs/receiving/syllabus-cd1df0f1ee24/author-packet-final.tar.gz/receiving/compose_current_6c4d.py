from pathlib import Path
import ast,hashlib,json,shutil
r=Path('/Users/me/Developer/canvaspilot-syllabus-cd1df0f1ee24')
source=json.loads((r/'inputs/source-6c4d5d2e.json').read_text())
payload=json.loads((r/'inputs/composition-6c4d5d2e.json').read_text())
base=r/'baseline-6c4d5d2e';base.mkdir(exist_ok=False)
protected=[]
for f in source['files']:
    b=f['content'].encode();g=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    assert g==f['git_blob'],f['path']
    p=base/f['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    protected.append({'path':f['path'],'bytes':len(b),'git_blob':g,'sha256':hashlib.sha256(b).hexdigest()})
dest=r/'composition-6c4d5d2e';shutil.copytree(base,dest)
contribution=[]
for f in payload['files']:
    p=dest/f['path'];p.parent.mkdir(parents=True,exist_ok=True);b=f['content'].encode();p.write_bytes(b)
    contribution.append({'path':f['path'],'bytes':len(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'sha256':hashlib.sha256(b).hexdigest()})
before=(base/'src/canvaspilot/cli.py').read_text();after=(dest/'src/canvaspilot/cli.py').read_text()
assert after.replace(payload['cli_parser'],'',1).replace(payload['cli_dispatch'],'',1)==before
before=(base/'README.md').read_text();after=(dest/'README.md').read_text()
assert after.replace(payload['readme_span'],'\n',1)==before
for f in protected:
    if f['path'] not in {'README.md','src/canvaspilot/cli.py'}:
        assert hashlib.sha256((dest/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
v3=json.loads((r/'inputs/candidate-v3-manifest.json').read_text())
for f in v3['files']:
    if f['path'] not in {'README.md','src/canvaspilot/cli.py'}:
        assert hashlib.sha256((dest/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
def function_text(p):
    text=p.read_text();tree=ast.parse(text);cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='CanvasAPI')
    return ast.get_source_segment(text,next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='get_course'))
assert function_text(base/'src/canvaspilot/api.py')==function_text(r/'baseline-current/src/canvaspilot/api.py')
receipt={'parent':source['head'],'parent_tree':source['tree'],'source_closure_files':len(protected),'protected_exact_files':len(protected)-2,'qualified_v3_payload_exact_except_composed_cli_readme':4,'cli_inverse_exact':True,'readme_inverse_exact':True,'get_course_exact':True,'parent_source':protected,'contribution':contribution,'native_receiving':'Pending bounded current-parent CLI success/order, late failure/no output and inherited help equality.'}
b=(json.dumps(receipt,indent=2)+'\n').encode();(r/'inputs/composition-6c4d5d2e-manifest.json').write_bytes(b)
print(json.dumps({'manifest_sha256':hashlib.sha256(b).hexdigest(),'contribution':contribution,'protected_exact_files':len(protected)-2,'free_bytes':shutil.disk_usage(r).free}))
