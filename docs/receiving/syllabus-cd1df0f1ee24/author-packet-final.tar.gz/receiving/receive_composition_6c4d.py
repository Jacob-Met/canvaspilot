from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

ROOT = Path("/Users/me/Developer/canvaspilot-syllabus-cd1df0f1ee24")
BASE = ROOT / "baseline-6c4d5d2e"
CANDIDATE = ROOT / "composition-6c4d5d2e"
OUT = ROOT / "receiving/current-6c4d5d2e"
OUT.mkdir(exist_ok=False)
RUNTIME = "/Users/me/canvaspilot-announcements-3dcb83a1/.venv/bin/python"
ENV = {k: v for k, v in os.environ.items()
       if not k.startswith("CANVAS_") and not k.lower().endswith("_proxy")}
ENV["PYTHONDONTWRITEBYTECODE"] = "1"
processes = []
requests = []
phase = "success"


def command(source, label, args):
    argv = [RUNTIME, "-m", "canvaspilot.cli", *args]
    env = {**ENV, "PYTHONPATH": str(source / "src")}
    result = subprocess.run(argv, env=env, cwd=source, capture_output=True, timeout=30, check=False)
    (OUT / (label + ".stdout")).write_bytes(result.stdout)
    (OUT / (label + ".stderr")).write_bytes(result.stderr)
    processes.append({"label": label, "argv": argv, "source": str(source), "exit": result.returncode,
                      "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
                      "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()})
    return result


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlsplit(self.path)
        record = {"phase": phase, "method": "GET", "path": parsed.path,
                  "query": parse_qs(parsed.query)}
        requests.append(record)
        assert self.headers.get("Authorization") == "Bearer fictional-current-parent-token"
        course_id = int(parsed.path.rsplit("/", 1)[1])
        if phase == "late-refusal" and course_id == 42:
            status, body = 503, {"error": "fictional later-course refusal"}
        else:
            status = 200
            body = {"id": course_id, "name": f"Composition studio {course_id}",
                    "syllabus_body": "<h2>Current-parent reading</h2><p>Bring a notebook.</p>" if course_id == 57 else ""}
        encoded = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def log_message(self, *args):
        pass


http = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
thread = threading.Thread(target=http.serve_forever, daemon=True)
thread.start()
try:
    common = ["--base-url", f"http://127.0.0.1:{http.server_port}",
              "--token", "fictional-current-parent-token", "--profile", str(OUT / "unused-profile")]
    success_path = OUT / "ordered-syllabi.html"
    result = command(CANDIDATE, "ordered-success", ["export-syllabus", "57", "42", "--out", str(success_path), *common])
    assert result.returncode == 0 and result.stderr == b"", processes[-1]
    report = json.loads(result.stdout)
    assert report["ok"] is True and report["course_ids"] == [57, 42]
    assert report["syllabus_statuses"] == [{"course_id": 57, "status": "supplied"}, {"course_id": 42, "status": "empty"}]
    html = success_path.read_text()
    assert html.index('id="course-57"') < html.index('id="course-42"')
    assert "Bring a notebook." in html and "explicitly empty syllabus" in html
    assert report["output_bytes"] == success_path.stat().st_size
    phase = "late-refusal"
    failure_path = OUT / "must-not-exist.html"
    result = command(CANDIDATE, "late-refusal", ["export-syllabus", "57", "42", "--out", str(failure_path), *common])
    assert result.returncode == 1 and result.stdout == b"" and not failure_path.exists()
    assert json.loads(result.stderr)["ok"] is False
    for kind in ["success", "late-refusal"]:
        group = [r for r in requests if r["phase"] == kind]
        assert [r["path"] for r in group] == ["/api/v1/courses/57", "/api/v1/courses/42"]
        assert all(r["query"] == {"include[]": ["syllabus_body", "term", "total_scores"], "per_page": ["50"]} for r in group)
    assert not (OUT / "unused-profile").exists()
finally:
    http.shutdown()
    http.server_close()
    thread.join(timeout=5)
(OUT / "http-requests.json").write_text(json.dumps(requests, indent=2) + "\n")

before = command(BASE, "parent-help", ["--help"])
after = command(CANDIDATE, "candidate-help", ["--help"])
assert before.returncode == after.returncode == 0 and before.stderr == after.stderr == b""
def inventory(text):
    return re.sub(r"\s+", "", re.search(r"\{([^}]+)\}", text.decode(), re.S)[1]).split(",")
old_names, new_names = inventory(before.stdout), inventory(after.stdout)
assert [n for n in new_names if n != "export-syllabus"] == old_names
assert new_names.count("export-syllabus") == 1
for name in ["announcements", "agenda", "quizzes", "quiz", "export-calendar", "module-progress"]:
    before = command(BASE, "parent-help-" + name, [name, "--help"])
    after = command(CANDIDATE, "candidate-help-" + name, [name, "--help"])
    assert before.returncode == after.returncode == 0
    assert before.stdout == after.stdout and before.stderr == after.stderr == b"", name

manifest = json.loads((ROOT / "inputs/composition-6c4d5d2e-manifest.json").read_text())
for f in manifest["parent_source"]:
    assert hashlib.sha256((BASE / f["path"]).read_bytes()).hexdigest() == f["sha256"]
for f in manifest["contribution"]:
    assert hashlib.sha256((CANDIDATE / f["path"]).read_bytes()).hexdigest() == f["sha256"]
for f in manifest["parent_source"]:
    if f["path"] not in {"README.md", "src/canvaspilot/cli.py"}:
        assert hashlib.sha256((CANDIDATE / f["path"]).read_bytes()).hexdigest() == f["sha256"]
receipt = {
    "parent": manifest["parent"], "parent_tree": manifest["parent_tree"],
    "groups": {"ordered_current_cli_success": "pass", "late_refusal_no_output": "pass",
               "inherited_help_preservation": "pass"},
    "exact_http_requests": len(requests), "preserved_parent_commands": old_names,
    "six_new_or_adjacent_command_help_bodies": "byte-identical",
    "source_after_execution": {"parent_closure": 19, "protected_current_files": 17, "payload": 6, "all_exact": True},
    "processes": processes,
    "scope": "One bounded current-parent CLI composition gate. Does not relabel or repeat prior 76 authored, 29 independent or offline browser cases.",
}
data = (json.dumps(receipt, indent=2) + "\n").encode()
(OUT / "receipt.json").write_bytes(data)
print(json.dumps({"receipt_sha256": hashlib.sha256(data).hexdigest(), "groups": receipt["groups"],
                  "http_requests": len(requests), "commands_preserved": len(old_names), "processes": len(processes)}))
