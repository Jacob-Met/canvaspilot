from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path("/Users/me/Developer/canvaspilot-syllabus-cd1df0f1ee24")
BASE = ROOT / "baseline"
OUT = ROOT / "receiving/baseline"
OUT.mkdir(exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.startswith("CANVAS_")}
env["PYTHONPATH"] = str(BASE / "src")
env["PYTHONDONTWRITEBYTECODE"] = "1"
cases = []
for name, args, expected in [
    ("help", ["--help"], 0),
    ("missing-export", ["export-syllabus", "42", "--out", str(OUT / "syllabi.html")], 2),
]:
    command = [sys.executable, "-m", "canvaspilot.cli", *args]
    result = subprocess.run(command, cwd=BASE, env=env, capture_output=True, timeout=15)
    (OUT / (name + ".stdout")).write_bytes(result.stdout)
    (OUT / (name + ".stderr")).write_bytes(result.stderr)
    assert result.returncode == expected, (name, result.returncode, result.stderr)
    cases.append({"name": name, "argv": command, "exit": result.returncode,
                  "stdout_bytes": len(result.stdout), "stderr_bytes": len(result.stderr)})
assert not (OUT / "syllabi.html").exists()
sys.path.insert(0, str(BASE / "src"))
import httpx
from canvaspilot.api import CanvasAPI
from canvaspilot.client import CanvasClient
html = "<h2>Course plan</h2>\n<p>Read A &amp; B. Office hour: Friday, 14:00.</p>\n<ul><li>Bring the notebook.</li></ul>"
course = {"id": 42, "name": "Synthetic course — field methods",
          "course_code": "FIELD-42", "syllabus_body": html}
fixture = {"routes": {"GET /api/v1/courses/42": course}}
before = json.dumps(fixture, sort_keys=True).encode()
calls = []
def forbid_http(*args, **kwargs):
    raise AssertionError("baseline fixture must not create an HTTP client")
httpx.Client = forbid_http
with CanvasClient(base_url="https://canvas.synthetic.invalid", token="",
                  profile=ROOT / "fixture-profile", fixture=fixture) as client:
    request = client.request
    def observed_request(method, path, **kwargs):
        calls.append({"method": method, "path": path, **kwargs})
        return request(method, path, **kwargs)
    client.request = observed_request
    value = CanvasAPI(client).get_course(42)
assert value == course and value["syllabus_body"] == html
assert calls == [{"method": "GET", "path": "/api/v1/courses/42",
                  "params": {"include[]": ["syllabus_body", "term", "total_scores"]}}]
assert json.dumps(fixture, sort_keys=True).encode() == before
(OUT / "existing-course-reader.json").write_text(json.dumps(
    {"fixture": course, "requests": calls, "result": value,
     "fixture_unchanged": True, "runtime_http_forbidden": True},
    ensure_ascii=False, indent=2) + "\n")
manifest = json.loads((ROOT / "inputs/source-manifest.json").read_text())
for entry in manifest["files"]:
    blob = (BASE / entry["path"]).read_bytes()
    assert hashlib.sha256(blob).hexdigest() == entry["sha256"]
files = [{"path": p.name, "bytes": p.stat().st_size,
          "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
         for p in sorted(OUT.iterdir()) if p.is_file()]
receipt = {"schema": "canvaspilot-syllabus-baseline/1",
           "source_commit": manifest["commit"], "source_tree": manifest["tree"],
           "python": sys.version, "python_executable": sys.executable,
           "cases": cases, "raw_syllabus_reader": "passes unchanged",
           "missing_export": "argparse rejects command before Canvas request or output",
           "output_created": False, "source_files_unchanged": len(manifest["files"]),
           "artifacts": files}
path = OUT / "receipt.json"
path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"baseline": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                  "help_exit": 0, "missing_export_exit": 2, "existing_syllabus_reader": "pass",
                  "source_files_unchanged": len(manifest["files"])}))
