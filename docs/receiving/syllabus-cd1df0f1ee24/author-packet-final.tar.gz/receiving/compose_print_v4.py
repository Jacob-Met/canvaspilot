from pathlib import Path
import hashlib,json,shutil
r=Path('/Users/me/Developer/canvaspilot-syllabus-cd1df0f1ee24')
p=json.loads((r/'inputs/composition-6c4d5d2e-v4.json').read_text())
out=r/'composition-6c4d5d2e-print-v4';shutil.copytree(r/'baseline-6c4d5d2e',out)
files=[]
for f in p['files']:
    b=f['content'].encode();d=out/f['path'];d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
    files.append({'path':f['path'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
old=json.loads((r/'inputs/composition-6c4d5d2e-manifest.json').read_text())
for f in old['parent_source']:
    if f['path'] not in {'README.md','src/canvaspilot/cli.py'}:assert hashlib.sha256((out/f['path']).read_bytes()).hexdigest()==f['sha256']
before=(r/'composition-6c4d5d2e/src/canvaspilot/syllabus_packet.py').read_text()
expected=before.replace('nav,.top-link,.packet-source{display:none}','nav,.top-link,.packet-source,.packet-footer{display:none}').replace('<footer>Saved by CanvasPilot. Only explicit navigation leaves this local reading file.</footer>','<footer class="packet-footer">Saved by CanvasPilot. Only explicit navigation leaves this local reading file.</footer>')
assert expected==(out/'src/canvaspilot/syllabus_packet.py').read_text()
receipt={'parent':p['baseline'],'parent_tree':p['parent_tree'],'component_version':4,'files':files,'protected_current_files_exact':17,'prior_current_cli_receiving':'receiving/current-6c4d5d2e/receipt.json','delta':'Two exact generated-footer presentation substitutions in the module plus one guide sentence; all source, CLI, read, validation, data-download and publication logic otherwise unchanged.'}
b=(json.dumps(receipt,indent=2)+'\n').encode();(r/'inputs/composition-6c4d5d2e-v4-manifest.json').write_bytes(b)
print(json.dumps({'manifest_sha256':hashlib.sha256(b).hexdigest(),'files':files,'free_bytes':shutil.disk_usage(r).free}))
