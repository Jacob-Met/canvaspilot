from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path("/Users/me/Developer/canvaspilot-syllabus-cd1df0f1ee24")
event = {
    "failed_attempt": {
        "stage": "Shell setup, before Python ran",
        "message": "zsh:1: can't create temp file for here document: no space left on device",
        "archive_written": False,
        "effect_on_qualified_source": "None",
    },
    "successor": "Run a small saved native script, preserving all source and original failures.",
}
(ROOT / "receiving/packaging-events.json").write_text(json.dumps(event, indent=2) + "\n")
paths = sorted(p for p in (ROOT / "inputs").glob("*") if p.is_file())
paths += sorted(p for p in (ROOT / "receiving").rglob("*")
                if p.is_file() and "pytest-temp" not in p.parts)
paths.append(ROOT / "OWNERSHIP.txt")
records = []
for path in paths:
    data = path.read_bytes()
    records.append({"path": path.relative_to(ROOT).as_posix(), "bytes": len(data),
                    "sha256": hashlib.sha256(data).hexdigest()})
manifest = (json.dumps({
    "files": records,
    "scope": "Exact author source inputs, all original negative stages, native outputs, v3 author qualification, current-parent bounded receiving and v4 print-only delta. Independent browser/print receiving is a separate packet.",
}, indent=2) + "\n").encode()
archive = ROOT / "author-packet-final.tar.gz"
try:
    with archive.open("xb") as output:
        with gzip.GzipFile(fileobj=output, mode="wb", mtime=0, filename="") as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as tar:
                def add(name, data):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mtime = 0
                    info.mode = 0o644
                    tar.addfile(info, io.BytesIO(data))
                add("MANIFEST.json", manifest)
                for path in paths:
                    add(path.relative_to(ROOT).as_posix(), path.read_bytes())
except OSError:
    if archive.exists():
        archive.unlink()
    raise
with tarfile.open(archive, "r:gz") as tar:
    for record in records:
        data = tar.extractfile(record["path"]).read()
        assert len(data) == record["bytes"] and hashlib.sha256(data).hexdigest() == record["sha256"]
(ROOT / "author-packet-final-manifest.json").write_bytes(manifest)
data = archive.read_bytes()
receipt = {
    "archive": str(archive), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
    "members": len(records) + 1, "all_members_readback_exact": True,
    "manifest_sha256": hashlib.sha256(manifest).hexdigest(),
}
(ROOT / "author-packet-final-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
