# Conversation packet: unchanged-source acquisition and baseline

This is a bounded partial source snapshot of Jacob-Met/canvaspilot commit 92e9f1b500a15dd61d4c74539dedbf880afde30b, tree 13ad8dabadb259983fb568dd35e65f2762f3ee3b. It contains all 25 current runtime/package assets and five selected project/contract/test files (30 source files, 337,343 bytes). It is not a full checkout or canonical Git ancestry.

No feature implementation, source claim, dependency installation, or build occurred. The open issue/PR collection and exact source were read during acquisition. No conversation/export owner was identified in that bounded collection; the ownership receipt is advisory and does not establish a lease.

Two actual unmodified CLI behaviors were received:
- `export-conversation 246 --out NEW_HTML` exits 2 because the command is absent; no request or output file.
- Existing `conversation 246` exits 0 and emits the exact authored nested/Unicode conversation. The unchanged CanvasAPI/CanvasClient token path sends GET /api/v1/conversations/246 with auto_mark_as_read=false and the inherited per_page=50. Its stdout is byte-identical to witness/conversation.json.

The subprocess runner uses HTTPX MockTransport and blocks socket connection/DNS and subprocess audit events. It passes an explicit synthetic token and a private, absent profile path. No browser, broker, real credential, live Canvas/profile, or attachment is accessed. Fixture state and all 30 source files remain unchanged. This is synthetic transport receiving, not real school or server-state receiving.

The first reader receiver incorrectly expected per_page=100. Its original source, raw traceback and recorded request are retained unchanged in witness/run-cli.py, witness/run-baseline.py and results/reader/. Only that receiver assumption was corrected to the source's existing value 50, using separately named corrected drivers/results. The successful missing-command case was not repeated. See evidence/receiver-correction.json.

Useful entry points:
- evidence/source-before.json and evidence/source-after.json: exact Git blob, SHA256, byte and mode pins
- evidence/ownership-source-context.json: source/ownership acquisition context
- evidence/baseline-receipt.json: native interpreter, dependency identities and final two-case outcome
- results/missing-command/: original absence witness
- results/reader/: disqualified receiver assumption attempt
- results/reader-corrected/: successful unchanged conversation reader
- witness/run-cli-corrected.py: successful offline CLI binding
- witness/run-baseline-corrected.py: successful single-reader replay plus original absence verification
- packet-manifest.json: every payload hash before handoff, excluding the manifest itself

The original completed receiver scripts deliberately use exclusive output creation and assert source pins, so invoking them again in the same directory would not overwrite evidence. A future replay must use a fresh output placement and preserve the pinned source.
