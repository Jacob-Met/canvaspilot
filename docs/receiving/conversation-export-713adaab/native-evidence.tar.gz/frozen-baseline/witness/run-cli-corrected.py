"""Execute the actual unmodified CLI under an offline-only synthetic transport."""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parents[1]
MODE = sys.argv[1]
assert MODE in ("missing-command", "reader")
RESULT = ROOT / "results" / ("reader-corrected" if MODE == "reader" else MODE)
assert RESULT.is_dir()
SOURCE = ROOT / "source" / "src"
sys.path.insert(0, str(SOURCE))
requests = []
guard_hits = []
fixture = json.loads((ROOT / "witness" / "conversation.json").read_text())
original = copy.deepcopy(fixture)
def audit(event, args):
    if event in {"socket.connect", "socket.getaddrinfo", "socket.gethostbyname",
                 "subprocess.Popen", "os.system", "os.posix_spawn"}:
        guard_hits.append(event)
        raise RuntimeError("offline witness denied external I/O: " + event)
sys.addaudithook(audit)

import httpx
real_client = httpx.Client
synthetic_token = "synthetic-offline-fixture-not-a-credential"
def handle(request):
    entry = {
        "method": request.method,
        "url": str(request.url),
        "query": list(request.url.params.multi_items()),
        "body_bytes": len(request.content),
        "synthetic_token_propagated": request.headers.get("Authorization") == "Bearer " + synthetic_token,
    }
    requests.append(entry)
    assert MODE == "reader"
    assert request.method == "GET"
    assert request.url.scheme == "https"
    assert request.url.host == "conversation-fixture.invalid"
    assert request.url.path == "/api/v1/conversations/246"
    assert list(request.url.params.multi_items()) == [("auto_mark_as_read", "false"), ("per_page", "50")]
    assert request.content == b""
    assert entry["synthetic_token_propagated"]
    return httpx.Response(200, json=copy.deepcopy(fixture))
class FixtureClient(real_client):
    def __init__(self, *args, **kwargs):
        assert "transport" not in kwargs
        kwargs["transport"] = httpx.MockTransport(handle)
        kwargs["trust_env"] = False
        super().__init__(*args, **kwargs)
httpx.Client = FixtureClient

profile = ROOT / "witness" / "never-created-profile"
output = ROOT / "results" / "never-created.html"
assert not profile.exists()
assert not output.exists()
common = ["--base-url", "https://conversation-fixture.invalid",
          "--profile", str(profile), "--token", synthetic_token]
sys.argv = ["canvaspilot", "export-conversation", "246", "--out", str(output), *common] if MODE == "missing-command" else ["canvaspilot", "conversation", "246", *common]
exit_code = 0
try:
    runpy.run_module("canvaspilot.cli", run_name="__main__", alter_sys=True)
except SystemExit as error:
    exit_code = error.code if isinstance(error.code, int) else 1
    raise
except BaseException:
    exit_code = 97
    raise
finally:
    receipt = {
        "mode": MODE, "exit_code_seen": exit_code, "requests": requests,
        "guard_hits": guard_hits, "fixture_unchanged": fixture == original,
        "profile_path_created": profile.exists(), "output_path_created": output.exists(),
        "source_module": str(SOURCE / "canvaspilot" / "cli.py"),
        "source_sha256": hashlib.sha256((SOURCE / "canvaspilot" / "cli.py").read_bytes()).hexdigest(),
        "limits": "Synthetic transport contract witness only. No live Canvas, broker, browser, profile, attachment fetch, or real server-state receiving."
    }
    with (RESULT / "transport.json").open("x") as stream:
        json.dump(receipt, stream, ensure_ascii=True, indent=2)
        stream.write("\n")
