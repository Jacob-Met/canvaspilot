"""Two bounded unchanged-source baseline witnesses; never installs dependencies."""
from __future__ import annotations
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source"
assert shutil.disk_usage(ROOT).free > 16 * 1024 * 1024
before = json.loads((ROOT / "evidence" / "source-before.json").read_text())
def source_manifest():
    rows = []
    for expected in before["files"]:
        path = SOURCE / expected["path"]
        data = path.read_bytes()
        row = {**expected, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
               "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}
        assert row == expected
        rows.append(row)
    return rows
source_manifest()
fixture_path = ROOT / "witness" / "conversation.json"
fixture = json.loads(fixture_path.read_text())
env = {k: v for k, v in os.environ.items() if not k.startswith("CANVAS_") and k not in ("PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP")}
env.update({"PYTHONDONTWRITEBYTECODE": "1", "CANVAS_PROFILE": str(ROOT / "witness" / "never-created-profile")})
first = json.loads((ROOT / "results" / "missing-command" / "transport.json").read_text())
assert first["exit_code_seen"] == 2 and first["requests"] == [] and first["guard_hits"] == []
assert (ROOT / "results" / "missing-command" / "stdout.txt").read_bytes() == b""
assert b"invalid choice: 'export-conversation'" in (ROOT / "results" / "missing-command" / "stderr.txt").read_bytes()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
cases = [{"mode": "missing-command", "returncode": 2, "request_count": 0, "passed": True, "source": "original preserved run; not repeated"}]
for mode in ("reader",):
    result = ROOT / "results" / "reader-corrected"
    result.mkdir(mode=0o700)
    command = [sys.executable, "-B", str(ROOT / "witness" / "run-cli-corrected.py"), mode]
    run = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=30)
    (result / "stdout.txt").write_bytes(run.stdout)
    (result / "stderr.txt").write_bytes(run.stderr)
    receipt = json.loads((result / "transport.json").read_text())
    assert not receipt["guard_hits"]
    assert receipt["fixture_unchanged"]
    assert not receipt["profile_path_created"]
    assert not receipt["output_path_created"]
    if mode == "missing-command":
        assert run.returncode == 2
        assert run.stdout == b""
        assert b"invalid choice: 'export-conversation'" in run.stderr
        assert receipt["requests"] == []
    else:
        assert run.returncode == 0
        assert json.loads(run.stdout) == fixture
        assert len(receipt["requests"]) == 1
        assert receipt["requests"][0]["query"] == [["auto_mark_as_read", "false"], ["per_page", "50"]]
    cases.append({"mode": mode, "returncode": run.returncode, "request_count": len(receipt["requests"]),
                  "stdout_sha256": hashlib.sha256(run.stdout).hexdigest(),
                  "stderr_sha256": hashlib.sha256(run.stderr).hexdigest(),
                  "transport_sha256": hashlib.sha256((result / "transport.json").read_bytes()).hexdigest(),
                  "passed": True})
after = {"base_commit": before["base_commit"], "base_tree": before["base_tree"], "files": source_manifest()}
with (ROOT / "evidence" / "source-after.json").open("x") as stream:
    json.dump(after, stream, indent=2); stream.write("\n")
report = {
    "schema": 1, "status": "qualified-unchanged-baseline", "started_utc": started,
    "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "base_commit": before["base_commit"], "base_tree": before["base_tree"],
    "python": sys.version, "executable": sys.executable,
    "dependencies": {n: importlib.metadata.version(n) for n in ("httpx", "mcp", "pytest")},
    "source_files_unchanged": len(after["files"]), "cases": cases,
    "fixture_sha256": hashlib.sha256(fixture_path.read_bytes()).hexdigest(),
    "fixture_contract": "Nested Unicode conversation data, message order, attachments as metadata, unknown fields, unread workflow_state preserved exactly in JSON stdout.",
    "network_contract": "Actual unchanged CLI and CanvasAPI/CanvasClient token path with HTTPX MockTransport only. All socket connection/DNS and child-process attempts denied and counted. Explicit synthetic token, private absent profile path; no live state claims.",
    "receiver_correction": "Original reader stopped on receiver-only per_page=100 assertion; source uses its existing default 50. Original raw trace/source retained. Corrected reader uses 50; missing-command not repeated.",
    "scope": "Only two baseline witnesses; no feature edit, no claim, no broad regression replay, no install or build.",
}
with (ROOT / "evidence" / "baseline-receipt.json").open("x") as stream:
    json.dump(report, stream, ensure_ascii=True, indent=2); stream.write("\n")
print(json.dumps(report, ensure_ascii=True))
