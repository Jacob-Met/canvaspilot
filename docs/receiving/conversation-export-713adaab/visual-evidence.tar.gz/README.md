# Local conversation packet visual receiver

This receiver is prepared for one pinned synthetic HTML file from the root-owned CanvasPilot contribution. It has not yet run against candidate HTML. The native direct executable version probe returned Chromium153.0.8010.47. The existing Python environment has no Playwright, Selenium, pyppeteer or websocket package; this driver uses only Python standard-library CDP pipes and installed Chromium/pdfinfo/pdftoppm.

Do not invoke /usr/bin/chromium-browser or /usr/bin/firefox wrappers: their inspected scripts alter desktop launcher settings. The driver names /snap/chromium/3537/usr/lib/chromium-browser/chrome directly and creates a new private user-data directory for every result placement.

Example invocation after root supplies the exact HTML and digest:

```sh
python3 -B /dev/shm/canvaspilot-conversation-visual-713adaab/receive_visual.py \
  --html /ABSOLUTE/PINNED/SYNTHETIC.html \
  --sha256 EXACT_SHA256 \
  --out /dev/shm/canvaspilot-conversation-visual-713adaab/runs/candidate-first
```

The destination must be new and remain inside this receiver namespace. The source file is read and hashed before and after receiving, never edited. Input is capped at16MiB; screenshot/PDF responses and captures also have explicit caps. At least256MiB native free space is required.

The receiver first records static structure, duplicate IDs, fragment targets and print/line-wrapping CSS indicators. Active or nonlocal resource syntax refuses browser launch. The optional browser then uses a new private profile/XDG directories, a pipe-based CDP connection with no debug listening port, disabled background/browser account features, DNS refusal, and explicit CDP offline/URL blocking before navigating to the one local file. Browser-wide netlog and target request events are retained. No existing profile/session is selected; no account or live Canvas URL is opened. Core dumps and crash reporting are disabled only for this child process.

Private user/network namespace creation was unavailable (uid_map: Operation not permitted). No privilege escalation or host-setting change was attempted. There is consequently no claim of OS-wide network isolation. The driver never adds --no-sandbox or retries with a sandbox bypass. A startup or protocol failure records static-only-browser-unavailable, preserves exact raw diagnostics, and stops.

On successful browser receiving it saves desktop/mobile screenshots, measured DOM/body text/overflow, print-media computed layout, actual print PDF, pdfinfo, and a first printed-page image. The screenshot full-height limit is12000px and any truncation is explicit in the receipt. DOM dimensions and captures still require human/assistant image review; browser-captured-review-pending is not a claim of visually approved output. --static-only suppresses browser launch completely.

Direct process dependencies and preliminary source/permission facts are recorded under evidence/. AST parsing and --help were checked; no browser-page run or candidate receiving is included in this preparation packet.

Primary protocol references consulted while preparing the driver:
- https://developer.chrome.com/docs/automation-and-testing/headless
- https://chromedevtools.github.io/devtools-protocol/tot/Network/
- https://chromedevtools.github.io/devtools-protocol/tot/Page/
