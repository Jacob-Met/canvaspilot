"""Bounded visual receiving of one pinned, passive, local conversation packet.

No installation, existing profile/session, server, or live account is used.
The direct installed Chromium executable is optional. Browser startup failure
leaves explicit static-only evidence; it does not trigger a sandbox bypass.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import select
import shutil
import subprocess
import sys
import time
import tempfile
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parent
CHROME = "/snap/chromium/3537/usr/lib/chromium-browser/chrome"


def save_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2)
        stream.write("\n")


class StaticHTML(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.elements = []
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        self.elements.append((tag, dict(attrs)))

    handle_startendtag = handle_starttag


def static_receipt(raw):
    text = raw.decode("utf-8")
    parsed = StaticHTML(text)
    problems = []
    forbidden = {"script", "iframe", "frame", "object", "embed", "img", "audio", "video",
                 "source", "form", "input", "button", "base", "link"}
    ids = [attrs["id"] for _, attrs in parsed.elements if "id" in attrs]
    links = []
    for tag, attrs in parsed.elements:
        if tag in forbidden:
            problems.append("active/remote-capable element: " + tag)
        if any(name.startswith("on") for name in attrs):
            problems.append("event attribute")
        if any(name in attrs for name in ("src", "srcset", "action", "poster", "background")):
            problems.append("resource attribute")
        if "href" in attrs:
            href = attrs["href"]
            if not href.startswith(("#", "data:application/json;base64,")):
                problems.append("nonlocal link")
            if href.startswith("#"):
                links.append({"target": href[1:], "exists": href[1:] in ids})
        if tag == "meta" and attrs.get("http-equiv", "").lower() == "refresh":
            problems.append("meta refresh")
    styles = "\n".join(re.findall(r"<style\b[^>]*>(.*?)</style\s*>", text, re.I | re.S))
    if re.search(r"@import|url\s*\(", styles, re.I):
        problems.append("CSS resource reference")
    return {
        "elements": len(parsed.elements), "duplicate_ids": sorted({i for i in ids if ids.count(i) > 1}),
        "local_links": links, "passive_admission_problems": problems,
        "print_media_present": bool(re.search(r"@media[^{]*\bprint\b", styles, re.I)),
        "page_rule_present": bool(re.search(r"@page\b", styles, re.I)),
        "pre_wrap_rule_present": bool(re.search(r"white-space\s*:\s*pre-wrap", styles, re.I)),
        "overflow_wrap_rule_present": bool(re.search(r"overflow-wrap\s*:", styles, re.I)),
        "inline_style_sha256": hashlib.sha256(styles.encode()).hexdigest(),
        "limits": "Static syntax/structure indicators only; not computed layout or print rendering.",
    }


class Pipe:
    def __init__(self, process, read_fd, write_fd):
        self.process, self.read_fd, self.write_fd = process, read_fd, write_fd
        self.pending = b""
        self.serial = 0
        self.events = []

    def message(self, deadline):
        while b"\0" not in self.pending:
            wait = deadline - time.monotonic()
            if wait <= 0:
                raise TimeoutError("CDP response deadline")
            if not select.select([self.read_fd], [], [], min(wait, 1))[0]:
                if self.process.poll() is not None:
                    raise RuntimeError("Chromium exited before CDP response")
                continue
            data = os.read(self.read_fd, 1024 * 1024)
            if not data:
                raise RuntimeError("Chromium closed CDP pipe")
            self.pending += data
            if len(self.pending) > 48 * 1024 * 1024:
                raise ValueError("CDP response exceeds receiver cap")
        raw, self.pending = self.pending.split(b"\0", 1)
        return json.loads(raw)

    def call(self, method, params=None, session=None, timeout=20):
        self.serial += 1
        message = {"id": self.serial, "method": method, "params": params or {}}
        if session:
            message["sessionId"] = session
        data = json.dumps(message).encode() + b"\0"
        while data:
            data = data[os.write(self.write_fd, data):]
        deadline = time.monotonic() + timeout
        while True:
            result = self.message(deadline)
            if result.get("id") == self.serial:
                if "error" in result:
                    raise RuntimeError(method + ": " + json.dumps(result["error"]))
                return result.get("result", {})
            if "method" in result:
                if len(self.events) >= 3000:
                    raise ValueError("CDP event cap reached")
                self.events.append(result)


MEASURE = """(() => {
const box = e => { const b=e.getBoundingClientRect(); return {x:b.x,y:b.y,width:b.width,height:b.height}; };
const cs = e => { const s=getComputedStyle(e); return {font:s.font,fontSize:s.fontSize,lineHeight:s.lineHeight,
  whiteSpace:s.whiteSpace,overflowWrap:s.overflowWrap,display:s.display,breakInside:s.breakInside}; };
return {url:location.href,title:document.title,readyState:document.readyState,
  viewport:{width:innerWidth,height:innerHeight},document:{width:document.documentElement.scrollWidth,
  height:document.documentElement.scrollHeight},body:box(document.body),
  headings:[...document.querySelectorAll('h1,h2,h3')].map(e=>({text:e.textContent,box:box(e),style:cs(e)})),
  messages:[...document.querySelectorAll('article.message')].map(e=>({text:e.textContent,box:box(e)})),
  bodies:[...document.querySelectorAll('.message-body')].map(e=>({text:e.textContent,box:box(e),style:cs(e)})),
  overflow:[...document.querySelectorAll('main,article,section,dl,dd,pre,.message-body')]
    .filter(e=>e.getBoundingClientRect().right>innerWidth+1||e.getBoundingClientRect().left < -1)
    .map(e=>({tag:e.tagName,classes:e.className,box:box(e)})),
  links:[...document.querySelectorAll('a')].map(e=>({href:e.getAttribute('href')?.startsWith('data:')?'data:JSON':e.getAttribute('href'),box:box(e)})),
  styleRules:[...document.styleSheets].flatMap(s=>[...s.cssRules].filter(r=>r.conditionText?.includes('print')).map(r=>r.cssText))};
})()"""


def browser_receive(html_path, output):
    profile = output / "profile"
    profile.mkdir(mode=0o700)
    env = {key: os.environ[key] for key in ("PATH", "LANG", "LC_ALL") if key in os.environ}
    for key, leaf in (("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache"),
                      ("XDG_DATA_HOME", "data")):
        path = output / leaf
        path.mkdir(mode=0o700)
        env[key] = str(path)
    # Chromium's SingletonSocket lives under TMPDIR and needs a short path.
    # Allocate a new directory exclusively; never reuse another owner's path.
    private_tmp = Path(tempfile.mkdtemp(prefix="cv713-", dir="/dev/shm"))
    env["TMPDIR"] = str(private_tmp)
    save_json(output / "private-tmp.json", {
        "path": str(private_tmp), "uid": private_tmp.stat().st_uid,
        "mode": oct(private_tmp.stat().st_mode & 0o777),
        "created_exclusively": True, "purpose": "This receiver's Chromium temporary socket/files",
    })
    read_child, write_parent = os.pipe()
    read_parent, write_child = os.pipe()
    env["PACKET_CDP_READ"] = str(read_child)
    env["PACKET_CDP_WRITE"] = str(write_child)
    args = [
        CHROME, "--headless", "--disable-gpu", "--remote-debugging-pipe",
        "--user-data-dir=" + str(profile), "--no-first-run", "--no-default-browser-check",
        "--disable-background-networking", "--disable-component-update", "--disable-sync",
        "--disable-extensions", "--disable-default-apps", "--disable-domain-reliability",
        "--disable-breakpad", "--disable-crash-reporter",
        "--metrics-recording-only", "--disk-cache-size=1", "--media-cache-size=1",
        "--host-resolver-rules=MAP * ~NOTFOUND", "--log-net-log=" + str(output / "browser-netlog.json"),
        "about:blank",
    ]
    save_json(output / "browser-command.json", {"argv": args, "private_profile": str(profile),
        "no_sandbox_bypass": True, "no_existing_profile_or_session": True, "private_tmp": str(private_tmp)})
    with (output / "browser.stdout.txt").open("xb") as stdout, (output / "browser.stderr.txt").open("xb") as stderr:
        process = subprocess.Popen([sys.executable, "-B", str(Path(__file__).resolve()), "--exec-browser", *args],
            env=env, cwd=output, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
            pass_fds=(read_child, write_child))
        os.close(read_child)
        os.close(write_child)
        pipe = Pipe(process, read_parent, write_parent)
        report = {}
        try:
            report["version"] = pipe.call("Browser.getVersion")
            target = pipe.call("Target.createTarget", {"url": "about:blank"})["targetId"]
            session = pipe.call("Target.attachToTarget", {"targetId": target, "flatten": True})["sessionId"]
            pipe.call("Page.enable", session=session)
            pipe.call("Network.enable", session=session)
            pipe.call("Network.setCacheDisabled", {"cacheDisabled": True}, session)
            pipe.call("Network.setBypassServiceWorker", {"bypass": True}, session)
            pipe.call("Network.setBlockedURLs", {"urls": ["http://*", "https://*", "ws://*", "wss://*", "ftp://*"]}, session)
            pipe.call("Network.emulateNetworkConditions",
                      {"offline": True, "latency": 0, "downloadThroughput": 0, "uploadThroughput": 0}, session)
            report["offline_before_navigation"] = True
            pipe.call("Page.navigate", {"url": html_path.as_uri()}, session)
            deadline = time.monotonic() + 15
            while True:
                ready = pipe.call("Runtime.evaluate", {"expression": "location.href+'|'+document.readyState", "returnByValue": True}, session)
                if ready["result"].get("value") == html_path.as_uri() + "|complete":
                    break
                if time.monotonic() > deadline:
                    raise TimeoutError("Local document readiness deadline")
                time.sleep(0.1)
            pipe.call("Runtime.evaluate", {"expression": "document.fonts.ready.then(()=>true)",
                      "awaitPromise": True, "returnByValue": True}, session)
            for label, width, height in (("desktop", 1280, 900), ("mobile", 390, 844)):
                pipe.call("Emulation.setDeviceMetricsOverride",
                          {"width": width, "height": height, "deviceScaleFactor": 1, "mobile": False}, session)
                measured = pipe.call("Runtime.evaluate", {"expression": MEASURE, "returnByValue": True}, session)["result"]["value"]
                save_json(output / (label + "-dom-layout.json"), measured)
                metrics = pipe.call("Page.getLayoutMetrics", session=session)["cssContentSize"]
                clip_height = min(12000, metrics["height"])
                png = pipe.call("Page.captureScreenshot", {"format": "png", "captureBeyondViewport": True,
                    "clip": {"x": 0, "y": 0, "width": width, "height": clip_height, "scale": 1}}, session)["data"]
                data = base64.b64decode(png, validate=True)
                if len(data) > 24 * 1024 * 1024:
                    raise ValueError("Screenshot exceeds receiver byte cap")
                (output / (label + ".png")).write_bytes(data)
                report[label] = {"overflow_elements": len(measured["overflow"]), "document_height": metrics["height"],
                                 "capture_height": clip_height, "full_height_captured": clip_height == metrics["height"]}
            pipe.call("Emulation.setDeviceMetricsOverride",
                      {"width": 794, "height": 1123, "deviceScaleFactor": 1, "mobile": False}, session)
            pipe.call("Emulation.setEmulatedMedia", {"media": "print"}, session)
            measured = pipe.call("Runtime.evaluate", {"expression": MEASURE, "returnByValue": True}, session)["result"]["value"]
            save_json(output / "print-dom-layout.json", measured)
            pdf = pipe.call("Page.printToPDF", {"printBackground": True, "preferCSSPageSize": True,
                          "paperWidth": 8.2677, "paperHeight": 11.6929}, session)["data"]
            pdf_data = base64.b64decode(pdf, validate=True)
            if len(pdf_data) > 24 * 1024 * 1024:
                raise ValueError("PDF exceeds receiver byte cap")
            (output / "packet.pdf").write_bytes(pdf_data)
            report["status"] = "browser-captured-review-pending"
            report["visual_review_limit"] = "Screenshots, measured DOM and actual print PDF; a reviewer still must inspect images."
        finally:
            save_json(output / "cdp-events.json", pipe.events)
            try:
                pipe.call("Browser.close", timeout=3)
            except Exception:
                pass
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=3)
            os.close(read_parent)
            os.close(write_parent)
    requests = [x["params"]["request"]["url"] for x in pipe.events if x.get("method") == "Network.requestWillBeSent"]
    report["page_requests"] = requests
    report["page_external_requests"] = [url for url in requests if not url.startswith(("file:", "data:", "about:"))]
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--html", required=True, type=Path)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--static-only", action="store_true")
    args = parser.parse_args()
    source = args.html.resolve(strict=True)
    output = args.out.resolve()
    assert output.is_relative_to(ROOT) and not output.exists()
    assert shutil.disk_usage(ROOT).free > 256 * 1024 * 1024
    assert source.stat().st_size <= 16 * 1024 * 1024
    raw = source.read_bytes()
    assert len(raw) <= 16 * 1024 * 1024 and hashlib.sha256(raw).hexdigest() == args.sha256
    output.mkdir(mode=0o700, parents=True)
    report = {"source_path": str(source), "source_sha256": args.sha256, "source_bytes": len(raw),
              "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "status": "static-only", "static": static_receipt(raw),
              "scope": "One supplied local synthetic artifact; no live account, attachment fetch, browser session, or dependency install."}
    save_json(output / "static-layout.json", report["static"])
    if not args.static_only and not report["static"]["passive_admission_problems"]:
        try:
            report["browser"] = browser_receive(source, output)
            report["status"] = report["browser"]["status"]
        except Exception as error:
            report["browser_failure"] = type(error).__name__ + ": " + str(error)
            report["status"] = "static-only-browser-unavailable"
    elif report["static"]["passive_admission_problems"]:
        report["status"] = "static-only-passivity-refused"
    assert source.read_bytes() == raw
    if (output / "packet.pdf").exists():
        for name, argv in (
            ("pdfinfo", ["/usr/bin/pdfinfo", str(output / "packet.pdf")]),
            ("print-page", ["/usr/bin/pdftoppm", "-f", "1", "-l", "1", "-singlefile", "-scale-to", "1400",
                            "-png", str(output / "packet.pdf"), str(output / "print-page-1")]),
        ):
            run = subprocess.run(argv, capture_output=True, timeout=20, check=False)
            (output / (name + ".stdout.txt")).write_bytes(run.stdout)
            (output / (name + ".stderr.txt")).write_bytes(run.stderr)
            report[name + "_exit"] = run.returncode
    report["source_unchanged"] = True
    report["limitations"] = "Private user/network namespace unavailable; browser uses explicit offline/URL blocking before file navigation and background-network disabling flags. Browser-wide netlog is retained for review. No OS-wide network isolation claim."
    save_json(output / "visual-receipt.json", report)
    files = []
    for path in sorted(output.iterdir()):
        if path.is_file():
            data = path.read_bytes()
            files.append({"path": path.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    save_json(output / "result-manifest.json", {"files": files, "profile_excluded": True})
    print(json.dumps({"status": report["status"], "output": str(output), "source_unchanged": True}))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--exec-browser":
        import resource
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        read_fd, write_fd = int(os.environ.pop("PACKET_CDP_READ")), int(os.environ.pop("PACKET_CDP_WRITE"))
        # Duplicate through fresh descriptors so swapping source descriptors
        # never destroys either pipe endpoint before assigning fd3/fd4.
        rcopy, wcopy = os.dup(read_fd), os.dup(write_fd)
        os.dup2(rcopy, 3, inheritable=True)
        os.dup2(wcopy, 4, inheritable=True)
        for fd in {read_fd, write_fd, rcopy, wcopy} - {3, 4}:
            os.close(fd)
        os.execve(sys.argv[2], sys.argv[2:], os.environ)
    else:
        main()
