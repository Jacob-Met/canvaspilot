"""Long-lived Canvas session broker (headed login; optional --headless after).

Keeps one Playwright persistent context open and serves in-page fetch over
localhost HTTP so CLI/MCP calls do not tear down SSO every time.
"""

from __future__ import annotations

import argparse
import ipaddress
import json
import os
import queue
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlsplit

from canvaspilot.client import default_base_url, default_profile

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = int(os.environ.get("CANVAS_SESSION_PORT", "18765"))


def _assert_loopback_bind(host: str) -> None:
    """Refuse to start the broker unless `host` is loopback-only.

    The broker has no authentication boundary of its own (see issue #5); its
    only network defense is binding 127.0.0.1. A future change that relaxes
    the bind — a ``--host 0.0.0.0`` flag, a constant edit, a hostname that
    resolves outward — would silently expose the unauthenticated /fetch and
    /shutdown endpoints to the network. Fail closed at startup instead.
    """
    candidates: list[str] = []
    try:
        candidates.append(str(ipaddress.ip_address(host.strip())))
    except ValueError:
        # Hostname: resolve and require every resolved address to be loopback.
        try:
            infos = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
        except socket.gaierror:
            raise SystemExit(
                f"broker: cannot resolve bind host {host!r}; refusing to start"
            )
        candidates.extend(info[4][0] for info in infos)
    if not candidates:
        raise SystemExit(
            f"broker: bind host {host!r} resolved to nothing; refusing to start"
        )
    bad = [c for c in candidates if not ipaddress.ip_address(c).is_loopback]
    if bad:
        raise SystemExit(
            f"broker: refusing to bind non-loopback host {host!r} "
            f"(resolves to {', '.join(sorted(set(bad)))}); "
            "the session broker must stay on loopback"
        )


class _BrokerState:
    def __init__(self) -> None:
        self.base_url = default_base_url()
        self.profile = default_profile()
        self.headless = False
        self.read_only = False
        self.jobs: queue.Queue[tuple[dict[str, Any], queue.Queue[dict[str, Any]]]] = queue.Queue()
        self.ready = threading.Event()
        self.page_url = ""
        self.page_title = ""
        self.error: str | None = None


STATE = _BrokerState()


def _provider_origin(url: str) -> str:
    """Normalize a configured or browser HTTP origin without substring matching."""
    try:
        parsed = urlsplit(url)
        port = parsed.port
        if (parsed.scheme not in {"http", "https"} or not parsed.hostname
                or parsed.username is not None or parsed.password is not None):
            raise ValueError()
        host = parsed.hostname
        if ":" in host:
            host = "[" + host + "]"
        if port is not None and port != (443 if parsed.scheme == "https" else 80):
            host += ":" + str(port)
        return parsed.scheme + "://" + host
    except (TypeError, ValueError) as exc:
        raise ValueError("Canvas provider requires a valid HTTP(S) origin") from exc


def _canvas_page(ctx):  # type: ignore[no-untyped-def]
    origin = _provider_origin(STATE.base_url)
    for p in ctx.pages:
        try:
            if _provider_origin(p.url or "") == origin:
                return p
        except ValueError:
            continue
    # Keep login/status pages visible. Fetch separately requires origin agreement.
    return ctx.pages[0] if ctx.pages else ctx.new_page()


def _browser_loop() -> None:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        STATE.error = f"playwright missing: {exc}"
        return

    STATE.profile.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as pw:
        ctx = pw.chromium.launch_persistent_context(
            str(STATE.profile),
            headless=STATE.headless,
            viewport={"width": 1400, "height": 900},
            args=["--disable-popup-blocking", "--disable-blink-features=AutomationControlled"],
        )
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(STATE.base_url, wait_until="domcontentloaded")
        STATE.page_url = page.url
        try:
            STATE.page_title = page.title()
        except Exception:  # noqa: BLE001 — title probe must not fail broker startup
            STATE.page_title = ""
        STATE.ready.set()
        msg = (
            "Headless broker up (reuse logged-in profile). Leave process running."
            if STATE.headless
            else "Log into Canvas in this window. Leave it open. CLI/MCP will use this session."
        )
        print(
            json.dumps(
                {
                    "status": "session_ready",
                    "base_url": STATE.base_url,
                    "profile": str(STATE.profile),
                    "port": DEFAULT_PORT,
                    "headless": STATE.headless,
                    "message": msg,
                    "url": STATE.page_url,
                }
            ),
            flush=True,
        )

        while True:
            try:
                job, reply = STATE.jobs.get(timeout=1.0)
            except queue.Empty:
                # refresh status
                try:
                    p = _canvas_page(ctx)
                    STATE.page_url = p.url
                    STATE.page_title = p.title()
                except Exception:  # noqa: BLE001, S110 — status refresh must never kill the broker loop
                    pass
                continue

            if job.get("op") == "shutdown":
                reply.put({"ok": True, "shutdown": True})
                break

            try:
                result = _run_job(ctx, job)
                reply.put({"ok": True, **result})
            except Exception as exc:  # noqa: BLE001
                reply.put({"ok": False, "error": str(exc)})

        ctx.close()


def _run_job(ctx, job: dict[str, Any]) -> dict[str, Any]:  # type: ignore[no-untyped-def]
    op = job.get("op")
    if op == "status":
        p = _canvas_page(ctx)
        return {
            "url": p.url,
            "title": p.title(),
            "headless": STATE.headless,
            "logged_in": "instructure.com" in p.url and "login.microsoft" not in p.url,
        }

    if op == "fetch":
        method = (job.get("method") or "GET").upper()
        path = job["path"]
        body = job.get("body")
        headers = job.get("headers") or {"Accept": "application/json"}
        page = _canvas_page(ctx)
        origin = _provider_origin(STATE.base_url)
        if _provider_origin(page.url) != origin:
            raise RuntimeError("Canvas provider mismatch: selected browser page is not the configured school")
        if _provider_origin(urljoin(page.url, path)) != origin:
            raise RuntimeError("Canvas provider mismatch: requested URL is outside the configured school")
        parsed = urlsplit(path)
        if parsed.scheme or parsed.netloc:
            path = (parsed.path or "/") + (("?" + parsed.query) if parsed.query else "")

        result = page.evaluate(
            """async ({method, path, headers, body, providerOrigin}) => {
              const origin = providerOrigin || location.origin;
              const target = new URL(path, location.href);
              if (location.origin !== origin || target.origin !== origin) {
                throw new Error('Canvas provider mismatch before fetch');
              }
              const opts = {method, credentials: 'include', headers: headers || {}};
              if (body != null && method !== 'GET' && method !== 'HEAD') {
                if (typeof body === 'string') opts.body = body;
                else {
                  opts.headers = Object.assign({'Content-Type': 'application/json'}, opts.headers);
                  opts.body = JSON.stringify(body);
                }
              }
              const r = await fetch(target.href, opts);
              if (new URL(r.url).origin !== origin || location.origin !== origin) {
                throw new Error('Canvas provider mismatch after fetch');
              }
              const text = await r.text();
              let json = null;
              try { json = JSON.parse(text); } catch (e) {}
              return {status: r.status, json, text: json ? null : text.slice(0, 4000),
                      headers: {link: r.headers.get('link') || ''}};
            }""",
            {"method": method, "path": path, "headers": headers, "body": body,
             "providerOrigin": origin},
        )
        if _provider_origin(page.url) != origin:
            raise RuntimeError("Canvas provider mismatch: browser page changed during fetch")
        return {"response": result}

    raise RuntimeError(f"unknown op: {op}")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def _json(self, code: int, obj: dict[str, Any]) -> None:
        data = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        if self.path.startswith("/health"):
            self._json(
                200,
                {
                    "ok": True,
                    "ready": STATE.ready.is_set(),
                    "url": STATE.page_url,
                    "title": STATE.page_title,
                    "headless": STATE.headless,
                    "read_only": STATE.read_only,
                    "error": STATE.error,
                    "base_url": STATE.base_url,
                    "provider_origin_checks": True,
                    "link_pagination": True,
                },
            )
            return
        if self.path.startswith("/status"):
            self._json(200, _call({"op": "status"}))
            return
        self._json(404, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            job = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            self._json(400, {"ok": False, "error": "bad json"})
            return
        if self.path.startswith("/shutdown"):
            self._json(200, _call({"op": "shutdown"}))
            threading.Thread(target=lambda: (time.sleep(0.3), os._exit(0)), daemon=True).start()
            return
        if self.path.startswith("/fetch"):
            method = str(job.get("method") or "GET").upper()
            if STATE.read_only and method not in ("GET", "HEAD"):
                self._json(
                    403,
                    {
                        "ok": False,
                        "read_only": True,
                        "error": (
                            f"read-only broker: {method} rejected; "
                            "restart without --read-only for write access"
                        ),
                    },
                )
                return
            self._json(200, _call(job if "op" in job else {"op": "fetch", **job}))
            return
        self._json(404, {"ok": False, "error": "not found"})


def _call(job: dict[str, Any], timeout: float = 120.0) -> dict[str, Any]:
    if STATE.error:
        return {"ok": False, "error": STATE.error}
    if not STATE.ready.wait(timeout=60):
        return {"ok": False, "error": "browser not ready"}
    reply: queue.Queue[dict[str, Any]] = queue.Queue()
    STATE.jobs.put((job, reply))
    try:
        return reply.get(timeout=timeout)
    except queue.Empty:
        return {"ok": False, "error": "job timeout"}


def broker_url(port: int | None = None) -> str:
    return f"http://{DEFAULT_HOST}:{port or DEFAULT_PORT}"


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Canvas stay-open session broker")
    parser.add_argument("--base-url", default=None)
    parser.add_argument("--profile", default=None)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run browser headless (use after a headed login into the same profile)",
    )
    parser.add_argument(
        "--read-only",
        action="store_true",
        help="Reject non-GET/HEAD /fetch ops (403); for unattended agent use",
    )
    args = parser.parse_args(argv)
    if args.base_url:
        STATE.base_url = args.base_url.rstrip("/")
        os.environ["CANVAS_BASE_URL"] = STATE.base_url
    if args.profile:
        STATE.profile = Path(args.profile)
    STATE.headless = bool(args.headless)
    STATE.read_only = bool(args.read_only)

    t = threading.Thread(target=_browser_loop, name="canvas-browser", daemon=True)
    t.start()
    if not STATE.ready.wait(timeout=90):
        raise SystemExit(STATE.error or "browser failed to start")

    # The broker's only network defense is its loopback bind; fail closed
    # rather than let a future host change silently expose /fetch and
    # /shutdown to the network.
    _assert_loopback_bind(DEFAULT_HOST)
    server = ThreadingHTTPServer((DEFAULT_HOST, args.port), Handler)
    print(json.dumps({"status": "listening", "url": broker_url(args.port)}), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        _call({"op": "shutdown"})
        server.shutdown()


if __name__ == "__main__":
    main()

