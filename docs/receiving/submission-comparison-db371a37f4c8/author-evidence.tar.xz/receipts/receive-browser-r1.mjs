// Actual offline comparison receiving through installed Chrome for Testing.
// Dependency-free CDP transport adapted from this cohort's qualified TasteTable
// browser-seam.mjs; that file and its dependencies are read-only.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { spawn, execFileSync } from 'node:child_process';

const root = '/Users/me/hamon-canvas-comparison-db371a37f4c8';
const source = path.join(root, 'composition-source');
const evidence = path.join(root, 'author-browser-r1');
const browserPath = '/Users/me/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell';
const transportPath = '/Users/me/hamon-tastetable-r3-db371a37f4c8/browser-seam.mjs';
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const manifestBytes = await fs.readFile(path.join(root, 'composition-source-manifest-r1.json'));
const manifest = JSON.parse(manifestBytes);
const cliReceiptPath = path.join(root, 'focused-http-r2', 'cli-history-1-current.json');
const cliReceiptBytes = await fs.readFile(cliReceiptPath);
const cliReceipt = JSON.parse(cliReceiptBytes);
assert.equal(cliReceipt.exit_code, 0);
const reportPath = cliReceipt.output;
const reportBytes = await fs.readFile(reportPath);
const reportUrl = pathToFileURL(reportPath).href;
const capacity = await fs.statfs(root);
assert.ok(capacity.bavail * capacity.bsize > 256 * 1024 * 1024, '256 MiB headroom before browser');
await fs.mkdir(evidence, { recursive: false });
const downloads = path.join(evidence, 'downloads');
await fs.mkdir(downloads);
const checks = [], artifacts = [], network = [], networkFailures = [], exceptions = [], events = [], inputs = [];
let browser, socket, session, guard, lowSpace = false, failure, exit, version, protocolCommands;
let nextId = 0;
const pending = new Map();
const browserLog = [];
const started = new Date().toISOString();
async function pinSources() {
  const rows = [];
  for (const row of manifest.files) {
    const bytes = await fs.readFile(path.join(source, row.path));
    assert.equal(hash(bytes), row.sha256, 'Exact source: ' + row.path);
    rows.push({ path: row.path, bytes: bytes.length, sha256: hash(bytes) });
  }
  return rows;
}
const before = await pinSources();
const transportBytes = await fs.readFile(transportPath);
const transportHash = hash(transportBytes);
function send(method, params = {}, sessionId) {
  const id = ++nextId;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error('CDP timeout: ' + method));
    }, 20000);
    pending.set(id, { resolve, reject, timer });
    socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
  });
}
async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }, session);
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description ?? result.exceptionDetails.text);
  return result.result.value;
}
async function waitFor(predicate, label) {
  const deadline = Date.now() + 15000;
  while (Date.now() < deadline) {
    if (lowSpace) throw new Error('Owned browser stopped below the 256 MiB floor');
    if (await predicate()) return;
    await delay(70);
  }
  throw new Error('Expected state not reached: ' + label);
}
async function click(selector) {
  await evaluate('(() => {const e=document.querySelector(' + JSON.stringify(selector) + ');'
    + 'if(!e)throw new Error("Missing control");e.scrollIntoView({block:"center",behavior:"instant"});})()');
  let previous, point;
  await waitFor(async () => {
    const current = await evaluate('(() => {const e=document.querySelector(' + JSON.stringify(selector) + ');'
      + 'const r=e.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;'
      + 'const hit=document.elementFromPoint(x,y);return {x,y,hit:Boolean(hit&&(hit===e||e.contains(hit)))};})()');
    const ready = current.hit && previous?.x === current.x && previous?.y === current.y;
    previous = current;
    if (ready) point = { x: current.x, y: current.y };
    return ready;
  }, 'stable click ' + selector);
  inputs.push({ selector, ...previous });
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', button: 'left', clickCount: 1, ...point }, session);
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', button: 'left', clickCount: 1, ...point }, session);
}
function check(description, details = {}) {
  checks.push({ description, passed: true, ...details });
  console.log('PASS ' + description);
}
async function screenshot(name) {
  const result = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false }, session);
  const bytes = Buffer.from(result.data, 'base64');
  await fs.writeFile(path.join(evidence, name), bytes);
  artifacts.push({ path: name, bytes: bytes.length, sha256: hash(bytes) });
}
async function layout() {
  return evaluate('(() => ({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,'
    + 'title:document.title,h1:document.querySelector("h1").textContent,'
    + 'selectors:[...document.querySelectorAll(".selector")].map(e=>e.textContent),'
    + 'activeResources:document.querySelectorAll("script,img,iframe,object,embed,link").length,'
    + 'injected:window.submittedMarkupRan??false,resources:performance.getEntriesByType("resource").map(e=>e.name),'
    + 'text:document.body.innerText,download:document.querySelector("#download-records").href}))()');
}
try {
  version = execFileSync(browserPath, ['--version'], { encoding: 'utf8', timeout: 15000 }).trim();
  const profile = await fs.mkdtemp(path.join(evidence, 'chrome-profile-'));
  browser = spawn(browserPath, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--disable-background-networking', '--disable-component-update', '--disable-sync', '--disable-extensions',
    '--disk-cache-size=1048576', '--media-cache-size=1048576', '--password-store=basic',
    '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0',
    '--user-data-dir=' + profile, 'about:blank',
  ], { stdio: ['ignore', 'ignore', 'pipe'], detached: true });
  browser.once('exit', (code, signal) => { exit = { code, signal }; });
  guard = setInterval(async () => {
    const current = await fs.statfs(root);
    if (current.bavail * current.bsize < 256 * 1024 * 1024) {
      lowSpace = true;
      try { process.kill(-browser.pid, 'SIGTERM'); } catch {}
    }
  }, 2000);
  const endpoint = await new Promise((resolve, reject) => {
    let stderr = '';
    const timer = setTimeout(() => reject(new Error('Browser startup: ' + stderr.slice(-2000))), 20000);
    browser.once('error', error => { clearTimeout(timer); reject(error); });
    browser.once('exit', code => { clearTimeout(timer); reject(new Error('Browser exited before connection: ' + code)); });
    browser.stderr.on('data', bytes => {
      browserLog.push(Buffer.from(bytes));
      stderr += bytes.toString();
      const match = stderr.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);
      if (match) { clearTimeout(timer); resolve(match[1]); }
    });
  });
  const protocolAddress = new URL(endpoint);
  const protocol = await fetch('http://' + protocolAddress.host + '/json/protocol',
    { signal: AbortSignal.timeout(5000) }).then(response => response.json());
  const required = {
    Browser: ['setDownloadBehavior'],
    Page: ['navigate', 'captureScreenshot', 'printToPDF'],
    Input: ['dispatchMouseEvent'],
    Emulation: ['setDeviceMetricsOverride', 'setEmulatedMedia'],
  };
  protocolCommands = {};
  for (const [domainName, names] of Object.entries(required)) {
    const domain = protocol.domains.find(item => item.domain === domainName);
    protocolCommands[domainName] = names.map(name => {
      const command = domain?.commands?.find(item => item.name === name);
      assert.ok(command, 'Installed browser declares ' + domainName + '.' + name);
      return command;
    });
  }
  socket = new WebSocket(endpoint);
  await new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, { once: true });
    socket.addEventListener('error', reject, { once: true });
  });
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) {
      const item = pending.get(message.id);
      pending.delete(message.id);
      clearTimeout(item.timer);
      if (message.error) item.reject(new Error(JSON.stringify(message.error)));
      else item.resolve(message.result);
    }
    if (message.method === 'Network.requestWillBeSent') network.push(message.params.request.url);
    if (message.method === 'Network.loadingFailed') networkFailures.push(message.params);
    if (message.method === 'Runtime.exceptionThrown') exceptions.push(message.params.exceptionDetails);
    if (message.method?.startsWith('Browser.download')) events.push(message);
  });
  await send('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: downloads, eventsEnabled: true });
  const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
  ({ sessionId: session } = await send('Target.attachToTarget', { targetId, flatten: true }));
  for (const domain of ['Runtime', 'Page', 'Network']) await send(domain + '.enable', {}, session);
  await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1100, deviceScaleFactor: 1, mobile: false }, session);
  const navigation = await send('Page.navigate', { url: reportUrl }, session);
  assert.ok(!navigation.errorText, JSON.stringify(navigation));
  await waitFor(() => evaluate('document.readyState==="complete" && Boolean(document.querySelector("#download-records"))'), 'actual offline report loaded');
  const desktop = await layout();
  assert.deepEqual(desktop.selectors, ['history:1', 'current']);
  assert.equal(desktop.h1, 'Revision notebook · 波');
  assert.equal(desktop.activeResources, 0);
  assert.equal(desktop.injected, false);
  assert.deepEqual(desktop.resources, []);
  assert.ok(desktop.scrollWidth <= desktop.width);
  assert.ok(desktop.text.includes('The period is 3 seconds.') && desktop.text.includes('The period is 2 seconds.'));
  assert.ok(desktop.text.includes('Metadata only, in returned order.'));
  check('Actual CLI report opens offline with exact selectors and inert submitted markup', {
    width: desktop.width, scrollWidth: desktop.scrollWidth, resources: desktop.resources,
  });
  await screenshot('desktop-overview.png');
  await evaluate('document.querySelector("#body").scrollIntoView({block:"start",behavior:"instant"})');
  await screenshot('desktop-text.png');
  await click('#download-records');
  await waitFor(() => events.filter(item => item.method === 'Browser.downloadWillBegin').length === 1, 'one actual JSON download begins');
  const begun = events.find(item => item.method === 'Browser.downloadWillBegin').params;
  await waitFor(() => events.some(item => item.method === 'Browser.downloadProgress'
    && item.params.guid === begun.guid && item.params.state === 'completed'), 'JSON file download completes');
  const names = (await fs.readdir(downloads)).filter(name => !name.endsWith('.crdownload'));
  assert.deepEqual(names, ['selected-submission-records.json']);
  const downloaded = await fs.readFile(path.join(downloads, names[0]));
  assert.deepEqual(downloaded, Buffer.from(desktop.download.split(',')[1], 'base64'));
  artifacts.push({ path: 'downloads/' + names[0], bytes: downloaded.length, sha256: hash(downloaded) });
  check('Native pointer click downloads the exact embedded record packet', {
    suggestedFilename: begun.suggestedFilename, bytes: downloaded.length, sha256: hash(downloaded),
  });
  await send('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 1, mobile: false }, session);
  await evaluate('document.querySelector("#body").scrollIntoView({block:"start",behavior:"instant"})');
  const phone = await layout();
  assert.equal(phone.width, 390);
  assert.ok(phone.scrollWidth <= 390);
  await screenshot('phone-text.png');
  await evaluate('document.querySelector("#attachments").scrollIntoView({block:"start",behavior:"instant"})');
  await screenshot('phone-attachments.png');
  await click('#body .source-detail > summary');
  assert.equal(await evaluate('document.querySelector("#body details").open'), true);
  const expanded = await layout();
  assert.ok(expanded.scrollWidth <= 390);
  assert.ok(await evaluate('document.querySelector("#body details").textContent.includes("<script>window.submittedMarkupRan=true</script>")'));
  assert.equal(expanded.injected, false);
  check('390 px text, metadata and opened exact source fit without horizontal overflow', {
    width: phone.width, scrollWidth: phone.scrollWidth, expandedScrollWidth: expanded.scrollWidth,
  });
  await send('Emulation.setDeviceMetricsOverride', { width: 794, height: 1123, deviceScaleFactor: 1, mobile: false }, session);
  await send('Emulation.setEmulatedMedia', { media: 'print' }, session);
  await evaluate('window.scrollTo(0,0)');
  const printState = await evaluate('(() => ({nav:getComputedStyle(document.querySelector("nav")).display,'
    + 'download:getComputedStyle(document.querySelector("#download-records")).display,'
    + 'hero:getComputedStyle(document.querySelector(".hero")).backgroundColor,'
    + 'sourceOpen:document.querySelector("#body details").open}))()');
  assert.equal(printState.nav, 'none');
  assert.equal(printState.download, 'none');
  assert.equal(printState.hero, 'rgb(255, 255, 255)');
  assert.equal(printState.sourceOpen, true);
  await screenshot('print-media.png');
  const pdf = await send('Page.printToPDF', { printBackground: true, preferCSSPageSize: true,
    paperWidth: 8.2677165354, paperHeight: 11.692913386, transferMode: 'ReturnAsBase64' }, session);
  const pdfBytes = Buffer.from(pdf.data, 'base64');
  assert.ok(pdfBytes.subarray(0, 8).toString().startsWith('%PDF-'));
  await fs.writeFile(path.join(evidence, 'comparison-print.pdf'), pdfBytes);
  artifacts.push({ path: 'comparison-print.pdf', bytes: pdfBytes.length, sha256: hash(pdfBytes) });
  check('Print media presents a paper layout and the actual browser produces a PDF', { ...printState, pdfBytes: pdfBytes.length });
  assert.equal(exceptions.length, 0);
  assert.ok(network.every(url => url === reportUrl || url.startsWith('data:application/json;base64,')));
  assert.deepEqual(await fs.readFile(reportPath), reportBytes);
} catch (error) {
  failure = { name: error.name, message: error.message, stack: error.stack };
  console.error(error.stack);
  process.exitCode = 1;
  if (socket && session) {
    try { await screenshot('failure.png'); } catch {}
  }
} finally {
  if (guard) clearInterval(guard);
  if (socket?.readyState === WebSocket.OPEN) {
    try { await send('Browser.close'); } catch {}
    socket.close();
  }
  if (browser && !exit) {
    try { process.kill(-browser.pid, 'SIGTERM'); } catch {}
    const deadline = Date.now() + 5000;
    while (!exit && Date.now() < deadline) await delay(50);
    if (!exit) {
      try { process.kill(-browser.pid, 'SIGKILL'); } catch {}
      await delay(100);
    }
  }
  for (const item of pending.values()) {
    clearTimeout(item.timer);
    item.reject(new Error('Owned browser closed'));
  }
  pending.clear();
  await fs.writeFile(path.join(evidence, 'chromium.log'), Buffer.concat(browserLog));
  const after = await pinSources();
  assert.deepEqual(after, before);
  assert.equal(hash(await fs.readFile(transportPath)), transportHash);
  const receipt = {
    accepted: !failure && !lowSpace && checks.length === 4,
    started, finished: new Date().toISOString(), browser: { executable: browserPath, version, pid: browser?.pid, exit },
    node: process.version, source, manifest_sha256: hash(manifestBytes),
    source_files_unchanged: before.length, report: { path: reportPath, bytes: reportBytes.length, sha256: hash(reportBytes) },
    origin_cli_receipt: { path: cliReceiptPath, sha256: hash(cliReceiptBytes) },
    read_only_transport_reference: { path: transportPath, sha256: transportHash },
    checks, artifacts, inputs, network, networkFailures, exceptions, events, lowSpace, failure,
  };
  await fs.writeFile(path.join(evidence, 'protocol-commands.json'), JSON.stringify(protocolCommands, null, 2) + '\n');
  await fs.writeFile(path.join(evidence, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify({ accepted: receipt.accepted, checks: checks.length,
    source_files_unchanged: before.length, receipt_sha256: hash(Buffer.from(JSON.stringify(receipt, null, 2) + '\n')), browser_exit: exit }));
}
