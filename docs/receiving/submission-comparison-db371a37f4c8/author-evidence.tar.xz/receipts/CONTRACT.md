# CanvasPilot submission comparison — frozen author contract

Canonical main: 0480cbce421bae532e3e909899fc8fb83789e878.
Canonical tree: f9ecaa4311d93cfe3a1fd1c9cc140834e2449341.
Issue: https://github.com/Jacob-Met/canvaspilot/issues/67.
Private exact original: /Users/me/hamon-canvas-comparison-db371a37f4c8/original.
Private candidate: /Users/me/hamon-canvas-comparison-db371a37f4c8/source.
Original source manifest: original-source-manifest.json, SHA-256 8c06a4ad17b92dd84f1df3fd2620a3ca02b4287f827c440f9b087afaf803b31f.

## CLI and record identity

canvaspilot compare-submissions COURSE ASSIGNMENT --before history:1 --after current --out comparison.html

Both selectors and an explicit new output path are required. A selector is exactly current or history:N, where N is a positive decimal index without leading zeroes, into the one-based returned history list. Whitespace, signs, alternative casing, zero and leading zeroes are rejected. An arbitrarily long index is refused as out of range without relying on unbounded integer conversion. Identical selectors are rejected. Two positions whose attempt numbers or complete records happen to match remain selectable. Before and after are user-chosen labels, not a chronology assertion.

Use the existing CanvasAPI.submission_history once after argument/output preflight. Its existing client issues the assignment GET and submissions/self GET with exactly its established include list. Do not alter the reader, API wrapper, authentication, client, pagination, MCP or bundle.

Retain each literal selector and its exact selected JSON record values. Preserve order, duplicates, JSON types, Unicode strings, unknown fields and nested record-local data. Do not infer missing history, sort attempts/timestamps, merge records, or join top-level/current comments or grades to history. Include the normalized assignment summary and returned history count to identify the reading context. The existing reader normalizes missing assignment summary fields to null; the report does not claim it can recover their original key presence.

Validate available non-null assignment/course identity against the requested positive IDs, including selected records when those keys are present. Missing identities remain unknown. Refuse contradictory identities without writing a report. The request is authoritative only about which IDs were requested, not missing Canvas metadata.

## Reading report

Produce one self-contained UTF-8 HTML document with responsive desktop/phone and print CSS. It loads no scripts, remote fonts, images, submitted URLs or attachment resources. Submitted markup and all metadata display as inert text. An explicit local data-URI JSON download preserves both selected records, their selectors, request IDs and assignment/history context. This preserves JSON values rather than original HTTP byte formatting.

Show:
- Both exact selection labels, returned attempt/submitted-at/submission-type metadata and a record-identity explanation.
- Readable body text: HTML parsing preserves text and paragraph/line boundaries, omits executable/style content, and never treats extracted text as exact source bytes. Exact body source remains inspectable.
- Line-level readable-text additions/removals and unchanged context for supported sizes. If readable text matches while source markup differs, explicitly disclose that distinction.
- Exact submitted URL as inert text.
- Returned attachments and media metadata for each selection, retaining order and all returned fields. These are metadata only; no file byte comparison or historical file availability claim.
- The complete exact selected record data remains available even for unknown content types.

Omitted keys, explicit null, empty strings and empty lists have distinct visible labels. Non-string bodies do not receive text highlights. JSON comparison is type-sensitive (false is not numeric zero); arrays keep order. Metadata equality says nothing about file bytes. Do not produce a global semantic-sameness claim or grade calculation.

For bounded work, refuse selected-source JSON above 2 MiB before publication. Readable-text highlighting is bounded to 2,000 lines per side, 250,000 combined characters and 1,000,000 line pairs. Outside the highlight bound, show the complete readable text in both columns and explicitly say highlighting was not computed. Do not truncate text or silently treat uncomputed changes as equal. Literal control characters/surrogates can be escaped for display; exact JSON values remain in the downloadable record packet.

## Output and failures

Preflight an existing target, including a dangling symlink, or missing/non-directory parent before API access. Any valid new filename may be used; .html is recommended. Read/render/validation failures leave no target. Write the complete result to a private temporary file in the same parent and atomically publish with no replacement. A target created concurrently must survive unchanged. Clean the owned temporary path; never replace or unlink another file. Return a structured success line with output path and selections; structured expected errors on stderr and a nonzero exit, with no traceback.

## Native qualification boundary

Use only authored records and explicit loopback HTTP/token/profile. Preserve original help/history output and the actual missing-command witness before edits. Qualify real CLI requests, JSON metadata/record identities, protected output/error paths, duplicate/out-of-order selectors, omitted/null/blank/types, hostile markup/Unicode and the large-text bound. Preserve source hashes around execution. Run the configured native lint/test gate once on the candidate, then only concrete composition gates as needed.

Use a private headless browser to inspect the actual report at desktop, 390 px and print boundaries. Assert no remote resource requests, exact download values, long-content wrapping and escaped submitted markup. Keep original receiver failures alongside any corrected harness. Root independently derives cases from canonical source and this declared contract before inspecting candidate code.
