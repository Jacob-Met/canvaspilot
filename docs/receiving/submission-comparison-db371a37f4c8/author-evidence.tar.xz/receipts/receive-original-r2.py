"""Preserve the actual canonical history output and missing comparison command."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

ROOT = Path("/Users/me/hamon-canvas-comparison-db371a37f4c8")
PYTHON = "/Users/me/canvaspilot-announcements-3dcb83a1/.venv/bin/python"
assert shutil.disk_usage(ROOT).free > 250_000_000, "insufficient native headroom"
OUT = ROOT / "baseline-r2"
OUT.mkdir(exist_ok=False)
fixture = json.loads((ROOT / "authored-fixture.json").read_text())
manifest = json.loads((ROOT / "original-source-manifest.json").read_text())

def verify_source():
    for row in manifest["files"]:
        data = (ROOT / "original" / row["path"]).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row["sha256"], row["path"]

verify_source()
calls = []

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_GET(self):
        url = urlsplit(self.path)
        calls.append({"method": "GET", "path": url.path,
                      "query": parse_qs(url.query, keep_blank_values=True),
                      "authorization": self.headers.get("Authorization")})
        (OUT / "requests.json").write_text(json.dumps(calls, indent=2) + "\n")
        assert self.headers.get("Authorization") == "Bearer canvas-comparison-fixture-token"
        if url.path == "/api/v1/courses/71/assignments/902":
            status, payload = 200, fixture["assignment"]
        elif url.path == "/api/v1/courses/71/assignments/902/submissions/self":
            status, payload = 200, fixture["submission"]
        else:
            status, payload = 404, {"error": "unexpected fixture request"}
        data = json.dumps(payload, ensure_ascii=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def unexpected_write(self):
        calls.append({"method": self.command, "path": self.path})
        self.send_error(405)

    do_POST = do_PUT = do_PATCH = do_DELETE = do_HEAD = unexpected_write

server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
server.daemon_threads = True
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
env = {k: v for k, v in os.environ.items()
       if not k.startswith(("CANVAS_", "CANVASPILOT_"))
       and k not in {"PYTHONPATH", "PYTHONHOME", "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
                    "http_proxy", "https_proxy", "all_proxy"}}
env.update({"PYTHONPATH": str(ROOT / "original" / "src"), "PYTHONNOUSERSITE": "1",
            "PYTHONDONTWRITEBYTECODE": "1", "NO_PROXY": "127.0.0.1,localhost"})
common = ["--base-url", f"http://127.0.0.1:{server.server_port}",
          "--token", "canvas-comparison-fixture-token",
          "--profile", str(OUT / "unused-profile")]
observations = []
try:
    for name, args, expected_code in [
        ("help", ["--help"], 0),
        ("history", ["submission-history", "71", "902", *common], 0),
        ("missing-comparison", ["compare-submissions", "71", "902",
                               "--before", "history:1", "--after", "current",
                               "--out", str(OUT / "must-not-exist.html"), *common], 2),
    ]:
        before = len(calls)
        cmd = [PYTHON, "-B", "-m", "canvaspilot.cli", *args]
        result = subprocess.run(cmd, env=env, cwd=OUT, capture_output=True, text=True, timeout=30)
        (OUT / f"{name}.stdout").write_text(result.stdout)
        (OUT / f"{name}.stderr").write_text(result.stderr)
        observations.append({"name": name, "command": cmd, "exit_code": result.returncode,
                             "requests": calls[before:], "stdout": result.stdout,
                             "stderr": result.stderr})
        (OUT / "observations.json").write_text(json.dumps(observations, ensure_ascii=True, indent=2) + "\n")
        assert result.returncode == expected_code, observations[-1]
        if name == "history":
            parsed = json.loads(result.stdout)
            assert parsed["history"]["records"] == fixture["submission"]["submission_history"]
            assert parsed["history"]["records"][0]["attachments"][0]["id"] == 9007199254740993
            assert [r["attempt"] for r in parsed["history"]["records"]] == [2, 2, 1]
            assert parsed["current_submission"] == {
                k: v for k, v in fixture["submission"].items()
                if k not in {"submission_history", "submission_comments"}
            }
            assert [row["method"] for row in calls[before:]] == ["GET", "GET"]
            assert calls[-1]["query"] == {"include[]": ["submission_history", "submission_comments"], "per_page": ["50"]}
            assert calls[-2]["query"] == {"per_page": ["50"]}
            assert not result.stderr
        else:
            assert len(calls) == before
    assert not (OUT / "must-not-exist.html").exists()
    assert not (OUT / "unused-profile").exists()
    verify_source()
    receipt = {"accepted": True, "canonical_parent": manifest["canonical_parent"],
               "source_files_unchanged": len(manifest["files"]),
               "fixture_sha256": hashlib.sha256((ROOT / "authored-fixture.json").read_bytes()).hexdigest(),
               "observations": observations, "requests": calls,
               "missing_command_product_control_exit": 2,
               "history_reader_preserved_exact_returned_records": True,
               "disk_free": shutil.disk_usage(ROOT).free}
    (OUT / "receipt.json").write_text(json.dumps(receipt, ensure_ascii=True, indent=2) + "\n")
    print(json.dumps({"accepted": True, "observations": len(observations),
                      "actual_http_requests": len(calls),
                      "source_files_unchanged": len(manifest["files"]),
                      "receipt_sha256": hashlib.sha256((OUT / "receipt.json").read_bytes()).hexdigest(),
                      "disk_free": receipt["disk_free"]}))
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=3)
