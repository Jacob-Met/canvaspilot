"""Full configured pytest gate and native decoding of the actual browser download."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT=Path("/Users/me/hamon-canvas-comparison-db371a37f4c8")
SOURCE=ROOT/"composition-source"
PYTHON="/Users/me/canvaspilot-announcements-3dcb83a1/.venv/bin/python"
assert shutil.disk_usage(ROOT).free > 250_000_000, "insufficient native headroom"
manifest=json.loads((ROOT/"composition-source-manifest-r1.json").read_text())
def verify():
 for row in manifest["files"]:
  assert hashlib.sha256((SOURCE/row["path"]).read_bytes()).hexdigest()==row["sha256"],row["path"]
verify()
download_path=ROOT/"author-browser-r1/downloads/selected-submission-records.json"
packet=json.loads(download_path.read_text())
fixture=json.loads((ROOT/"authored-fixture.json").read_text())
expected_current={k:v for k,v in fixture["submission"].items() if k not in {"submission_history","submission_comments"}}
assert packet["before"]=={"selector":"history:1","record":fixture["submission"]["submission_history"][0]}
assert packet["after"]=={"selector":"current","record":expected_current}
assert packet["assignment"]==fixture["assignment"]
assert packet["request"]=={"course_id":"71","assignment_id":"902"}
assert packet["history"]=={"returned":True,"record_count":3}
assert type(packet["after"]["record"]["attachments"][0]["id"]) is int
assert packet["after"]["record"]["attachments"][0]["id"]==9007199254740993
assert packet["after"]["record"]["future_field"]["enabled"] is False
assert type(packet["after"]["record"]["future_field"]["count"]) is int
browser=json.loads((ROOT/"author-browser-r1/receipt.json").read_text())
assert browser["accepted"] is True and browser["source_files_unchanged"]==86
validation={"accepted":True,"download":str(download_path),"download_sha256":hashlib.sha256(download_path.read_bytes()).hexdigest(),"fixture_sha256":hashlib.sha256((ROOT/"authored-fixture.json").read_bytes()).hexdigest(),"exact_selected_json_values":True,"integer_above_javascript_safe_range":9007199254740993,"json_decoded_by":"native Python, avoiding JavaScript numeric coercion","visual_review":"Author inspected all five browser screenshots: desktop context and changes, 390 px text and attachment metadata, and print-media layout. No clipping or source execution found. Actual PDF was generated; individual PDF pages were not separately raster-inspected."}
(ROOT/"browser-records-and-visual-validation.json").write_text(json.dumps(validation,ensure_ascii=True,indent=2)+"\n")
env={k:v for k,v in os.environ.items() if not k.startswith(("CANVAS_","CANVASPILOT_")) and k not in {"PYTHONPATH","PYTHONHOME","HTTP_PROXY","HTTPS_PROXY","ALL_PROXY","http_proxy","https_proxy","all_proxy"}}
env.update({"PYTHONPATH":str(SOURCE/"src"),"PYTHONNOUSERSITE":"1","PYTHONDONTWRITEBYTECODE":"1","NO_PROXY":"127.0.0.1,localhost","CANVAS_COMPARISON_RECEIPTS_DIR":str(ROOT/"full-http-r1")})
out=ROOT/"full-pytest-r1"
assert not out.exists()
command=[PYTHON,"-B","-m","pytest","-q","-p","no:cacheprovider","--basetemp",str(out)]
started=time.monotonic()
result=subprocess.run(command,cwd=SOURCE,env=env,capture_output=True,timeout=300)
log=result.stdout+result.stderr
(ROOT/"full-tests-r1.log").write_bytes(log)
verify()
receipt={"command":command,"cwd":str(SOURCE),"exit_code":result.returncode,"elapsed_seconds":time.monotonic()-started,"log_sha256":hashlib.sha256(log).hexdigest(),"source_files_unchanged":len(manifest["files"]),"canonical_parent":manifest["canonical_parent"],"ruff_passed_on_exact_same_source":"ruff-r2.log","browser_passed_on_exact_same_source":"author-browser-r1/receipt.json","source_manifest_sha256":hashlib.sha256((ROOT/"composition-source-manifest-r1.json").read_bytes()).hexdigest(),"disk_free":shutil.disk_usage(ROOT).free}
(ROOT/"full-qualification-r1.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt))
print(log.decode("utf-8",errors="replace"))
