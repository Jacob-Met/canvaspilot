"""Seal exact author inputs/outputs; exclude only disposable native caches."""
import base64
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT=Path("/Users/me/hamon-canvas-comparison-db371a37f4c8")
assert shutil.disk_usage(ROOT).free > 256 * 1024 * 1024, "insufficient native headroom"
context=json.loads((ROOT/"sealing-context.json").read_text())
source=ROOT/"composition-source"
manifest=json.loads((ROOT/"composition-source-manifest-r1.json").read_text())
for row in manifest["files"]:
 assert hashlib.sha256((source/row["path"]).read_bytes()).hexdigest()==row["sha256"],row["path"]
commands=[]
for cmd in [
 ["git","-C",str(source),"add","--",*[row["path"] for row in context["contribution_hashes"]]],
 ["git","-C",str(source),"-c","user.name=HAMON Estate","-c","user.email=hamon-estate@users.noreply.github.com","commit","-m","Add explicit submitted-record comparison and offline reading report"]
]:
 result=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
 commands.append({"command":cmd,"exit_code":result.returncode,"stdout":result.stdout,"stderr":result.stderr})
 assert result.returncode==0,commands[-1]
private_commit=subprocess.check_output(["git","-C",str(source),"rev-parse","HEAD"],text=True).strip()
(ROOT/"native-candidate-commit.json").write_text(json.dumps({"private_commit":private_commit,"private_commit_is_canonical_ancestry":False,"canonical_parent":context["current_parent"],"commands":commands},indent=2)+"\n")
members={}
def add(name,path):
 assert name not in members and not name.startswith("/") and ".." not in Path(name).parts,name
 p=Path(path)
 assert p.is_file() and not p.is_symlink(),str(p)
 members[name]=p.read_bytes()
for name in [
 "AUTHOR.md","CONTRACT.md","admission-inputs.json","materialization-r1.json",
 "source-admission-completion.json","original-source-manifest.json",
 "source-patch-transcript-r1.json","product-patch-r1.json","lint-correction-r1.json",
 "lint-correction-receipt.json","composition-receipt-r1.json",
 "composition-original-manifest.json","composition-source-manifest-r1.json",
 "composition-inputs-r1.json","current-canonical-files.json","inherited-source-delta.json",
 "candidate-inputs-r1.json","composition-inputs-qualified-r2.json",
 "candidate-import.log","composition-import-r2.log","ruff-r1.log","ruff-r2.log",
 "focused-qualification-r1.json","focused-qualification-r2.json","focused-tests-r2.log",
 "full-qualification-r1.json","full-tests-r1.log","full-native-environment-triage.json",
 "browser-records-and-visual-validation.json","authored-fixture.json",
 "baseline-harness-correction.json","receive-original.py","receive-original-r2.py",
 "qualify-focused-r1.py","qualify-focused-r2.py","qualify-full-r1.py",
 "receive-browser-r1.mjs","compose-r1.py","native-candidate-commit.json",
 "seal-author-evidence.py","seal-author-evidence-r2.py","archive-admission-r1.json",
]:
 add("receipts/"+name,ROOT/name)
for directory in ["baseline","baseline-r2","focused-http-r2","full-http-r1","lint-r1-inputs"]:
 for p in sorted((ROOT/directory).rglob("*")):
  if p.is_file() and not p.is_symlink():
   add("receipts/"+str(p.relative_to(ROOT)),p)
for directory,manifest_name in [
 ("original","original-source-manifest.json"),
 ("composition-original","composition-original-manifest.json"),
 ("composition-source","composition-source-manifest-r1.json"),
]:
 source_manifest=json.loads((ROOT/manifest_name).read_text())
 for row in source_manifest["files"]:
  p=ROOT/directory/row["path"]
  assert hashlib.sha256(p.read_bytes()).hexdigest()==row["sha256"],str(p)
  add("native-source/"+directory+"/"+row["path"],p)
for p in sorted((ROOT/"author-browser-r1").rglob("*")):
 if any(part.startswith("chrome-profile-") for part in p.parts):
  continue
 if p.is_file() and not p.is_symlink():
  add("browser/"+str(p.relative_to(ROOT/"author-browser-r1")),p)
origins=[]
for before,after in [("history:1","current"),("history:2","history:1"),("history:3","history:2"),("current","history:1")]:
 receipt_path=ROOT/"focused-http-r2"/("cli-"+before.replace(":","-")+"-"+after.replace(":","-")+".json")
 receipt=json.loads(receipt_path.read_text())
 assert receipt["exit_code"]==0
 archive_name="reports/"+before.replace(":","-")+"-"+after.replace(":","-")+".html"
 add(archive_name,receipt["output"])
 origins.append({"path":archive_name,"native_origin":receipt["output"],"cli_receipt":str(receipt_path),"sha256":hashlib.sha256(members[archive_name]).hexdigest()})
members["report-origins.json"]=(json.dumps(origins,indent=2)+"\n").encode()
members["source-context.json"]=(json.dumps({k:v for k,v in context.items() if k!="author_note"},indent=2)+"\n").encode()
rows=[{"path":name,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()} for name,data in sorted(members.items())]
packet_manifest={"format":"canvaspilot.author-evidence.v1","canonical_parent":context["current_parent"],"canonical_tree":context["current_commit"]["tree"]["sha"],"files":rows}
manifest_bytes=(json.dumps(packet_manifest,indent=2)+"\n").encode()
manifest_name="author-evidence.manifest.json"
assert manifest_name not in members
archive=ROOT/"author-evidence.tar.xz"
assert not archive.exists()
with tarfile.open(archive,"w:xz",preset=6) as tar:
 for name,data in [*sorted(members.items()),(manifest_name,manifest_bytes)]:
  info=tarfile.TarInfo(name)
  info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0
  tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,"r:xz") as tar:
 assert len(tar.getmembers())==len(rows)+1
 assert tar.extractfile(manifest_name).read()==manifest_bytes
 for row in rows:
  b=tar.extractfile(row["path"]).read()
  assert len(b)==row["bytes"] and hashlib.sha256(b).hexdigest()==row["sha256"],row["path"]
(ROOT/manifest_name).write_bytes(manifest_bytes)
data=archive.read_bytes()
encoded=base64.b64encode(data).decode("ascii")
(ROOT/"author-evidence.base64.txt").write_text(encoded+"\n")
receipt={"archive":str(archive),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+bytes([0])+data).hexdigest(),"members":len(rows)+1,"uncompressed_member_bytes":sum(row["bytes"] for row in rows)+len(manifest_bytes),"manifest_sha256":hashlib.sha256(manifest_bytes).hexdigest(),"verified_extraction_members":len(rows)+1,"base64_characters":len(encoded),"private_source_commit":private_commit,"disk_free":shutil.disk_usage(ROOT).free}
(ROOT/"author-evidence-seal.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt))
