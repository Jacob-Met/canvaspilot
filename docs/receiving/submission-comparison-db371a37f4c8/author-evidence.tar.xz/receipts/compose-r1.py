"""Compose only the seven reserved paths over a newly read actual main."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT=Path("/Users/me/hamon-canvas-comparison-db371a37f4c8")
assert shutil.disk_usage(ROOT).free > 250_000_000, "insufficient native headroom"
inputs=json.loads((ROOT/"composition-inputs-r1.json").read_text())
current=json.loads((ROOT/"current-canonical-files.json").read_text())
correction=json.loads((ROOT/"lint-correction-r1.json").read_text())
original=ROOT/"original"
source=ROOT/"source"
fixes=[]
for name,content in correction.items():
 p=source/name; before=p.read_bytes()
 preserve=ROOT/"lint-r1-inputs"/name
 preserve.parent.mkdir(parents=True,exist_ok=True)
 preserve.write_bytes(before)
 after=content.encode("utf-8")
 p.write_bytes(after)
 fixes.append({"path":name,"before_sha256":hashlib.sha256(before).hexdigest(),"after_sha256":hashlib.sha256(after).hexdigest()})
(ROOT/"lint-correction-receipt.json").write_text(json.dumps({
 "first_gate":"ruff-r1.log","focused_tests_executed_before_correction":False,
 "changes":"Import ordering in the three new Python files; TypeError for malformed assignment-summary type; no lint rule disabled.",
 "source_inputs_preserved":"lint-r1-inputs/","files":fixes
},indent=2)+"\n")
base=ROOT/"composition-original"
assert not base.exists()
shutil.copytree(original,base)
for name,row in current.items():
 p=base/name; p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(row["content"],encoding="utf-8")
 p.chmod(int(row["mode"][-3:],8))
base_rows=[]
for row in inputs["files"]:
 p=base/row["path"]; b=p.read_bytes()
 blob=hashlib.sha1(b"blob "+str(len(b)).encode()+bytes([0])+b).hexdigest()
 assert blob==row["sha"] and len(b)==row["size"],row["path"]
 base_rows.append({**row,"sha256":hashlib.sha256(b).hexdigest()})
(ROOT/"composition-original-manifest.json").write_text(json.dumps({
 "canonical_parent":inputs["canonical_parent"],"canonical_tree":inputs["canonical_tree"],"files":base_rows
},indent=2)+"\n")
composed=ROOT/"composition-source"
assert not composed.exists()
shutil.copytree(base,composed)
logs=[]
for cmd in [
 ["git","init","--initial-branch=canonical-snapshot",str(composed)],
 ["git","-C",str(composed),"add","."],
 ["git","-C",str(composed),"-c","user.name=HAMON Estate","-c","user.email=hamon-estate@users.noreply.github.com","commit","-m","Capture exact CanvasPilot 6c4d5d2e thin native source"],
 ["git","-C",str(composed),"checkout","-b","estate-db371a37f4c8/submission-comparison"]
]:
 result=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
 logs.append({"command":cmd,"exit_code":result.returncode,"stdout":result.stdout,"stderr":result.stderr})
 assert result.returncode==0,logs[-1]
private_commit=subprocess.check_output(["git","-C",str(composed),"rev-parse","HEAD"],text=True).strip()
for name,content in inputs["packet"].items():
 p=composed/name; p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(content,encoding="utf-8")
 p.chmod(0o644)
for row in base_rows:
 if row["path"] not in inputs["packet"]:
  assert hashlib.sha256((composed/row["path"]).read_bytes()).hexdigest()==row["sha256"],row["path"]
# Removing our two exact spans must recover the current canonical CLI verbatim.
cli=(composed/"src/canvaspilot/cli.py").read_text()
assert cli.count(inputs["parser_addition"])==cli.count(inputs["dispatch_addition"])==1
assert cli.replace(inputs["parser_addition"],"").replace(inputs["dispatch_addition"],"")==(base/"src/canvaspilot/cli.py").read_text()
deltas={}
for name in ("src/canvaspilot/api.py","src/canvaspilot/cli.py","README.md"):
 deltas[name]="".join(difflib.unified_diff((original/name).read_text().splitlines(keepends=True),(base/name).read_text().splitlines(keepends=True),fromfile="0480cbce/"+name,tofile="6c4d5d2e/"+name))
(ROOT/"inherited-source-delta.json").write_text(json.dumps(deltas,indent=2)+"\n")
rows=[]
for p in sorted(composed.rglob("*")):
 if p.is_file() and ".git" not in p.parts:
  b=p.read_bytes()
  rows.append({"path":str(p.relative_to(composed)),"mode":"100644","bytes":len(b),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+bytes([0])+b).hexdigest(),"sha256":hashlib.sha256(b).hexdigest()})
manifest={"canonical_parent":inputs["canonical_parent"],"canonical_tree":inputs["canonical_tree"],"files":rows,"source":str(composed)}
(ROOT/"composition-source-manifest-r1.json").write_text(json.dumps(manifest,indent=2)+"\n")
receipt={"canonical_parent":inputs["canonical_parent"],"canonical_tree":inputs["canonical_tree"],"canonical_source_files":len(base_rows),"candidate_source_files":len(rows),"inherited_files_unchanged":len(base_rows)-2,"contribution_paths":list(inputs["packet"]),"private_snapshot_commit":private_commit,"private_commit_is_canonical_ancestry":False,"git_commands":logs,"cli_exact_additive_proof":True,"disk_free":shutil.disk_usage(ROOT).free}
(ROOT/"composition-receipt-r1.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({key:value for key,value in receipt.items() if key!="git_commands"}))
print(deltas["src/canvaspilot/api.py"])
print(deltas["src/canvaspilot/cli.py"])
