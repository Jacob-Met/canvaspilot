"""Run bounded project-native qualification without changing shared dependencies."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path("/Users/me/hamon-canvas-comparison-db371a37f4c8")
SOURCE = ROOT / "source"
PYTHON = "/Users/me/canvaspilot-announcements-3dcb83a1/.venv/bin/python"
assert shutil.disk_usage(ROOT).free > 250_000_000, "insufficient native headroom"
env = {key: value for key, value in os.environ.items()
       if not key.startswith(("CANVAS_", "CANVASPILOT_"))
       and key not in {"PYTHONPATH", "PYTHONHOME", "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
                      "http_proxy", "https_proxy", "all_proxy"}}
env.update({"PYTHONPATH": str(SOURCE / "src"), "PYTHONNOUSERSITE": "1",
            "PYTHONDONTWRITEBYTECODE": "1", "NO_PROXY": "127.0.0.1,localhost",
            "CANVAS_COMPARISON_RECEIPTS_DIR": str(ROOT / "focused-http-r1")})

def hashes():
    return {str(path.relative_to(SOURCE)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in SOURCE.rglob("*") if path.is_file() and ".git" not in path.parts}

before = hashes()
results = []
for name, command, timeout in [
    ("candidate-import", [PYTHON, "-B", "-c",
      "import canvaspilot,json,sys; print(json.dumps({'python':sys.version,'module':canvaspilot.__file__})); "
      f"assert canvaspilot.__file__.startswith({str(SOURCE / 'src')!r})"], 30),
    ("ruff-r1", [PYTHON, "-B", "-m", "ruff", "check", "src", "tests", "scripts", "--no-cache"], 60),
    ("focused-tests-r1", [PYTHON, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider",
     "tests/test_submission_comparison.py", "tests/test_submission_comparison_process.py",
     "--basetemp", str(ROOT / "focused-pytest-r1")], 180),
]:
    started = time.monotonic()
    completed = subprocess.run(command, cwd=SOURCE, env=env, capture_output=True, timeout=timeout)
    (ROOT / f"{name}.log").write_bytes(completed.stdout + completed.stderr)
    receipt = {"name": name, "command": command, "cwd": str(SOURCE),
               "exit_code": completed.returncode, "elapsed_seconds": time.monotonic() - started,
               "log_sha256": hashlib.sha256(completed.stdout + completed.stderr).hexdigest()}
    results.append(receipt)
    (ROOT / "focused-qualification-r1.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(receipt), flush=True)
    if completed.returncode:
        print((completed.stdout + completed.stderr).decode("utf-8", errors="replace"), flush=True)
        break
after = hashes()
assert before == after, "source changed during qualification"
(ROOT / "candidate-inputs-r1.json").write_text(json.dumps({
    "source": str(SOURCE), "files": before, "source_unchanged": True,
    "results": results, "disk_free": shutil.disk_usage(ROOT).free,
}, indent=2) + "\n")
print(json.dumps({"source_files_unchanged": len(before), "disk_free": shutil.disk_usage(ROOT).free}), flush=True)
