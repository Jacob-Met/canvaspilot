import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root='/home/jacob/snap/chromium/common/hamon-canvas-comparison-root-db371a37f4c8';
const evidence=path.join(root,'browser-r1');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const transferBytes=await fs.readFile(path.join(root,'input-transfer.json'));
const transfer=JSON.parse(transferBytes);
const inputs=[];
for(const row of transfer.files){
 const data=Buffer.from(row.base64,'base64'); assert.equal(data.length,row.bytes);assert.equal(hash(data),row.sha256);
 const output=path.join(root,'inputs',row.path);await fs.mkdir(path.dirname(output),{recursive:true});await fs.writeFile(output,data,{flag:'wx'});
 inputs.push({path:row.path,bytes:data.length,sha256:hash(data)});
}
const space=await fs.statfs(root);
assert.ok(space.bavail*space.bsize>256*1024*1024,'256 MiB floor before browser');
await fs.mkdir(evidence);
const profile=path.join(evidence,'profile');await fs.mkdir(profile);
const receipt={started_at:new Date().toISOString(),node:process.version,browser_executable:'/snap/bin/chromium',receiver_sha256:hash(await fs.readFile(new URL(import.meta.url))),input_transfer_sha256:hash(transferBytes),inputs,free_bytes_before:space.bavail*space.bsize,groups:[],artifacts:[],network:[],network_failures:[],exceptions:[],downloads:[],commands:[]};
let browser,ws,session,browserExit,expectedClose=false,failure;
let nextId=0;
const pending=new Map();
const stderr=[],stdout=[];
const browserExitPromise=new Promise(resolve=>{
 const args=['--headless=new','--no-sandbox','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'];
 receipt.browser_argv=args;
 browser=spawn('/snap/bin/chromium',args,{stdio:['ignore','pipe','pipe'],detached:true});
 receipt.browser_pid=browser.pid;
 browser.stdout.on('data',b=>stdout.push(b));browser.stderr.on('data',b=>stderr.push(b));
 browser.on('error',error=>{browserExit={error:String(error)};resolve(browserExit);});
 browser.on('exit',(code,signal)=>{browserExit={code,signal};resolve(browserExit);});
});
function send(method,params={},sid){
 receipt.commands.push({method,time:new Date().toISOString()});
 const id=++nextId;
 return new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>{pending.delete(id);reject(new Error('CDP timeout '+method));},15000);
  pending.set(id,{resolve,reject,timer});
  ws.send(JSON.stringify({id,method,params,...(sid?{sessionId:sid}:{})}));
 });
}
async function evaluate(expression){
 const response=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},session);
 if(response.exceptionDetails)throw new Error(response.exceptionDetails.exception?.description??response.exceptionDetails.text);
 return response.result.value;
}
async function waitFor(test,label,timeout=15000){
 const end=Date.now()+timeout;
 while(Date.now()<end){if(await test())return;if(browserExit&&!expectedClose)throw new Error('Browser exited before '+label);await delay(50);}
 throw new Error('Timeout '+label);
}
async function settle(){await evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');}
async function screenshot(name){
 await settle();
 const result=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false,fromSurface:true},session);
 const data=Buffer.from(result.data,'base64'),p=path.join(evidence,name+'.png');await fs.writeFile(p,data,{flag:'wx'});
 receipt.artifacts.push({path:p,bytes:data.length,sha256:hash(data)});
}
async function metrics(width,height){
 await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false},session);
}
async function noOverflow(label){
 const box=await evaluate('({viewport:innerWidth,width:document.documentElement.scrollWidth,body:document.body.scrollWidth})');
 assert.ok(box.width<=box.viewport+1&&box.body<=box.viewport+1,label+' horizontal overflow '+JSON.stringify(box));
 return box;
}
async function download(name){
 const destination=path.join(evidence,'downloads-'+name);await fs.mkdir(destination);
 await send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:destination,eventsEnabled:true});
 await evaluate('window.scrollTo(0,0)');await settle();
 const box=await evaluate('(()=>{let r=document.querySelector("#download-records").getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2,w:r.width,h:r.height}})()');
 assert.ok(box.w>0&&box.h>0&&box.y>0);
 const previous=receipt.downloads.length;
 await send('Input.dispatchMouseEvent',{type:'mouseMoved',x:box.x,y:box.y},session);
 await send('Input.dispatchMouseEvent',{type:'mousePressed',x:box.x,y:box.y,button:'left',clickCount:1},session);
 await send('Input.dispatchMouseEvent',{type:'mouseReleased',x:box.x,y:box.y,button:'left',clickCount:1},session);
 let begin;
 await waitFor(async()=>{begin=receipt.downloads.slice(previous).find(x=>x.method==='Browser.downloadWillBegin');return Boolean(begin);},name+' download start');
 assert.equal(begin.params.suggestedFilename,'selected-submission-records.json');
 await waitFor(async()=>receipt.downloads.some(x=>x.method==='Browser.downloadProgress'&&x.params.guid===begin.params.guid&&x.params.state==='completed'),name+' download complete');
 const p=path.join(destination,begin.params.suggestedFilename);
 await waitFor(async()=>{try{await fs.access(p);return true;}catch{return false;}},name+' download file');
 const actual=await fs.readFile(p),expected=await fs.readFile(path.join(root,'inputs','cli-r1',name,'embedded-selected-records.json'));
 assert.ok(actual.equals(expected),'Actual pointer download must retain exact original JSON bytes '+name);
 const result={path:p,bytes:actual.length,sha256:hash(actual),suggested_filename:begin.params.suggestedFilename,guid:begin.params.guid,exact_native_packet:true};
 receipt.artifacts.push(result);return result;
}
try{
 let portFile;
 await waitFor(async()=>{try{portFile=await fs.readFile(path.join(profile,'DevToolsActivePort'),'utf8');return portFile.trim().split('\n').length>=2;}catch{return false;}},'DevTools port');
 const [port,endpoint]=portFile.trim().split('\n');
 ws=new WebSocket('ws://127.0.0.1:'+port+endpoint);
 await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
 ws.addEventListener('message',event=>{
  const msg=JSON.parse(event.data);
  if(msg.id){const job=pending.get(msg.id);if(job){clearTimeout(job.timer);pending.delete(msg.id);if(msg.error)job.reject(new Error(JSON.stringify(msg.error)));else job.resolve(msg.result??{});}return;}
  if(msg.method==='Network.requestWillBeSent')receipt.network.push({url:msg.params.request.url,method:msg.params.request.method,type:msg.params.type});
  if(msg.method==='Network.loadingFailed')receipt.network_failures.push(msg.params);
  if(msg.method==='Runtime.exceptionThrown')receipt.exceptions.push(msg.params);
  if(msg.method?.startsWith('Browser.download'))receipt.downloads.push({method:msg.method,params:msg.params});
 });
 receipt.browser_version=await send('Browser.getVersion');
 const target=await send('Target.createTarget',{url:'about:blank'});
 session=(await send('Target.attachToTarget',{targetId:target.targetId,flatten:true})).sessionId;
 for(const method of ['Page.enable','Runtime.enable','Network.enable','DOM.enable'])await send(method,{},session);
 await send('Network.setCacheDisabled',{cacheDisabled:true},session);
 await metrics(1280,1000);
 const rich=pathToFileURL(path.join(root,'inputs/cli-r1/rich/comparison.html')).href;
 const nav=await send('Page.navigate',{url:rich},session);assert.ok(!nav.errorText);
 await waitFor(()=>evaluate('document.readyState==="complete"&&document.querySelectorAll(".record").length===2'),'rich report');
 await settle();
 const observation=await evaluate('({selectors:[...document.querySelectorAll(".record .selector")].map(n=>n.textContent),ids:[...document.querySelectorAll(".record")].map(r=>[...r.querySelectorAll("tr")].find(x=>x.querySelector("th")?.textContent==="id")?.querySelector("td")?.textContent),scripts:document.scripts.length,images:document.images.length,frames:document.querySelectorAll("iframe,object,embed").length,injected:document.getElementById("injected-witness")!==null,executed:typeof globalThis.__rootExecuted,removed:[...document.querySelectorAll(".diff-line.removed code")].map(n=>n.textContent),added:[...document.querySelectorAll(".diff-line.added code")].map(n=>n.textContent),links:[...document.querySelectorAll("a")].map(n=>n.getAttribute("href"))})');
 assert.deepEqual(observation.selectors,['history:3','history:1']);
 assert.deepEqual(observation.ids,['9007199254740995','9007199254740993']);
 assert.equal(observation.scripts,0);assert.equal(observation.images,0);assert.equal(observation.frames,0);assert.equal(observation.injected,false);assert.equal(observation.executed,'undefined');
 assert.ok(observation.removed.includes('First result: 7')&&observation.added.includes('First result: 8'));
 assert.ok(observation.removed.includes('y = 2')&&observation.added.includes('y = 1'));
 assert.ok(observation.links.every(x=>x.startsWith('#')||x.startsWith('data:application/json;base64,')));
 receipt.groups.push({name:'explicit_records_and_inert_actual_dom',pass:true,observation:{...observation,links:observation.links.map(x=>x.startsWith('data:')?'exact local JSON data URI':x)}});
 await screenshot('rich-desktop');
 const richDownload=await download('rich');
 await metrics(390,1000);await evaluate('window.scrollTo(0,0)');
 const phoneTop=await noOverflow('phone top');await screenshot('rich-phone-top');
 await evaluate('document.querySelector("#attachments").scrollIntoView({block:"start"})');
 const phoneFiles=await noOverflow('phone file metadata');
 const literalFile=await evaluate('document.querySelector("#attachments").innerText');
 assert.ok(literalFile.includes('<img onerror=alert(1)>')&&literalFile.includes('Q'.repeat(420)));
 await screenshot('rich-phone-attachments');
 await metrics(1280,1400);await send('Emulation.setEmulatedMedia',{media:'print'},session);
 await evaluate('document.querySelectorAll("details").forEach(n=>n.open=true);document.querySelector("#body").scrollIntoView({block:"start"})');
 const printBounds=await noOverflow('print media');await screenshot('rich-print-media');
 receipt.groups.push({name:'desktop_phone_and_print_media_regions',pass:true,phone_top:phoneTop,phone_files:phoneFiles,print_media:printBounds,boundary:'Captured rendered regions; no physical-device, pagination or paper-print claim'});
 await send('Emulation.setEmulatedMedia',{media:''},session);await metrics(1280,1000);
 const types=pathToFileURL(path.join(root,'inputs/cli-r1/types/comparison.html')).href;
 const typesNav=await send('Page.navigate',{url:types},session);assert.ok(!typesNav.errorText);
 await waitFor(()=>evaluate('document.readyState==="complete"&&document.querySelector("#body")?.innerText.includes("Text highlighting is unavailable")'),'types report');
 const typeView=await evaluate('({body:[...document.querySelectorAll("#body > .pair > .side > .value")].map(n=>n.textContent),url:[...document.querySelectorAll("#url .side")].map(n=>n.innerText),attachments:[...document.querySelectorAll("#attachments .side")].map(n=>n.innerText),media:document.querySelector("#media").innerText})');
 assert.deepEqual(typeView.body,['false','0']);
 assert.ok(typeView.url[0].includes('Omitted')&&typeView.url[1].includes('Blank string'));
 assert.ok(typeView.attachments[0].includes('Null')&&typeView.attachments[1].includes('Empty list'));
 await evaluate('document.querySelector("#body").scrollIntoView({block:"start"})');await screenshot('unsupported-value-states');
 const typedDownload=await download('types');
 receipt.groups.push({name:'unsupported_value_states_and_exact_pointer_downloads',pass:true,observation:typeView,downloads:[richDownload,typedDownload]});
 assert.equal(receipt.exceptions.length,0);
 assert.ok(receipt.network.every(r=>['file:','data:'].includes(new URL(r.url).protocol)),'External resource requested');
 const documents=receipt.network.filter(r=>r.type==='Document'&&r.url.startsWith('file:'));
 assert.deepEqual(documents.map(r=>r.url),[rich,types]);
 receipt.no_external_requests=true;
 for(const row of inputs){const b=await fs.readFile(path.join(root,'inputs',row.path));assert.equal(hash(b),row.sha256);}
 receipt.inputs_after_exact=true;
}catch(error){failure={type:error.name,message:error.message,stack:error.stack};receipt.failure=failure;}
finally{
 expectedClose=true;
 if(ws?.readyState===1){try{await send('Browser.close');}catch(error){receipt.close_command=String(error);}}
 const closed=await Promise.race([browserExitPromise,delay(7000).then(()=>null)]);
 if(!closed){try{process.kill(-browser.pid,'SIGTERM');receipt.terminated_owned_process_group=true;}catch(error){receipt.termination_error=String(error);}await Promise.race([browserExitPromise,delay(3000)]);}
 ws?.close();
 for(const p of pending.values()){clearTimeout(p.timer);p.reject(new Error('Browser receiving closed'));}pending.clear();
 receipt.browser_exit=browserExit??null;
 await fs.writeFile(path.join(evidence,'browser-stdout.log'),Buffer.concat(stdout),{flag:'wx'});
 await fs.writeFile(path.join(evidence,'browser-stderr.log'),Buffer.concat(stderr),{flag:'wx'});
 if(browserExit?.code===0){await fs.rm(profile,{recursive:true});receipt.profile_removed=true;}
 receipt.ended_at=new Date().toISOString();
 await fs.writeFile(path.join(evidence,'receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({receipt:path.join(evidence,'receipt.json'),sha256:hash(await fs.readFile(path.join(evidence,'receipt.json'))),groups:receipt.groups.map(g=>({name:g.name,pass:g.pass})),failure,artifacts:receipt.artifacts,browser_exit:receipt.browser_exit,profile_removed:receipt.profile_removed,no_external_requests:receipt.no_external_requests,inputs_after_exact:receipt.inputs_after_exact},null,2));
}
if(failure)process.exitCode=1;
