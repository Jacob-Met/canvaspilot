# CanvasPilot submission comparison: independent receiving contract

Frozen by estate-db371a37f4c8/root on 2026-10-08 before inspecting any candidate comparison implementation.

## Authoritative context

Canonical main: 0480cbce421bae532e3e909899fc8fb83789e878; tree f9ecaa4311d93cfe3a1fd1c9cc140834e2449341.
Read directly: src/canvaspilot/submission_history.py, src/canvaspilot/api.py, src/canvaspilot/client.py, src/canvaspilot/cli.py, docs/submission-history.md, tests/test_submission_history.py and tests/test_submission_history_process.py.
Read declared new consumer contract: issue #67 and /Users/me/hamon-canvas-comparison-db371a37f4c8/CONTRACT.md.

The canonical history reader preserves returned order, duplicate attempts, exact selected record fields, and separate current/top-level associations. Its assignment projection intentionally turns absent summary keys into null. The canonical client adds per_page=50 to requests. This receiver will exercise the real CLI and established API/client over authored loopback HTTP, not a substituted comparison function or a live Canvas account.

## Bounded independent controls

1. Explicit record identity and source fidelity. Supply history records whose attempt numbers and timestamps are duplicated/out of order, with distinct identity markers and nested unknown fields. Compare two explicit positions rather than choosing by attempt metadata. Retain literal selectors, exact selected JSON values and input order; do not import the current record or top-level grades/comments into either historical selection. Use mixed omitted, null, empty and non-empty fields, astral/combining Unicode, exact URLs, file/media metadata and hostile literal markup. The current submission and unselected history record contain distinct witness markers that cannot legitimately appear as selected content.

2. Offline reading and exact download. Open that actual emitted HTML with a fresh private browser profile and network observation. Check readable current selections and source differences, exact local JSON download, inert markup and URLs, long-value wrapping, and the captured desktop/390px/print-media regions. Print-media screenshots are not physical printing/pagination qualification; a phone viewport is not a physical-device claim. Close the browser and preserve all downloaded bytes in unique paths. Submitted text may be transformed for reading only while exact original JSON values remain available and differences caused only by source markup are disclosed.

3. Publication race. In a separate actual CLI process, start with a valid absent output target and a loopback server barrier after argument/output preflight. Create a sentinel target during the real request sequence, then release the response. The complete target must remain byte-for-byte sentinel content; CLI must refuse without success output or a partial replacement and clean only its private temporary file. This is a genuine concurrent file creation control, not a monkeypatched renderer or writer.

4. Unsupported and type-sensitive values. Through another actual CLI process, compare false with numeric zero in returned body/metadata values, and omitted, null, empty strings or empty file lists as distinct supplied states. Retain exact JSON types and disclose unsupported text highlighting without treating either value as an empty string or claiming semantic equality. This control complements the author's authored large-text boundary and malformed/error matrix instead of repeating that full suite.

## Execution and custody

Create no report or browser output until a frozen candidate is supplied. Pin every actual imported source file, the receiver, authored inputs, output HTML, browser executable/version, downloaded JSON, process stdout/stderr, request log, and screenshots. Measure the source before and after; distinguish root independent receiving from author tests and later composition.
Use existing verified native Python/Playwright dependencies read-only and no installations or broad rebuild. Preserve an original receiver failure and correction if one occurs; never silently rewrite a failed case or its evidence. No live school login, attachment retrieval, provider writes, browser session reuse, or deployment is in scope.
