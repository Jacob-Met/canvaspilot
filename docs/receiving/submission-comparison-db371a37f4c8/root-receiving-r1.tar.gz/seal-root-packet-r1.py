import pathlib, json, hashlib, io, tarfile, gzip, os
from datetime import datetime, timezone
ROOT=pathlib.Path("/home/jacob/snap/chromium/common/hamon-canvas-comparison-root-db371a37f4c8")
def sha(b): return hashlib.sha256(b).hexdigest()
def exact_or_new(p,b):
    if p.exists():
        assert p.is_file() and not p.is_symlink() and p.read_bytes()==b, str(p)
        return
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("xb") as f: f.write(b)
payload=json.loads((ROOT/"sealing-payload-r1.json").read_bytes())
for row in payload["files"]:
    b=row["content"].encode("utf-8")
    if "sha256" in row: assert sha(b)==row["sha256"],row["path"]
    exact_or_new(ROOT/row["path"],b)
expected={
"inputs/CONTRACT.md":"85a1459762c274066766e9bf8cf1083c22edc041e23714961d16c78ecdf4b6af",
"inputs/cli-r1/receipt.json":"b6232f61cabcdab7c54f1115a03a5aadd027292e8d05c32ae9b6069daf5cefe2",
"inputs/cli-r1/rich/comparison.html":"daf8d36a955ce135e5dbcae4b2c9db61a953a9f69e30c8c0fc8313f64d7f84d3",
"inputs/cli-r1/rich/embedded-selected-records.json":"82e8b5cf166b6d0b96f4d71af212df0d698d9dd931e514491dc3cc8a11e0434d",
"inputs/cli-r1/types/comparison.html":"6c5815d9c20f9ea650f7c88d359465f69746ec76bfdafdae9f9eca4d1f4d8d5a",
"inputs/cli-r1/types/embedded-selected-records.json":"8922f239ccb33916b685a7526080280f00834f6c722c2620387b855dfe2cd993",
"browser-r1/receipt.json":"01383ca4e10ead0811f8c69a756d96d478834d769d14cf262ac769aa976ada67",
"receive-browser-r1.mjs":"6ef94d4a53b9ac08cede0d52da3f2bb57ec275e6af8c05a566da26e7da7bf0de",
"receive-cli-r1.py":"4fe4baf79707506ec79f76eb4d3794cc826a2fd27def411f0b708ce781d5588d",
"input-transfer.json":"97cd10e6c3fbbc175ef1fcf6b5ba9c9b492dee8e5ba770400e90bf2553abbab5"}
for rel,h in expected.items(): assert sha((ROOT/rel).read_bytes())==h,rel
cli=json.loads((ROOT/"inputs/cli-r1/receipt.json").read_bytes())
browser=json.loads((ROOT/"browser-r1/receipt.json").read_bytes())
assert len(cli["groups"])==3 and all(g["pass"] for g in cli["groups"]) and cli["source_after_exact"]
assert len(browser["groups"])==3 and all(g["pass"] for g in browser["groups"])
assert browser["profile_removed"] and browser["browser_exit"]["code"]==0 and browser["inputs_after_exact"] and browser["no_external_requests"]
assert not browser["exceptions"]
for row in browser["artifacts"]:
    p=pathlib.Path(row["path"]); assert p.is_relative_to(ROOT)
    b=p.read_bytes(); assert len(b)==row["bytes"] and sha(b)==row["sha256"],str(p)
paths=[]
for directory in ["inputs","browser-r1","transport"]:
    for p in (ROOT/directory).rglob("*"):
        assert not p.is_symlink(),str(p)
        if p.is_file(): paths.append(p)
for rel in ["receive-browser-r1.mjs","receive-cli-r1.py","input-transfer.json","ROOT.md","seal-root-packet-r1.py"]:
    paths.append(ROOT/rel)
rows=[]
data={}
for p in sorted(paths,key=lambda p:p.relative_to(ROOT).as_posix()):
    rel=p.relative_to(ROOT).as_posix(); assert rel not in data
    b=p.read_bytes(); data[rel]=b
    rows.append({"path":rel,"bytes":len(b),"sha256":sha(b)})
manifest={"format":"hamon.root-receiving-archive.v1","scope":"CanvasPilot submission comparison independent root CLI and browser receiving","files":rows,"payload_files":len(rows),"payload_bytes":sum(r["bytes"] for r in rows),"missing_mac_only_files_disclosed_in":"ROOT.md","all_payload_pins_checked":True}
mb=(json.dumps(manifest,indent=2,ensure_ascii=True)+"\n").encode()
data["MANIFEST.json"]=mb
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode="w",format=tarfile.USTAR_FORMAT) as t:
    for rel,b in sorted(data.items()):
        info=tarfile.TarInfo(rel);info.size=len(b);info.mtime=0;info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname=""
        t.addfile(info,io.BytesIO(b))
compressed=gzip.compress(raw.getvalue(),compresslevel=9,mtime=0)
archive=ROOT/"root-receiving-r1.tar.gz"
exact_or_new(archive,compressed)
with tarfile.open(fileobj=io.BytesIO(compressed),mode="r:gz") as t:
    members=t.getmembers()
    assert len(members)==len(data)
    assert set(m.name for m in members)==set(data)
    for m in members:
        assert m.isfile() and t.extractfile(m).read()==data[m.name],m.name
for row in rows: assert sha((ROOT/row["path"]).read_bytes())==row["sha256"]
exact_or_new(ROOT/"root-receiving-manifest-r1.json",mb)
receipt={"created_at":datetime.now(timezone.utc).isoformat(),"path":str(archive),"bytes":len(compressed),"sha256":sha(compressed),"git_blob_sha":hashlib.sha1(("blob "+str(len(compressed))+"\0").encode()+compressed).hexdigest(),"manifest_sha256":sha(mb),"payload_files":len(rows),"archive_members":len(data),"uncompressed_payload_bytes":sum(len(b) for b in data.values()),"all_members_roundtrip_exact":True,"all_source_files_after_exact":True,"root_note_sha256":sha((ROOT/"ROOT.md").read_bytes()),"no_product_execution":True}
with (ROOT/"root-receiving-seal-r1.json").open("x",encoding="utf-8") as f:json.dump(receipt,f,indent=2);f.write("\n")
print(json.dumps(receipt,indent=2))
