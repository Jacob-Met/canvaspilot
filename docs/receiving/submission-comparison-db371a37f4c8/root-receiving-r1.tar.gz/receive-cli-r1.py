"""Independent actual-CLI receiving, frozen contract before candidate review."""
import base64, copy, hashlib, json, os, pathlib, subprocess, threading, time, traceback
from datetime import datetime, timezone
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs
ROOT=pathlib.Path("/Users/me/hamon-canvas-comparison-root-db371a37f4c8")
SOURCE=pathlib.Path("/Users/me/hamon-canvas-comparison-db371a37f4c8/composition-source")
MANIFEST=SOURCE.parent/"composition-source-manifest-r1.json"
PYTHON="/Users/me/canvaspilot-announcements-3dcb83a1/.venv/bin/python"
TOKEN="synthetic-root-canvas-comparison-token"
OUT=ROOT/"cli-r1"
def stamp(): return datetime.now(timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def put(path,value):
    with path.open("x",encoding="utf-8") as f:
        json.dump(value,f,ensure_ascii=True,indent=2); f.write("\n")
def free():
    v=os.statvfs(ROOT); return v.f_bavail*v.f_frsize
if free()<64*1024*1024:
    print(json.dumps({"status":"capacity_refused_before_cli","free_bytes":free(),"floor":64*1024*1024}))
    raise SystemExit(3)
OUT.mkdir(exist_ok=False)
manifest_bytes=MANIFEST.read_bytes()
manifest=json.loads(manifest_bytes)
def pins():
    rows=[]
    for row in manifest["files"]:
        p=SOURCE/row["path"]; b=p.read_bytes()
        assert sha(b)==row["sha256"], row["path"]
        rows.append({"path":row["path"],"bytes":len(b),"sha256":sha(b)})
    return rows
before_pins=pins()
receipt={"started_at":stamp(),"contract_sha256":sha((ROOT/"CONTRACT.md").read_bytes()),
         "receiver_sha256":sha(pathlib.Path(__file__).read_bytes()),
         "source_manifest_sha256":sha(manifest_bytes),"source":str(SOURCE),
         "source_files":len(before_pins),"capacity_floor_bytes":64*1024*1024,
         "capacity_scope":"Three bounded authored CLI processes; below 1 MiB expected report/receipt output, no build or browser",
         "free_bytes_before":free(),"groups":[],"processes":[]}
put(OUT/"source-before.json",before_pins)
env={k:v for k,v in os.environ.items() if not k.startswith("CANVAS_") and k.upper() not in {"HTTP_PROXY","HTTPS_PROXY","ALL_PROXY","NO_PROXY","PYTHONPATH","PYTHONHOME","PYTHONSTARTUP"}}
env.update({"PYTHONPATH":str(SOURCE/"src"),"PYTHONNOUSERSITE":"1","PYTHONDONTWRITEBYTECODE":"1","NO_PROXY":"127.0.0.1,localhost"})
binding=subprocess.run([PYTHON,"-B","-c","import sys,json,canvaspilot.cli,canvaspilot.api,canvaspilot.client,canvaspilot.submission_history,canvaspilot.submission_comparison;print(json.dumps({'python':sys.version,'executable':sys.executable,'modules':{n:sys.modules[n].__file__ for n in ['canvaspilot.cli','canvaspilot.api','canvaspilot.client','canvaspilot.submission_history','canvaspilot.submission_comparison']}}))"],cwd=OUT,env=env,capture_output=True,timeout=15)
(OUT/"import-binding-stdout.log").write_bytes(binding.stdout)
(OUT/"import-binding-stderr.log").write_bytes(binding.stderr)
assert binding.returncode==0 and binding.stderr==b""
bound=json.loads(binding.stdout)
assert all(pathlib.Path(p).is_relative_to(SOURCE/"src") for p in bound["modules"].values())
put(OUT/"import-binding.json",bound)
assignment={"id":902,"course_id":71,"name":"Projection & exact records \U0001f9ed",
            "html_url":"https://never-fetch.invalid/courses/71/assignments/902","points_possible":30}
first={"id":9007199254740993,"assignment_id":902,"course_id":"00071","attempt":4,
       "submitted_at":"2026-10-07T18:00:00Z","submission_type":"online_text_entry",
       "body":'<section><p>Projection &amp; scale \U0001f9ed e\u0301</p><p>First result: 8</p><pre>x = 0\r\ny = 1</pre><img id="injected-witness" src="https://never-fetch.invalid/pixel" alt="literal diagram"><script>globalThis.__rootExecuted="FIRST";fetch("https://never-fetch.invalid/script")</script></section>',
       "url":"https://work.invalid/A?x=1&x=2#frag","attachments":[],
       "media_comment":"","media_comment_id":0,"score":0,"grade":None,
       "future":{"record":"FIRST_SELECTED","flag":False,"zero":0,"large":9007199254740993,"control":"\u0000\u202e","surrogate":"\ud800"}}
third={"id":9007199254740995,"assignment_id":"00902","attempt":4,
       "submitted_at":"2026-10-06T19:00:00Z","submission_type":"online_text_entry",
       "body":'<div><p>Projection &amp; scale \U0001f9ed e\u0301</p><p>First result: 7</p><pre>x = 0\ny = 2</pre><img src="https://never-fetch.invalid/other" alt="literal diagram"><style>body{background:red}</style></div>',
       "url":"HTTPS://Work.Invalid/%41?x=1&x=2#frag",
       "attachments":[{"id":17,"filename":"<img onerror=alert(1)> \U0001f9ed "+("Q"*420)+".pdf","size":0,"url":"javascript:alert(1)","future":{"flag":False}},
                      {"id":18,"filename":"second.txt","size":None,"url":None}],
       "media_comment":None,"media_comment_id":False,"grade":"0",
       "submission_comments":[{"comment":"THIRD_LOCAL_ONLY","attempt":4}],
       "future":{"record":"THIRD_SELECTED","flag":0,"zero":False}}
rich={"id":600,"assignment_id":902,"attempt":12,"body":"CURRENT_MUST_NOT_ATTACH","grade":"CURRENT_GRADE_MUST_NOT_ATTACH",
      "submission_history":[first,{"id":700,"attempt":2,"body":"UNSELECTED_MUST_NOT_ATTACH"},third],
      "submission_comments":[{"comment":"TOP_LEVEL_MUST_NOT_ATTACH","attempt":4}]}
typed_current={"id":601,"assignment_id":902,"attempt":9,"submission_type":"unknown_future",
               "body":0,"url":"","attachments":[],"media_comment":[],"media_comment_type":"",
               "future":{"value":0,"large":-9007199254740993}}
typed_before={"id":602,"attempt":9,"body":False,"attachments":None,"media_comment":None,"media_comment_type":None,
              "future":{"value":False,"large":-9007199254740993}}
typed={**typed_current,"submission_history":[typed_before],"submission_comments":[]}
fixtures={"rich":{"submission":rich,"before":"history:3","after":"history:1","left":third,"right":first},
          "types":{"submission":typed,"before":"history:1","after":"current","left":typed_before,"right":typed_current},
          "race":{"submission":rich,"before":"history:3","after":"history:1","left":third,"right":first}}
def exact(a,b,label="value"):
    assert type(a) is type(b), (label,type(a).__name__,type(b).__name__)
    if isinstance(a,dict):
        assert list(a)==list(b), (label,"object fields or order",list(a),list(b))
        for k in a: exact(a[k],b[k],label+"."+k)
    elif isinstance(a,list):
        assert len(a)==len(b), (label,"length")
        for i,(x,y) in enumerate(zip(a,b)): exact(x,y,label+"["+str(i)+"]")
    else: assert a==b, (label,a,b)
class Links(HTMLParser):
    def __init__(self): super().__init__(); self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag=="a": self.links.append(dict(attrs))
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*_args): pass
    def do_GET(self):
        u=urlsplit(self.path)
        row={"at":stamp(),"method":self.command,"path":u.path,"query":parse_qs(u.query,keep_blank_values=True),"authorization":self.headers.get("Authorization")}
        self.server.calls.append(row)
        if self.headers.get("Authorization")!="Bearer "+TOKEN: status,payload=401,{"error":"synthetic auth required"}
        elif u.path=="/api/v1/courses/71/assignments/902": status,payload=200,assignment
        elif u.path=="/api/v1/courses/71/assignments/902/submissions/self":
            if self.server.name=="race":
                assert not self.server.output.exists()
                with self.server.output.open("xb") as f: f.write(self.server.sentinel)
                self.server.race_event={"at":stamp(),"after_request_count":len(self.server.calls),"sha256":sha(self.server.sentinel)}
            status,payload=200,self.server.fixture
        else: status,payload=404,{"error":"unexpected fixture route"}
        body=json.dumps(payload,ensure_ascii=True).encode("utf-8")
        self.send_response(status);self.send_header("Content-Type","application/json; charset=utf-8");self.send_header("Content-Length",str(len(body)));self.end_headers();self.wfile.write(body)
    def unexpected(self):
        self.server.calls.append({"at":stamp(),"method":self.command,"path":self.path})
        self.send_error(405)
    do_POST=do_PUT=do_PATCH=do_DELETE=do_HEAD=unexpected
try:
    for name in ("rich","race","types"):
        data=fixtures[name]; case=OUT/name;case.mkdir()
        output=case/"comparison.html"; profile=case/"unused-profile"
        put(case/"authored-input.json",{"assignment":assignment,"submission":data["submission"],"before":data["before"],"after":data["after"]})
        server=ThreadingHTTPServer(("127.0.0.1",0),Handler);server.daemon_threads=True
        server.name=name;server.calls=[];server.fixture=copy.deepcopy(data["submission"]);server.output=output
        server.sentinel=b"Independent writer created this target during the actual self-submission GET.\n"
        server.race_event=None
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        argv=[PYTHON,"-B","-m","canvaspilot.cli","compare-submissions","00071","0902","--before",data["before"],"--after",data["after"],"--out",str(output),"--base-url","http://127.0.0.1:"+str(server.server_port),"--token",TOKEN,"--profile",str(profile)]
        observation={"started_at":stamp(),"argv":argv,"cwd":str(case),"free_bytes_before":free(),"output_absent_before_start":not output.exists()}
        try:
            p=subprocess.run(argv,cwd=case,env=env,capture_output=True,timeout=30,check=False)
        finally:
            server.shutdown();server.server_close();thread.join(timeout=3)
        (case/"stdout.log").write_bytes(p.stdout);(case/"stderr.log").write_bytes(p.stderr)
        observation.update({"ended_at":stamp(),"returncode":p.returncode,"stdout_sha256":sha(p.stdout),"stderr_sha256":sha(p.stderr),"requests":server.calls,"race_event":server.race_event,"profile_created":profile.exists(),"server_closed":not thread.is_alive()})
        put(case/"process.json",observation);receipt["processes"].append(observation)
        assert not profile.exists() and not thread.is_alive()
        assert [x["method"] for x in server.calls]==["GET","GET"]
        assert [x["path"] for x in server.calls]==["/api/v1/courses/71/assignments/902","/api/v1/courses/71/assignments/902/submissions/self"]
        assert server.calls[0]["query"]=={"per_page":["50"]}
        assert server.calls[1]["query"]=={"include[]":["submission_history","submission_comments"],"per_page":["50"]}
        assert all(x["authorization"]=="Bearer "+TOKEN for x in server.calls)
        assert not list(case.glob(".canvaspilot-comparison-*.tmp"))
        if name=="race":
            assert p.returncode==1 and p.stdout==b""
            error=json.loads(p.stderr);assert error["ok"] is False and error["error"]=="FileExistsError"
            assert output.read_bytes()==server.sentinel
            assert server.race_event["after_request_count"]==2
            receipt["groups"].append({"name":"real_output_creation_during_http","pass":True,"sentinel_sha256":sha(output.read_bytes()),"race_event":server.race_event})
            continue
        assert p.returncode==0 and p.stderr==b"", (name,p.returncode,p.stderr.decode("utf-8","replace"))
        success=json.loads(p.stdout)
        assert success["ok"] is True and success["before"]==data["before"] and success["after"]==data["after"] and success["output"]==str(output)
        report=output.read_bytes();html=report.decode("utf-8")
        parser=Links();parser.feed(html)
        link=next(x for x in parser.links if x.get("id")=="download-records")
        prefix="data:application/json;base64,"
        assert link["href"].startswith(prefix) and link["download"]=="selected-submission-records.json"
        packet_bytes=base64.b64decode(link["href"][len(prefix):],validate=True)
        (case/"embedded-selected-records.json").write_bytes(packet_bytes)
        packet=json.loads(packet_bytes)
        assert packet["format"]=="canvaspilot.submission-comparison.v1"
        assert packet["request"]=={"course_id":"71","assignment_id":"902"}
        assert packet["history"]=={"returned":True,"record_count":len(data["submission"]["submission_history"])}
        assert packet["before"]["selector"]==data["before"] and packet["after"]["selector"]==data["after"]
        exact(packet["before"]["record"],data["left"],"before")
        exact(packet["after"]["record"],data["right"],"after")
        assert packet["assignment"]=={key:assignment.get(key) for key in ("id","course_id","name","html_url","due_at","points_possible")}
        for marker in ("CURRENT_MUST_NOT_ATTACH","CURRENT_GRADE_MUST_NOT_ATTACH","UNSELECTED_MUST_NOT_ATTACH","TOP_LEVEL_MUST_NOT_ATTACH"): assert marker not in html
        if name=="rich":
            assert packet["before"]["record"]["id"]==9007199254740995
            assert packet["after"]["record"]["id"]==9007199254740993
            assert packet["after"]["record"]["future"]["surrogate"]=="\ud800"
            assert 'id="injected-witness"' not in html
            group="exact_explicit_historical_selection"
        else:
            assert type(packet["before"]["record"]["body"]) is bool and packet["before"]["record"]["body"] is False
            assert type(packet["after"]["record"]["body"]) is int and packet["after"]["record"]["body"]==0
            assert "Text highlighting is unavailable" in html
            for label in ("Omitted — key not returned","Null — explicitly returned","Empty list — []","Blank string"): assert label in html
            group="unsupported_types_and_distinct_value_states"
        receipt["groups"].append({"name":group,"pass":True,"report":str(output),"report_bytes":len(report),"report_sha256":sha(report),"embedded_packet_sha256":sha(packet_bytes),"selected_record_ids":[data["left"]["id"],data["right"]["id"]]})
    after_pins=pins();assert after_pins==before_pins
    put(OUT/"source-after.json",after_pins)
    receipt["source_after_exact"]=True
except BaseException as error:
    receipt["failure"]={"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}
    try: receipt["source_after_exact"]=pins()==before_pins
    except BaseException as source_error: receipt["source_check_failure"]=str(source_error)
finally:
    receipt["ended_at"]=stamp();receipt["free_bytes_after"]=free()
    put(OUT/"receipt.json",receipt)
    print(json.dumps({"receipt":str(OUT/"receipt.json"),"sha256":sha((OUT/"receipt.json").read_bytes()),"groups":receipt["groups"],"failure":receipt.get("failure"),"source_after_exact":receipt.get("source_after_exact"),"free_bytes_after":receipt["free_bytes_after"]},ensure_ascii=True,indent=2))
raise SystemExit(1 if receipt.get("failure") else 0)
