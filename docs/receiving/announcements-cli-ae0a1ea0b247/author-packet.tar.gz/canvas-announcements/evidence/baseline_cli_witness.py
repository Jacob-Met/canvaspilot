import hashlib,json,pathlib,subprocess,sys
source=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
raw=source.read_bytes();sha=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
assert sha=="545ec52f31b694a351e9a41a68e52a34c49db532"
cases=[("existing-help",["--help"],0),("missing-announcements",["announcements","42","77"],2),("missing-full-announcements",["announcements","42","77","--detail","full","--start-date","2026-10-01"],2)]
rows=[]
for name,args,expected in cases:
 p=subprocess.run([sys.executable,"-B",str(source),*args],capture_output=True,text=True)
 (out/(name+".stdout")).write_text(p.stdout);(out/(name+".stderr")).write_text(p.stderr)
 assert p.returncode==expected,(name,p.returncode,p.stderr)
 if name.startswith("missing-"):assert "invalid choice: 'announcements'" in p.stderr and not p.stdout
 rows.append({"name":name,"argv":args,"returncode":p.returncode,"result":"CONTROL_PASS" if expected==0 else "MISSING_CAPABILITY_CONFIRMED","stdoutSha256":hashlib.sha256(p.stdout.encode()).hexdigest(),"stderrSha256":hashlib.sha256(p.stderr.encode()).hexdigest()})
assert source.read_bytes()==raw
report={"sourceBlob":sha,"sourceUnchanged":True,"cases":rows,"qualification":"Actual maintained cli.py __main__ entry, using stdlib argument parsing. No dependency shim or substitute API. These failures occur before API import or any HTTP request; full native-client execution awaits available dependencies."}
(out/"baseline-receipt.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2))
