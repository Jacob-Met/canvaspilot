import difflib,hashlib,importlib.metadata,io,json,os,pathlib,sys,tarfile
root=pathlib.Path(sys.argv[1]); source=root/"source"; evidence=root/"evidence"
reserve=pathlib.Path("/dev/shm/ae0a1ea0b247-canvas-announcements-evidence.reserve")
def ident(data):return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"gitBlob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
pins=json.loads((evidence/"source-pins.json").read_text())
spans=json.loads((evidence/"contribution-spans.json").read_text())
cli=(source/"src/canvaspilot/cli.py").read_text()
assert cli.replace(spans["parser"],"").replace(spans["dispatch"],"")== (evidence/"original-cli.py").read_text()
readme=(source/"README.md").read_text()
assert ident(readme.replace(spans["readme"],"").encode())["gitBlob"]=="4a61c3a5c4b219ec3aaa6cf3b64f19338856ca1f"
baseline=pins["files"]+spans["scriptManifest"]
unchanged={}
for entry in baseline:
 if entry["path"]=="src/canvaspilot/cli.py":continue
 actual=ident((source/entry["path"]).read_bytes())
 assert actual["gitBlob"]==entry["sha"],entry["path"]
 unchanged[entry["path"]]=actual
contributed={p:ident((source/p).read_bytes()) for p in ["src/canvaspilot/cli.py","tests/test_announcements_cli.py","docs/announcements-cli.md","README.md"]}
assert contributed["src/canvaspilot/cli.py"]["gitBlob"]=="a38cda5d650c6fb400089a84b800c7422ad2dbb2"
patch="".join(difflib.unified_diff((evidence/"original-cli.py").read_text().splitlines(True),cli.splitlines(True),fromfile="a/src/canvaspilot/cli.py",tofile="b/src/canvaspilot/cli.py"))
(evidence/"candidate-cli.patch").write_text(patch)
full=json.loads((evidence/"candidate-full-native-suite-venv.json").read_text())
initialFull=json.loads((evidence/"candidate-full-native-suite.json").read_text())
focused=json.loads((evidence/"candidate-focused-corrected.json").read_text())
lint=json.loads((evidence/"candidate-native-lint-corrected.json").read_text())
receipt={"status":"AUTHOR_FROZEN","base":pins["base"],"claim":pins["claim"],"contributed":contributed,"unchangedImportedCount":len(unchanged),"unchangedImported":unchanged,"existingCliAndReadmeReconstructExactly":True,"nativeFocused":focused,"nativeFull":full,"initialFullMissingSubprocessDependency":initialFull,"nativeLint":lint,"dependencies":{"mode":"Read-only existing CanvasPilot Python3.12 dependency directory; no package installed or API replaced","path":"/workspace/scratch/ac386303dce2/runtime-execution/canvaspilot-env/lib/python3.12/site-packages","executable":"/workspace/scratch/ac386303dce2/runtime-execution/canvaspilot-env/bin/python","versions":{name:importlib.metadata.version(name) for name in ["httpx","mcp","pytest","ruff","pydantic"]}},"qualifications":["All network observations are authored loopback HTTP; no school account, browser profile or provider was used.","Full offline-suite execution clears proxy variables for local fixtures. No production client, broker, authentication or proxy implementation changed.","The first full run used the primary interpreter with borrowed PYTHONPATH; inherited subprocess tests replace that path and could not import httpx. Its 28 failures/658 passes/1 skip are retained. The same untouched full source is then executed through the existing venv interpreter, so child processes inherit its installed packages without relying on PYTHONPATH.","Original stdlib and complete-module missing-command witnesses, first dependency/incomplete-closure failures, original receiver calibration and the first candidate's real logging failures remain in evidence.","The original baseline fixture comparison uses the exact original CLI. The corrected source passes the same focused receiver after the documented logger correction.","This is an authored source freeze awaiting independent receiving and normal native CI/integration; it is not a deployed service or owner lease."]}
(evidence/"AUTHOR-RECEIPT.json").write_text(json.dumps(receipt,indent=2)+"\n")
files=[]
for folder in [source,evidence]:
 for p in folder.rglob("*"):
  if not p.is_file() or any(part in {".pytest_cache","__pycache__", ".ruff_cache"} for part in p.parts):continue
  if p.name=="PACKET-MANIFEST.json" or p.name.startswith("packet-retention"):continue
  files.append(p)
manifest={str(p.relative_to(root)):ident(p.read_bytes()) for p in sorted(files)}
(evidence/"PACKET-MANIFEST.json").write_text(json.dumps({"files":manifest},indent=2)+"\n")
files.append(evidence/"PACKET-MANIFEST.json")
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode="w:gz",compresslevel=9) as archive:
 for p in sorted(files):archive.add(p,arcname="canvas-announcements/"+str(p.relative_to(root)),recursive=False)
raw=buf.getvalue();assert len(raw)<=reserve.stat().st_size,("packet exceeds allocation",len(raw),reserve.stat().st_size)
assert not any(reserve.read_bytes()),"reserve already holds evidence"
with reserve.open("r+b") as f:
 f.write(raw);f.flush();os.fsync(f.fileno());f.seek(0);assert f.read(len(raw))==raw
 f.truncate(len(raw));f.flush();os.fsync(f.fileno());f.seek(0);assert f.read()==raw
with tarfile.open(fileobj=io.BytesIO(reserve.read_bytes()),mode="r:gz") as archive:
 for name,value in manifest.items():assert ident(archive.extractfile("canvas-announcements/"+name).read())==value,name
print(json.dumps({"packet":{"path":str(reserve),"format":"tar.gz",**ident(raw),"files":len(files)},"receipt":ident((evidence/"AUTHOR-RECEIPT.json").read_bytes()),"manifest":ident((evidence/"PACKET-MANIFEST.json").read_bytes()),"contributed":contributed,"unchangedImportedCount":len(unchanged),"fullReturncode":full["returncode"],"fullStdout":(evidence/"candidate-full-native-suite-venv.stdout").read_text()[-2200:],"focusedStdout":(evidence/"candidate-focused-corrected.stdout").read_text(),"lintReturncode":lint["returncode"]},indent=2))
