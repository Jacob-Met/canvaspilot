# Announcement CLI current-source composition

The immutable author packet remains tied to a5ce672e5b3580c1f52e13c49eefee830f11346c. This supplement records the same announcement spans composed over discussion-merged current main c744bb5b79f23457f4dd9070f762100bc6ad91ad / tree abec51ddc40ab44d9e405857469736550d08b4f2.

Current CLI cf51b1e3f57f1b821eadbe7416f352a826faeded and README b8128cb28110636eb02fb6f1770d26e0e00df127 remove back to exact current before-images e29baec3a184006d90f70c879880ceb4d1de2a3c / c193b910f10d8a17ebab5a0e4f4fcde4588578c1 using only the original contribution spans.

All 46 pre-existing API function bodies are unchanged by the incoming owner merge; CanvasAPI.discussion_thread is the sole added API function body. Current API258efbfc, client1db4b113, MCP2a29f821, bundlecebeaa98 and discussion_thread2ed658fc remain exact parent source.

The same native test bodies ran once together on this combined source: the full/start-date/narrow-console announcement test and the owner's actual all/unread discussion CLI test. Both passed (2 in5.07seconds), using actual installed Python/HTTPX and authored loopback requests. This is a bounded current import/parser seam check, not a relabeled full author suite. No source or test changed after the run.

To reconstruct the layout, extract the original author archive's canvas-announcements directory, then copy this supplement's current-input and current-evidence directories into it. From that root, source_join.py reconstructs current-source using only pinned source inputs and verifies API/before-image preservation. The actual execution records name the qualified existing interpreter and environment. Normal hosted CI and independent source-binding are recorded on the native PR.

The original parent/current CLI and README before-images, all new owner runtime/test inputs, exact composed files, helper and native outputs are retained. Only source files and synthetic results are present; no school data, live account, browser profile, lease or deployed service is claimed.
