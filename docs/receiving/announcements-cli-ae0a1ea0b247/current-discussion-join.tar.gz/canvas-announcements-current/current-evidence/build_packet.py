from pathlib import Path
import base64,hashlib,io,json,tarfile
root=Path.cwd(); ev=root/"current-evidence"; dest=ev/"execution"; dest.mkdir(exist_ok=True)
for stem in ["current-source-composition","current-paired-cli-receiving"]:
 for ext in ["json","stdout","stderr"]:
  p=root/"evidence"/(stem+"."+ext);(dest/p.name).write_bytes(p.read_bytes())
def ident(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"gitBlob":hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()}
files=[p for folder in [root/"current-input",ev] for p in folder.rglob("*") if p.is_file() and p.name!="MANIFEST.json"]
manifest={str(p.relative_to(root)):ident(p.read_bytes()) for p in sorted(files)}
(ev/"MANIFEST.json").write_text(json.dumps({"files":manifest},indent=2)+"\n");files.append(ev/"MANIFEST.json")
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode="w:gz",compresslevel=9) as archive:
 for p in sorted(files):archive.add(p,arcname="canvas-announcements-current/"+str(p.relative_to(root)),recursive=False)
raw=buf.getvalue();(root/"current-join.tar.gz").write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(raw),mode="r:gz") as archive:
 for name,pin in manifest.items():assert ident(archive.extractfile("canvas-announcements-current/"+name).read())==pin,name
encoded=base64.b64encode(raw).decode()
parts=[encoded[i:i+24000] for i in range(0,len(encoded),24000)]
for i,part in enumerate(parts):(root/f"current-join-base64-{i}.txt").write_text(part)
print(json.dumps({"packet":ident(raw),"files":len(files),"parts":len(parts),"manifest":ident((ev/"MANIFEST.json").read_bytes())},indent=2))
