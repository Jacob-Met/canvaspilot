from pathlib import Path
import ast,hashlib,json,shutil
root=Path.cwd(); old=root/"source"; src=root/"current-source"; inp=root/"current-input"; out=root/"current-evidence"
src.mkdir(exist_ok=True);out.mkdir(exist_ok=True)
shutil.copytree(old,src,dirs_exist_ok=True,ignore=shutil.ignore_patterns("__pycache__",".pytest_cache",".ruff_cache"))
for folder in ["src","tests"]:
 for p in (inp/folder).rglob("*"):
  if p.is_file():
   target=src/p.relative_to(inp);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
(src/"src/canvaspilot/cli.py").write_bytes((inp/"cli.py").read_bytes())
(src/"README.md").write_bytes((inp/"README.md").read_bytes())
spans=json.loads((root/"evidence/contribution-spans.json").read_text())
assert (src/"src/canvaspilot/cli.py").read_text().replace(spans["parser"],"").replace(spans["dispatch"],"")==(inp/"before-cli.py").read_text()
assert (src/"README.md").read_text().replace(spans["readme"],"")==(inp/"before-README.md").read_text()
def methods(path):
 tree=ast.parse(path.read_text()); result={}
 for node in tree.body:
  if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):result[node.name]=ast.dump(node,include_attributes=False)
  elif isinstance(node,ast.ClassDef):
   for method in node.body:
    if isinstance(method,(ast.FunctionDef,ast.AsyncFunctionDef)):result[node.name+"."+method.name]=ast.dump(method,include_attributes=False)
 return result
before=methods(old/"src/canvaspilot/api.py");after=methods(src/"src/canvaspilot/api.py")
assert all(after.get(k)==v for k,v in before.items()),[k for k,v in before.items() if after.get(k)!=v]
def ident(raw):
 return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"gitBlob":hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()}
pins={str(p.relative_to(src)):ident(p.read_bytes()) for p in src.rglob("*") if p.is_file() and not any(x in p.parts for x in ["__pycache__",".pytest_cache",".ruff_cache"])}
receipt={"status":"SOURCE_COMPOSED","base":"c744bb5b79f23457f4dd9070f762100bc6ad91ad","baseTree":"abec51ddc40ab44d9e405857469736550d08b4f2","originalAuthorBase":"a5ce672e5b3580c1f52e13c49eefee830f11346c","cliBefore":ident((inp/"before-cli.py").read_bytes()),"readmeBefore":ident((inp/"before-README.md").read_bytes()),"cliCurrent":pins["src/canvaspilot/cli.py"],"readmeCurrent":pins["README.md"],"exactCurrentBeforeImagesReconstructed":True,"existingApiBodiesUnchanged":len(before),"addedApiBodies":sorted(set(after)-set(before)),"sourceFiles":pins,"qualification":"Only original announcement spans and paragraph are inserted into complete current discussion-merged source. Original API bodies all match by native AST; actual paired CLI receiving follows without relabeling original full-suite counts as current."}
(out/"source-join.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({k:v for k,v in receipt.items() if k!="sourceFiles"},indent=2))
