"""Independent Canvas announcement CLI receiving; actual HTTPX and loopback HTTP."""
from __future__ import annotations
import contextlib, hashlib, importlib.util, io, json, logging, os, pathlib, sys, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qsl, urlencode, urlsplit

root=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2]); out.mkdir()
sys.path.insert(0,str(root/'source/src'))
original_path=root/'original-cli.py'
spec=importlib.util.spec_from_file_location('independent_original_cli',original_path)
original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
body='résumé '+('x'*410)
records=[
 {'id':'A-007','title':'Literal <b> & snow 雪','posted_at':None,'context_code':'course_71','message':body,'html_url':'https://example.invalid/a?x=1&y=2','ignored':'not projected'},
 {'id':13,'title':'second page','posted_at':'2026-01-02T03:04:05+09:00','context_code':'course_3','message':'<p>short</p>','html_url':None},
]
expected=[{k:r[k] for k in ('id','title','posted_at','context_code','html_url')} | {'message_text':body if i==0 else 'short'} for i,r in enumerate(records)]
requests=[];mode='healthy'
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args): pass
 def do_GET(self):
  parsed=urlsplit(self.path);q=parse_qsl(parsed.query);requests.append({'method':'GET','path':parsed.path,'query':q})
  assert self.headers.get('Authorization')=='Bearer synthetic-local-only'
  assert parsed.path=='/api/v1/announcements'
  page=dict(q).get('page','1')
  status=403 if mode=='auth' else (503 if mode=='late' and page=='2' else 200)
  payload=({'error':'authored refusal'} if status!=200 else [records[int(page)-1]])
  b=json.dumps(payload).encode();self.send_response(status)
  self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)))
  if status==200 and page=='1':
   next_q=[(k,v) for k,v in q if k!='page']+[('page','2')]
   self.send_header('Link','<'+base+'/api/v1/announcements?'+urlencode(next_q)+'>; rel="next"')
  self.end_headers();self.wfile.write(b)

server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
base='http://127.0.0.1:'+str(server.server_port)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
for key in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):
 os.environ.pop(key,None)
os.environ['NO_PROXY']='127.0.0.1,localhost'
os.environ['no_proxy']='127.0.0.1,localhost'
logger=logging.getLogger('httpx'); logs=io.StringIO(); handler=logging.StreamHandler(logs)
prior=(logger.level,list(logger.handlers),logger.propagate)
logger.setLevel(logging.INFO);logger.handlers=[handler];logger.propagate=False
cases=[]
def invoke(module,detail='full',level=logging.INFO):
 logger.setLevel(level);before=(logger.level,tuple(logger.handlers),logger.propagate)
 logs.seek(0);logs.truncate(0);requests.clear()
 stdout,stderr=io.StringIO(),io.StringIO();exit_code=0
 argv=['announcements','71','3','--start-date','2026-01-02T03:04:05+09:00','--detail',detail,'--base-url',base,'--token','synthetic-local-only']
 with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
  try:module.main(argv)
  except SystemExit as exc:exit_code=exc.code
 result={'mode':mode,'detail':detail,'logger_level':level,'exit':exit_code,'stdout':stdout.getvalue(),'stderr':stderr.getvalue(),'requests':list(requests),'httpx_logs':logs.getvalue()}
 assert before==(logger.level,tuple(logger.handlers),logger.propagate),'logger state changed'
 return result
try:
 baseline=invoke(original);assert baseline['exit']==2 and not baseline['requests'] and not baseline['stdout']
 cases.append({'name':'original refusal without network or logger mutation','result':baseline})
 from canvaspilot import cli
 for detail,level in [('full',logging.INFO),('compact',logging.DEBUG)]:
  result=invoke(cli,detail,level)
  assert result['exit']==0 and not result['stderr'],result
  expect=json.loads(json.dumps(expected))
  if detail=='compact':expect[0]['message_text']=body[:400]+'…'
  assert json.loads(result['stdout'])==expect,result
  assert len(result['requests'])==2
  for request in result['requests']:
   q=request['query'];assert [v for k,v in q if k=='context_codes[]']==['course_71','course_3']
   assert [v for k,v in q if k=='start_date']==['2026-01-02T03:04:05+09:00']
   assert dict(q)['active_only']=='true' and dict(q)['per_page']=='50'
  assert not result['httpx_logs'],result
  logger.info('receiver-post-command-marker')
  assert 'receiver-post-command-marker' in logs.getvalue()
  cases.append({'name':detail+' actual CLI/pagination and restored logger','result':result})
 for selected in ('late','auth'):
  mode=selected;result=invoke(cli,level=logging.INFO)
  assert result['exit']==1 and not result['stdout'],result
  error=json.loads(result['stderr']);assert error['ok'] is False
  assert error['error']==('HTTPStatusError' if selected=='late' else 'CanvasAuthError'),error
  assert len(result['requests'])==(2 if selected=='late' else 1)
  assert not result['httpx_logs'],result
  logger.info('receiver-post-failure-marker');assert 'receiver-post-failure-marker' in logs.getvalue()
  cases.append({'name':selected+' failure atomic stdout and restored logger','result':result})
 import httpx,mcp
 result={'disposition':'ACCEPT','groups':5,'actual_http_gets':7,'source':{},'python':sys.version,'httpx':httpx.__version__,'mcp_file':mcp.__file__,'cases':cases,'qualification':'Actual imported CLI/API/client and installed dependencies; authored loopback data only. No module stubs, account, browser or source mutation.'}
 for relative in ('src/canvaspilot/cli.py','src/canvaspilot/api.py','src/canvaspilot/client.py'):
  b=(root/'source'/relative).read_bytes();result['source'][relative]={'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()}
 (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
 (out/'fixture.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
 (out/'expected-full.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'disposition':result['disposition'],'groups':5,'http_gets':7,'source':result['source']}))
finally:
 logger.setLevel(prior[0]);logger.handlers=prior[1];logger.propagate=prior[2]
 server.shutdown();server.server_close();thread.join()
