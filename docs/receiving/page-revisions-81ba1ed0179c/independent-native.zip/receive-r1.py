import pathlib,json,hashlib,os,sys,copy,subprocess,time,threading,http.server,urllib.parse,select,datetime,traceback
B=pathlib.Path('/home/jacob/canvas-revisions-independent-81ba1ed0179c');O=B/'run-r1';S=pathlib.Path('/home/jacob/canvas-page-revisions-81ba1ed0179c/source');PY='/home/jacob/canvaspilot-enrollments-env-65ae877160f6/bin/python'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,b):
 with (O/name).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def jsave(name,v):put(name,(json.dumps(v,indent=2,ensure_ascii=True)+'\n').encode())
eb=(B/'expectations-before-candidate.json').read_bytes();assert sha(eb)=='4100e3a89dca0ca2b971d4457a9d420cfd5a11bcbcab0c27e9a0e6fa00d51317'
E=json.loads(eb);F=E['fixture'];binding=json.loads((B/'runtime-binding.json').read_bytes())
for p in binding['sourceFiles']:assert sha((S/p['path']).read_bytes())==p['sha256']
rec={'schema':'canvaspilot.page-revisions.independent-receiving/1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expectationSha256':sha(eb),'python':sys.version,'groups':[],'passed':False,'method':'Four frozen complementary API/CLI/MCP groups; synthetic loopback/fake transport only. No author or existing test suite, live account, browser, write/revert endpoint or token/config change.'}
class Fake:
 def __init__(self):self.calls=[];self.rows=copy.deepcopy(F['list']);self.row=copy.deepcopy(F['show'])
 def get_paginated(self,path):self.calls.append(('list',path));return self.rows
 def request(self,method,path,params=None):self.calls.append((method,path,params));return self.row
 def close(self):pass
requests=[];server=None;thread=None;mcp=None;children=[];http_mode={'value':'valid'}
def expected_show(row):
 result={'revision':copy.deepcopy(row)}
 if 'body' in row:result['body_text']=None if row['body'] is None else F['expectedShowText']
 return result
error=None
try:
 from canvaspilot.api import CanvasAPI
 fake=Fake();api=CanvasAPI(fake);originalRows=copy.deepcopy(fake.rows);originalRow=copy.deepcopy(fake.row)
 rows=api.list_page_revisions(F['course'],F['page']);assert rows==F['list'];assert fake.calls[-1]==('list',F['route'])
 rows[0]['unknown']['flags'].append('changed');rows[1]['unknown'][1]['名']='changed';assert fake.rows==originalRows
 assert api.list_page_revisions(F['course'],F['page'])==F['list']
 shown=api.get_page_revision(F['course'],F['page'],'0007',summary=True);assert shown==expected_show(F['show'])
 assert fake.calls[-1]==('GET',F['route']+'/7',{'summary':True}) and type(fake.calls[-1][2]['summary']) is bool
 shown['revision']['unknown']['flags'].append('changed');shown['revision']['body_text']='changed';assert fake.row==originalRow
 assert api.get_page_revision(F['course'],F['page'],'latest')==expected_show(F['show'])
 assert fake.calls[-1]==('GET',F['route']+'/latest',{'summary':False})
 rec['groups'].append({'id':1,'passed':True,'name':'Exact once-encoded route, canonical IDs and complete detached metadata','calls':copy.deepcopy(fake.calls),'list':F['list'],'show':expected_show(F['show'])})
 for key in ['absent','nullBody']:
  fake.row=copy.deepcopy(F[key]);before=copy.deepcopy(fake.row)
  out=api.get_page_revision(1,F['page'],7);expected={'revision':copy.deepcopy(F[key])}
  if key=='nullBody':expected['body_text']=None
  assert out==expected and fake.row==before
 fake.row=copy.deepcopy(F['show'])
 refusals=[]
 for e in E['inputRefusals']:
  kw={'course_id':F['course'],'page_url':F['page'],'revision_id':'0007','summary':False}
  v=e.get('value');g=e.get('generator','')
  if g.startswith('bad +'):v='bad'+chr(127)+'name'
  elif 'surrogate' in g:v=chr(0xd800)
  elif '2049' in g:v='é'*1024+'a'
  field={'course':'course_id','page':'page_url','revision':'revision_id','summary':'summary'}[e['field']];kw[field]=v
  count=len(fake.calls);before=(copy.deepcopy(fake.row),copy.deepcopy(fake.rows));message=None
  try:api.get_page_revision(**kw)
  except (ValueError,TypeError) as ex:message=str(ex)
  assert message and len(fake.calls)==count and before==(fake.row,fake.rows),e
  refusals.append({'case':e,'message':message,'transportCalls':0})
 for page,ending in [('é'*1024,'%C3%A9'*1024),(chr(0x85),'%C2%85')]:
  api.get_page_revision(1,page,'latest');assert fake.calls[-1][1]=='/api/v1/courses/1/pages/'+ending+'/revisions/latest'
 fake.row={'revision_id':'9223372036854775807'};assert api.get_page_revision(1,F['page'],'9223372036854775807')=={'revision':fake.row}
 responses=[]
 for e in E['responseRefusals']:
  before=copy.deepcopy(e['response']);message=None
  if isinstance(before,list):fake.rows=copy.deepcopy(before)
  else:fake.row=copy.deepcopy(before)
  try:
   if isinstance(before,list):api.list_page_revisions(1,F['page'])
   else:api.get_page_revision(1,F['page'],7)
  except (TypeError,ValueError) as ex:message=str(ex)
  assert message and (fake.rows if isinstance(before,list) else fake.row)==before
  responses.append({'case':e['case'],'message':message,'originalPreserved':True})
 rec['groups'].append({'id':2,'passed':True,'name':'Outer derived-field collision, absent/null,15 strict input refusals,3 valid boundaries and4 complete response refusals','inputRefusals':refusals,'responseRefusals':responses,'outerBodyTextDoesNotOverwriteServer':True})
 class Handler(http.server.BaseHTTPRequestHandler):
  def do_GET(self):
   u=urllib.parse.urlsplit(self.path);requests.append({'method':'GET','path':u.path,'query':urllib.parse.parse_qs(u.query),'authorizationIsSynthetic':self.headers.get('Authorization')=='Bearer independent-loopback-fixture-token'})
   assert self.headers.get('Authorization')=='Bearer independent-loopback-fixture-token'
   if u.path==F['route']:response=F['list']
   elif u.path in [F['route']+'/7',F['route']+'/latest']:response=F['show'] if http_mode['value']=='valid' else {'revision_id':8,'body':'mismatch'}
   else:self.send_error(404);return
   b=json.dumps(response,ensure_ascii=False).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
  def do_POST(self):requests.append({'method':'POST','path':self.path});self.send_error(405)
  def log_message(self,*args):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 base='http://127.0.0.1:'+str(server.server_address[1]);rec['loopback']=base
 env={k:v for k,v in os.environ.items() if k in ['PATH','LANG','LC_ALL']};env.update(PYTHONPATH=str(S/'src'),PYTHONDONTWRITEBYTECODE='1',CANVAS_BASE_URL=base,CANVAS_API_TOKEN='independent-loopback-fixture-token',CANVAS_PROFILE=str(B/'unused-fixture-profile'),NO_PROXY='127.0.0.1')
 def cli(name):
  cmd=[PY,'-B','-m','canvaspilot.cli','page-revision',F['course'],F['page'],'0007','--base-url',base,'--token','independent-loopback-fixture-token','--profile',str(B/'unused-fixture-profile')]
  p=subprocess.Popen(cmd,cwd=O,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);children.append(p.pid);out,err=p.communicate(timeout=15);put(name+'.stdout',out);put(name+'.stderr',err);return p.returncode,out,err
 before=len(requests);code,out,err=cli('cli-success');assert code==0 and json.loads(out)==expected_show(F['show']) and not err
 assert requests[before]['path']==F['route']+'/7' and requests[before]['query'].get('summary')==['false']
 http_mode['value']='mismatch';code2,out2,err2=cli('cli-refusal');assert code2==1 and not out2 and isinstance(json.loads(err2),dict);http_mode['value']='valid'
 assert len(requests)==before+2
 rec['groups'].append({'id':3,'passed':True,'name':'Actual CLI success and whole-output numeric-ID mismatch refusal','successExit':code,'refusalExit':code2,'success':json.loads(out),'refusal':json.loads(err2),'requests':copy.deepcopy(requests[before:])})
 mcp=subprocess.Popen([PY,'-B','-m','canvaspilot.cli','mcp'],cwd=O,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);children.append(mcp.pid)
 buf=b'';protocol=[];seq=0
 def send(v):mcp.stdin.write((json.dumps(v,ensure_ascii=True)+'\n').encode());mcp.stdin.flush();protocol.append({'direction':'send','message':v})
 def request(method,params):
  global seq,buf
  seq+=1;want=seq;send({'jsonrpc':'2.0','id':want,'method':method,'params':params});end=time.monotonic()+12
  while time.monotonic()<end:
   while b'\n' in buf:
    line,buf=buf.split(b'\n',1)
    if not line.strip():continue
    msg=json.loads(line);protocol.append({'direction':'receive','message':msg})
    if msg.get('id')==want:return msg
   ready,_,_=select.select([mcp.stdout],[],[],.1)
   if ready:
    b=os.read(mcp.stdout.fileno(),65536)
    if not b:raise RuntimeError('MCP closed before reply; exit '+str(mcp.poll()))
    buf+=b
  raise TimeoutError('MCP '+method)
 init=request('initialize',{'protocolVersion':'2024-11-05','capabilities':{},'clientInfo':{'name':'independent-page-revisions','version':'1'}});assert 'result' in init
 send({'jsonrpc':'2.0','method':'notifications/initialized'})
 listed=request('tools/list',{});tools={x['name']:x for x in listed['result']['tools']}
 names=['canvas_list_page_revisions','canvas_get_page_revision'];metadata={}
 for n in names:
  ann=tools[n]['annotations'];assert ann['readOnlyHint'] is True and ann['destructiveHint'] is False and ann['idempotentHint'] is True;metadata[n]=tools[n]
 def call(name,args):
  r=request('tools/call',{'name':name,'arguments':args});assert 'result' in r;return r['result']
 count=len(requests);listedResult=call(names[0],{'course_id':F['course'],'page_url':F['page']});assert not listedResult.get('isError');assert json.loads(listedResult['content'][0]['text'])==F['list']
 shownResult=call(names[1],{'course_id':F['course'],'page_url':F['page'],'revision_id':'latest','summary':False});assert not shownResult.get('isError');assert json.loads(shownResult['content'][0]['text'])==expected_show(F['show'])
 assert len(requests)==count+2 and requests[count]['path']==F['route'] and requests[count+1]['path']==F['route']+'/latest'
 before=len(requests);bad=call(names[1],{'course_id':F['course'],'page_url':F['page'],'revision_id':'latest','summary':'true'});assert bad.get('isError') is True and len(requests)==before
 mcp.stdin.close();mcp.stdin=None;tail,stderr=mcp.communicate(timeout=5);put('mcp.stdout-tail',tail);put('mcp.stderr',stderr);assert mcp.returncode==0
 jsave('mcp-protocol.json',protocol)
 rec['groups'].append({'id':4,'passed':True,'name':'Actual registered MCP stdio metadata/list/latest/StrictBool refusal','metadata':metadata,'strictBoolError':bad,'processExit':mcp.returncode,'httpRequests':copy.deepcopy(requests[count:])})
 assert all(r['method']=='GET' and r['authorizationIsSynthetic'] for r in requests);assert not (B/'unused-fixture-profile').exists();rec['passed']=True
except Exception as ex:error=ex;rec['error']={'type':type(ex).__name__,'message':str(ex),'traceback':traceback.format_exc()}
finally:
 if mcp and mcp.poll() is None:
  try:mcp.terminate();mcp.wait(timeout=3)
  except subprocess.TimeoutExpired:mcp.kill();mcp.wait(timeout=3)
 if server:server.shutdown();server.server_close();thread.join(timeout=3)
 rec['childPids']=children;rec['childrenAbsent']=all(not pathlib.Path('/proc',str(p)).exists() for p in children);rec['httpRequests']=requests;rec['serverThreadStopped']=not thread or not thread.is_alive()
 rec['sourceUnchanged']=all(sha((S/p['path']).read_bytes())==p['sha256'] for p in binding['sourceFiles'])
 rec['passed']=rec['passed'] and rec['childrenAbsent'] and rec['serverThreadStopped'] and rec['sourceUnchanged']
 jsave('receipt.json',rec)
print(json.dumps({'passed':rec['passed'],'groups':len(rec['groups']),'receiptBytes':(O/'receipt.json').stat().st_size,'receiptSha256':sha((O/'receipt.json').read_bytes()),'error':rec.get('error',{}).get('message')}))
if not rec['passed']:sys.exit(1)
