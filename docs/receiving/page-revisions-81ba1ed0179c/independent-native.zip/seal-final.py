import pathlib,json,hashlib,os,zipfile,datetime,subprocess,socket
B=pathlib.Path('/home/jacob/canvas-revisions-independent-81ba1ed0179c');S=pathlib.Path('/home/jacob/canvas-page-revisions-81ba1ed0179c/source')
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,b,mode=0o644):
 p.parent.mkdir(parents=True,exist_ok=True)
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
 with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b
r=json.loads((B/'run-r1/receipt.json').read_bytes());w=json.loads((B/'run-r1/wrapper.json').read_bytes());binding=json.loads((B/'runtime-binding.json').read_bytes())
assert sha((B/'run-r1/receipt.json').read_bytes())=='762c539f71cdaebe127b48811a4f59ac49eead8e39e0223685900054e59af884'
assert r['passed'] and len(r['groups'])==4 and w['exit']==0 and not w['remainingOwnGroup']
pids=[w['wrapperPid'],w['productPid']]+r['childPids'];assert all(not pathlib.Path('/proc',str(p)).exists() for p in pids)
port=int(r['loopback'].rsplit(':',1)[1]);listeners=[]
for line in pathlib.Path('/proc/net/tcp').read_text().splitlines()[1:]:
 parts=line.split()
 if parts[3]=='0A' and int(parts[1].split(':')[1],16)==port:listeners.append(parts[1])
assert not listeners and not (B/'unused-fixture-profile').exists()
for p in binding['sourceFiles']:
 b=(S/p['path']).read_bytes();assert sha(b)==p['sha256'];put(B/'received-runtime'/p['path'],b,(S/p['path']).stat().st_mode&0o777)
guide=S/'docs/page-revisions.md';assert sha(guide.read_bytes())=='3162e234d9f2c1a0d6240699edea5e1a30136af899923e299b8dcdcd6312dd24';put(B/'received-guide.md',guide.read_bytes())
lines=(S/'src/canvaspilot/cli.py').read_text().splitlines();assert lines[907].strip()=='finally:' and 'api.close()' in lines[908]
cleanup={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pids':pids,'allAbsent':True,'serverPort':port,'listeners':listeners,'unusedFixtureProfileAbsent':True,'runtimeSource32Exact':True}
put(B/'final-cleanup.json',(json.dumps(cleanup,indent=2)+'\n').encode())
review={'schema':'canvaspilot.revisions.independent-final/1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'outcome':'qualified zero blockers','sourceHead':'a317417a8a2c39fb23256102904c24fba16a969a','sourceManifestSha256':'a9e5076bc1e94ea10d397b7c06a7a6c3684a2b7ca62ceedf75d209c43e8ef155','frozenBeforeCandidate':'4100e3a89dca0ca2b971d4457a9d420cfd5a11bcbcab0c27e9a0e6fa00d51317','actualReceiptSha256':'762c539f71cdaebe127b48811a4f59ac49eead8e39e0223685900054e59af884','actualGroups':4,'actualRuntimeSeconds':w['elapsed'],'boundedCases':{'strictInputRefusals':15,'validBoundaries':3,'completeResponseRefusals':4,'actualCliProcesses':2,'registeredMcpProcess':1,'actualHttpRequests':4,'allHttpMethods':'GET'},'operatorBenefit':'Recorded revisions and historical body retain complete server metadata, including an unknown body_text key, in a detached inner object. Derived outer text preserves absent versus null content. IDs/path/summary are strict before transport. Actual CLI failure has no successful stdout; registered MCP rejects coercive summary before HTTP.','sourceExposure':'Only contract+envelope addendum before freeze. Candidate pure module, additive API/CLI/MCP slices, unchanged client binding and guide read after freeze. Full32 tracked runtime blobs verified/copied after receiving; no author test bodies or suite read/run.','boundedStaticReview':{'pureModule':'Canonical bounded IDs, literal page exactly once quoted, whole-response duplicate/mismatch checks and deepcopy preserve raw object. Only outer body_text derived through unchanged strip_html.','cli':'Actual0/1 exit and stdout/stderr fidelity observed; unchanged outer finally api.close() read statically at lines908/909, not instrumented.','mcp':'Actual registration annotations and StrictBool tool refusal observed; EOF process exited0. No additional in-process client-close instrumentation claim.','guide':'Exact3162e234 coherently discloses editor rights, no permission escalation/revert, historical locator differences, raw envelope, existing paginator scope and synthetic receiving limits.'},'limits':['No live Canvas, school account or real editor permission qualification.','No POST/PUT/delete/revert or current-page change; no peer credentials/profile touched.','No original18 or author60 test-suite replay, no browser/installation.','Full HTTP transport is synthetic loopback with an explicit synthetic token; actual four observed requests onlyGET.'],'negatives':['One orchestrator serializer rejected a literal lone-surrogate expectation before native invocation. Destination was confirmed absent; same refusal represented by a Unicode-codepoint generator in actual frozen file. No native product failure or retry.'],'cleanupSha256':sha((B/'final-cleanup.json').read_bytes())}
put(B/'independent-final.json',(json.dumps(review,indent=2)+'\n').encode())
D=B/'delivery';D.mkdir();files=[p for p in sorted(B.rglob('*')) if p.is_file() and not p.is_relative_to(D)]
entries=[{'path':p.relative_to(B).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'mode':p.stat().st_mode&0o777} for p in files];mb=(json.dumps({'files':entries},indent=2)+'\n').encode();put(D/'members.json',mb)
Z=D/'Canvas-page-revisions-independent.zip'
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(B).as_posix())
 z.write(D/'members.json','custody-members.json')
with Z.open('r+b') as f:f.flush();os.fsync(f.fileno())
with zipfile.ZipFile(Z) as z:
 assert len(z.infolist())==len(files)+1
 for e in entries:
  i=z.getinfo(e['path']);assert z.read(i)==(B/e['path']).read_bytes() and (i.external_attr>>16)&0o777==e['mode']
 assert z.read('custody-members.json')==mb
receipt={'archive':{'path':str(Z),'bytes':Z.stat().st_size,'sha256':sha(Z.read_bytes()),'members':len(files)+1},'review':{'bytes':(B/'independent-final.json').stat().st_size,'sha256':sha((B/'independent-final.json').read_bytes())},'allMembersReopened':True,'cleanupSha256':sha((B/'final-cleanup.json').read_bytes())};put(D/'custody-receipt.json',(json.dumps(receipt,indent=2)+'\n').encode())
dest='/srv/hamon-estate/coord/estate-81ba1ed0179c/canvas-page-revisions-independent';spec=[{'source':str(p),'name':p.name,'sha256':sha(p.read_bytes())} for p in [Z,D/'members.json',D/'custody-receipt.json',B/'independent-final.json']]
rootcode="""import pathlib,hashlib,json,os
D=pathlib.Path(%r);D.mkdir(mode=0o700);os.chown(D,1000,1000)
for e in json.loads(%r):
 b=pathlib.Path(e['source']).read_bytes();assert hashlib.sha256(b).hexdigest()==e['sha256'];p=D/e['name']
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 os.chown(p,1000,1000);assert p.read_bytes()==b
"""%(dest,json.dumps(spec))
subprocess.run(['sudo','-n','python3','-c',rootcode],check=True)
print(json.dumps(receipt));print(json.dumps({'durable':dest+'/'+Z.name}))
