import pathlib,hashlib,json,os,subprocess,datetime
B=pathlib.Path('/home/jacob/canvas-revisions-independent-81ba1ed0179c');S=pathlib.Path('/home/jacob/canvas-page-revisions-81ba1ed0179c/source')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((B/'expectations-before-candidate.json').read_bytes())=='4100e3a89dca0ca2b971d4457a9d420cfd5a11bcbcab0c27e9a0e6fa00d51317'
p=pathlib.Path('/home/jacob/canvas-page-revisions-81ba1ed0179c/evidence/source-freeze-r2.json');b=p.read_bytes();assert sha(b)=='a9e5076bc1e94ea10d397b7c06a7a6c3684a2b7ca62ceedf75d209c43e8ef155'
with (B/'candidate-source-freeze.json').open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
head=subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip();assert head=='a317417a8a2c39fb23256102904c24fba16a969a'
rows=[]
for record in subprocess.check_output(['git','-C',str(S),'ls-files','-s','--','src']).decode().splitlines():
 meta,name=record.split('\t');mode,obj,stage=meta.split();p=S/name;b=p.read_bytes();assert hashlib.sha1(('blob %d\0'%len(b)).encode()+b).hexdigest()==obj;rows.append({'path':name,'bytes':len(b),'sha256':sha(b),'gitBlob':obj,'gitMode':mode})
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(S),'head':head,'sourceFiles':rows,'python':'/home/jacob/canvaspilot-enrollments-env-65ae877160f6/bin/python','method':'All tracked runtime src Git blobs verified before independent imports, no authored test body read. Candidate-only after frozen4100e3a8.'}
data=(json.dumps(v,indent=2)+'\n').encode()
with (B/'runtime-binding.json').open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
print(json.dumps({'files':len(rows),'bytes':len(data),'sha256':sha(data),'head':head}))
