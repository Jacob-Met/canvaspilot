import pathlib,os,hashlib,json,subprocess,time,signal,datetime
B=pathlib.Path('/home/jacob/canvas-revisions-independent-81ba1ed0179c');O=B/'run-r1';P='/home/jacob/canvaspilot-enrollments-env-65ae877160f6/bin/python';S=pathlib.Path('/home/jacob/canvas-page-revisions-81ba1ed0179c/source')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((B/'receive-r1.py').read_bytes())=='a075b15e4ea8274393a469c8dbba6c9efc5c2dba34fcc40d01e50b87432929ea'
binding=json.loads((B/'runtime-binding.json').read_bytes())
for e in binding['sourceFiles']:assert sha((S/e['path']).read_bytes())==e['sha256']
mem=int(next(x for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')).split()[1])*1024;v=os.statvfs(B);free=v.f_bavail*v.f_frsize;assert mem>=2147483648 and free>=268435456,(mem,free)
O.mkdir(mode=0o700);env={k:v for k,v in os.environ.items() if k in ['PATH','LANG','LC_ALL']};env.update(PYTHONPATH=str(S/'src'),PYTHONDONTWRITEBYTECODE='1')
t=time.monotonic();p=subprocess.Popen([P,'-B',str(B/'receive-r1.py')],cwd=O,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timeout=False
try:out,err=p.communicate(timeout=60)
except subprocess.TimeoutExpired:
 timeout=True;os.killpg(p.pid,signal.SIGTERM)
 try:out,err=p.communicate(timeout=3)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate(timeout=5)
for name,b in [('outer.stdout',out),('outer.stderr',err)]:
 with (O/name).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
remaining=[]
for q in pathlib.Path('/proc').iterdir():
 if q.name.isdigit():
  try:
   st=(q/'stat').read_text().split(') ',1)[1].split()
   if int(st[2])==p.pid:remaining.append(int(q.name))
  except (FileNotFoundError,PermissionError,ProcessLookupError):pass
r={'schema':'canvaspilot.revisions.independent-wrapper/1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapperPid':os.getpid(),'productPid':p.pid,'exit':p.returncode,'elapsed':time.monotonic()-t,'timeout':timeout,'remainingOwnGroup':remaining,'productAbsent':not pathlib.Path('/proc',str(p.pid)).exists(),'sourceUnchanged':all(sha((S/e['path']).read_bytes())==e['sha256'] for e in binding['sourceFiles']),'admission':{'memoryAvailable':mem,'diskAvailable':free,'memoryFloor':2147483648,'diskFloor':268435456},'stdout':{'bytes':len(out),'sha256':sha(out)},'stderr':{'bytes':len(err),'sha256':sha(err)}}
with (O/'wrapper.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'wrapper':r,'stdout':out.decode(),'stderr':err.decode()}));assert p.returncode==0 and not timeout and not remaining and r['sourceUnchanged']
