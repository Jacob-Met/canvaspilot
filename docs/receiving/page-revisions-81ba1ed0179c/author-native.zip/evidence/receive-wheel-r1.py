import pathlib,subprocess,os,json,hashlib,zipfile,time,traceback
B=pathlib.Path('/home/jacob/canvas-page-revisions-81ba1ed0179c');S=B/'source';E=B/'evidence/wheel-r1';E.mkdir();(E/'tmp').mkdir();(E/'wheels').mkdir()
P='/home/jacob/canvaspilot-enrollments-env-65ae877160f6/bin/python'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(E/'tmp'));env.pop('PYTHONPATH',None)
r={'commands':[],'passed':False}
def run(c,n):
 with (E/(n+'.stdout')).open('wb') as o,(E/(n+'.stderr')).open('wb') as e:p=subprocess.run(c,cwd=E,env=env,stdout=o,stderr=e,timeout=150)
 r['commands'].append({'argv':c,'exit':p.returncode});assert p.returncode==0,n
try:
 run([P,'-B','-m','pip','--isolated','wheel','--no-deps','--no-cache-dir','--index-url','https://pypi.org/simple','--wheel-dir',str(E/'wheels'),str(S)],'build')
 ws=list((E/'wheels').glob('*.whl'));assert len(ws)==1;w=ws[0]
 with zipfile.ZipFile(w) as z:
  rows=[]
  for n in ['page_revisions.py','api.py','cli.py','mcp_server.py']:
   b=z.read('canvaspilot/'+n);assert b==(S/'src/canvaspilot'/n).read_bytes()
   rows.append({'path':'canvaspilot/'+n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 r['wheel']={'path':str(w),'bytes':w.stat().st_size,'sha256':hashlib.sha256(w.read_bytes()).hexdigest(),'exact_payloads':rows}
 run([P,'-B','-m','pip','--isolated','install','--no-deps','--no-index','--no-cache-dir','--no-compile','--target',str(E/'installed'),str(w)],'install')
 env['PYTHONPATH']=str(E/'installed')
 run([P,'-B','-m','canvaspilot.cli','page-revisions','--help'],'installed-list-help')
 run([P,'-B','-m','canvaspilot.cli','page-revision','--help'],'installed-show-help')
 run([P,'-B','-c',"import canvaspilot.page_revisions as m; from canvaspilot.api import CanvasAPI; from pathlib import Path; assert Path(m.__file__).resolve().is_relative_to(Path('installed').resolve()); R=type('R',(),{'request':lambda self,*a,**k:{'revision_id':2,'body':'<p>Original &amp; current</p>','body_text':'raw'}}); got=CanvasAPI(R()).get_page_revision(42,'renamed',2); assert got=={'revision':{'revision_id':2,'body':'<p>Original &amp; current</p>','body_text':'raw'},'body_text':'Original & current'}; print(got); print(m.__file__)"],'installed-api')
 r['passed']=True
except BaseException:r['error']=traceback.format_exc()
finally:
 r['source_status']=subprocess.check_output(['git','-C',str(S),'status','--porcelain']).decode()
 b=(json.dumps(r,indent=2)+'\n').encode();(E/'receipt.json').write_bytes(b);print(json.dumps(r));print('receipt',len(b),hashlib.sha256(b).hexdigest())
raise SystemExit(0 if r['passed'] else 1)
