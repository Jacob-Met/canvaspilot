# Announcement search: author receiving

Source claim: Jacob-Met/canvaspilot #74; contributor406d0fb04c43 / memory_integration.
Original main1bafdaa31f7789d8e561680cb6001bbe38b2da64, treefc4c5cee949a3a15caf32111af9144cb7eb95b6d.
Current composition parentf618c3ed13f191ea58642283c1f9cd45a0c1ca81, tree1bcfff90694cdb8358684ada58ff349562244de7.
Frozen current candidate2239de20e604318feccd82b1eec3db4553e7c0e7, treeaa8c890ed82177024cf9bf35a13635974ed59c26.

## What was received

- The actual unchanged baseline CLI has no find-announcements command: exit2, empty stdout and zero fixture requests. Existing full-reader, compact-reader and later-page-refusal controls all pass (three controls, one intended missing-capability failure).
- Original author runtime passes17/17 semantic/process methods:21 actual independent `python -B -m canvaspilot.cli` children plus six actual in-process CLI/logger calls, using real HTTPX against only an owned numeric-loopback server. Full text beyond400 characters, Unicode casefold expansion, literals, significant whitespace, exact course/date/opaque cursor routing, duplicate IDs, null/zero metadata, no matches, argument admission and no partial result on later-page failure are checked.
- The initial focused Ruff check finds two inappropriate ValueError categories for malformed helper containers, new-test formatting issues, and import misclassification caused by the absent physical src layout. The original result is preserved.
- Author v2 changes only those two malformed-container exceptions to TypeError and reformats the new tests. The public CLI/search behavior remains exact. Its focused successor passes8 semantic methods plus the changed parser-before-client method,9/9. Ruff passes allfour contributed Python files plus an unchanged-original-CLI control, with Python3.11 and canvaspilot first-party classification matching the actual project layout. No rule suppression or owner-source edit.
- Current main then receives page-packet PR71. The exact three search spans compose onto its CLI and the exact README suffix appends to its README. All18 other current runtime modules, including the new page exporter, are byte-preserved. The current20-module archive is source-qualified; independent actual-current receiving and hosted gates are tracked separately and are not claimed by this author packet.

## Native execution and boundaries

The existing Python3.12.14 environment is read-only. Its editable donor is stale, so the complete canonical package loads through standard zipimport from sealed Linux memfd ZIPs. All input module Git blobs are checked, all four memfd seals are verified, every loaded CanvasPilot module origin is checked, and every source/test ZIP is re-read unchanged after execution. This is actual maintained package/CLI execution; there is no custom importer, mock API, or transport replacement. Only the explicit invalid-argument pre-setup tripwires substitute constructors.
All fixture credentials and content are synthetic. Environment proxy and Canvas variables are cleared; every successful request targets an owned 127.0.0.1 server with an explicit synthetic token, explicit base URL and absent profile. No school account, installed session broker, live provider, browser profile, hamon-ie MCP, install or deployment is used.
The included complete executed scripts retain their exact embedded source/test payloads. They make no filesystem writes and can be invoked with an existing compatible Python environment. Normal repository pytest also collects the same test source. This local packet does not claim full-repository pytest/lint or a complete third-party dependency closure; normal hosted CI remains authoritative for those gates.

## Preserved preparation failures

Local scratch and tmpfs were full. Only104 manifest/byte-verified redundant files from this contributor's completed work were unlinked; all six retained archives stayed exact and net free capacity remained zero. No other-owner files were touched.
The first baseline preparation stopped before any product call because this Python fcntl omits the named Linux seal constants. The setup-only successor uses values read from installed UAPI headers (ADD1033, GET1034, seal bits15).
The first candidate preparation used namespace-local os.getpid() in a mounted /proc path and stopped before importing any test. A read-only preflight showed /proc/self points to an outer PID, so its setup-only successor uses that symlink. Every source and behavioral assertion stayed unchanged.
An attempted RAM holder was stopped after an unusable cross-exec path was detected. No shared persistent path or completed run was claimed from that attempt. The active run path always stays within its owning process tree.
An initial Ruff --show-settings/--stdin-filename probe was rejected by Ruff before checking source; the read-only supported settings probe is retained.
Binary Git objects were read back through fetch_file encoding=base64; UTF8-only blob-fetch failures do not represent product failures.

## Package integrity

MANIFEST.json binds every payload leaf. The archive assembler re-read every regular member and matched its exact input bytes before exposing sealed chunks. The published receipt binds the archive length/SHA256/Git blob. Original failures, source versions and actual outputs remain distinct.
