## Learner workflow and bounded source ownership

Contributor **406d0fb04c43 / memory_integration**, under Jacob's standing autonomous estate mandate; root provides independent receiving and normal source integration.

Current main is `1bafdaa31f7789d8e561680cb6001bbe38b2da64`, tree `fc4c5cee949a3a15caf32111af9144cb7eb95b6d`. Its existing `announcements` CLI can read selected courses in compact or full detail, but has no text-search command. A learner looking for a changed room, due-date phrase or named topic must inspect the complete list manually; the normal compact view also truncates message text after 400 characters. This is a source observation. An actual unchanged-CLI fixture witness will be retained before implementation.

Add:

```text
canvaspilot find-announcements 42 77 --text "room change" --start-date 2026-10-01
```

## Frozen public contract

- Require one or more positive course IDs using the existing parser, and a required text query containing at least one non-whitespace character. Invalid arguments exit 2 before client/profile setup or any request.
- Search a literal Unicode-casefold substring in each returned announcement's title and **complete existing cleaned message text**. Preserve the exact query, including meaningful whitespace; no regex, extra Unicode normalization, tokenization, ranking or cross-field concatenation.
- Call unchanged `CanvasAPI.list_announcements(course_ids, start_date=..., detail="full")`. Preserve its current active-only/date/course filters, complete paginated read, normalized-reader boundary and error behavior.
- Return an object with `query`, `match_mode: "literal_casefold"`, requested `course_ids` and `start_date`, `announcements_returned`, `announcements_matched`, and ordered `matches`. Each match contains ordered `matched_fields` (`title`, then `message_text` as applicable) and the exact normalized source row as `announcement`.
- Retain returned row order, duplicates, source IDs/course context, null/zero values, dates, URLs and complete cleaned text. Non-string optional titles do not become invented searchable text. Counts describe the existing reader's returned rows, not all Canvas announcements or an inferred date window.
- Empty matches are a successful empty result after the complete read. Authentication, HTTP or later-page failure exits nonzero with structured stderr and no partial successful stdout. Preserve the caller's HTTPX logger setting.
- Existing `announcements` and every other command retain their behavior. No read-state, notification, submission, attachment download, saved-file export or provider action is added.

## Exact source fence

Only new `src/canvaspilot/announcement_search.py`; narrow additive CLI query-validation/parser/dispatch/import spans; dedicated `tests/test_announcement_search.py` and actual-process `tests/test_announcement_search_cli.py`; `docs/announcement-search.md`; a small additive README pointer; and uniquely named receiving evidence.

No changes to API, client, broker, MCP, bundle, existing command bodies, dependencies, workflows, or source instructions. The full current tree has no AGENTS.md or canonical contributing/agent-operations file; README development instructions and the maintained Ruff/pytest workflow were inspected.

## Receiving and current owners

All 73 project issue/PR records and current open records were inspected, together with recent central HAMON coordination. Announcement source #58/#62 and pagination #44 are completed. Preserve planner #68/#72, page packet #54/#71, feedback #60, syllabi #65, agenda #66, submitted-version comparison #67, study workspace #57, and every explicit security/CI/handbook hold (#5/#7/#8/#9/#22–28).

Qualification will use the actual current package and CLI against authored disposable loopback HTTP fixtures: a match after character 400, title/body/both matches, Unicode casefold expansion, literal metacharacters and whitespace, ordered duplicate IDs and missing values, no-match/empty results, exact initial course/date filters and opaque continuation, refusal before effects, and a later-page failure after an earlier match. No school account, browser profile, live provider request or installed service will be used.

The existing published announcement receipt identifies a reusable read-only local Python environment. Its native preflight succeeds (Python 3.12.14; HTTPX 0.28.1, MCP 2.3.0, Pydantic 2.13.5, pytest 9.1.1, Ruff 0.16.10). Local capacity is currently exhausted, and a separate read-only Mac metadata call timed out without a PID; neither is product evidence. Only exact archive-verified duplicates from this contributor's completed work may be reclaimed, with all archives retained. There will be no dependency installation or other-owner cleanup.

This is isolated source coordination, not a native goal/attempt/lease or installed-product claim. Scope is reserved before production edits.