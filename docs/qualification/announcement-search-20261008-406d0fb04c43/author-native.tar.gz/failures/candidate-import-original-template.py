import base64,fcntl,hashlib,importlib,io,json,os,subprocess,sys,time,unittest,zipfile,zlib
GROUPS=__SOURCE_GROUPS__
PRODUCT=__PRODUCT__
def decode(group):
 raw=zlib.decompress(base64.b64decode(group["base64"]))
 if len(raw)!=group["bytes"] or hashlib.sha256(raw).hexdigest()!=group["sha256"]:raise RuntimeError("transport group mismatch")
 return json.loads(raw)
catalog=[]
for group in GROUPS:catalog.extend(decode(group))
def pin(path,content):
 b=content.encode("utf-8")
 return {"path":path,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"gitBlob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
for row in catalog:
 actual=pin(row["path"],row["content"])
 if actual["bytes"]!=row["bytes"] or actual["gitBlob"]!=row["gitBlob"]:raise RuntimeError("baseline source pin mismatch "+row["path"])
products=decode(PRODUCT)
expected={r["path"]:r for r in PRODUCT["manifest"]}
for row in products:
 if pin(row["path"],row["content"])!=expected[row["path"]]:raise RuntimeError("product pin mismatch "+row["path"])
baseline={row["path"]:row["content"] for row in catalog}
sources=dict(baseline)
for row in products:
 if row["path"].startswith("src/"):sources[row["path"]]=row["content"]
protected=[path for path in baseline if path!="src/canvaspilot/cli.py"]
if len(protected)!=17 or not all(sources[p]==baseline[p] for p in protected):raise RuntimeError("protected source mismatch")
def make_zip(files):
 stream=io.BytesIO()
 with zipfile.ZipFile(stream,"w",allowZip64=False) as archive:
  for path,content in sorted(files.items()):
   item=zipfile.ZipInfo(path,(2026,10,8,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16
   archive.writestr(item,content.encode("utf-8"),compresslevel=9)
 return stream.getvalue()
source_zip=make_zip({p.removeprefix("src/"):s for p,s in sources.items()})
test_files={r["path"]:r["content"] for r in products if r["path"].startswith("tests/")}
test_zip=make_zip({p.removeprefix("tests/"):s for p,s in test_files.items()})
fds=[]
def sealed(data,name):
 fd=os.memfd_create(name,os.MFD_CLOEXEC|os.MFD_ALLOW_SEALING);os.write(fd,data);fcntl.fcntl(fd,1033,15)
 if fcntl.fcntl(fd,1034)!=15:raise RuntimeError("unsealed receiving source")
 fds.append((fd,data));return "/proc/"+str(os.getpid())+"/fd/"+str(fd)
source_path=sealed(source_zip,"canvas74-candidate-source-v1")
test_path=sealed(test_zip,"canvas74-author-tests-v1")
for key in list(os.environ):
 if key.lower().endswith("_proxy") or key.startswith("CANVAS_"):os.environ.pop(key,None)
os.environ.update({"PYTHONPATH":source_path,"PYTHONDONTWRITEBYTECODE":"1","PYTHONNOUSERSITE":"1","CANVAS_SESSION_PORT":"1"})
sys.dont_write_bytecode=True;sys.path[:0]=[source_path,test_path]
for path,content in {**sources,**test_files}.items():compile(content,path,"exec")
modules=[importlib.import_module("test_announcement_search"),importlib.import_module("test_announcement_search_cli")]
for module in modules:
 if not module.__file__.startswith(test_path+"/"):raise RuntimeError("test origin mismatch")
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(m) for m in modules)
test_log=io.StringIO();started=time.monotonic()
result=unittest.TextTestRunner(stream=test_log,verbosity=2).run(suite)
loaded={name:getattr(module,"__file__",None) for name,module in sys.modules.items() if name=="canvaspilot" or name.startswith("canvaspilot.")}
if not loaded or not all(path and path.startswith(source_path+"/") for path in loaded.values()):raise RuntimeError("runtime source origin mismatch")
ruff=[]
for row in products:
 if not row["path"].endswith(".py"):continue
 args=[sys.executable,"-B","-m","ruff","check","--isolated","--no-cache","--stdin-filename",row["path"],"-"]
 r=subprocess.run(args,input=row["content"],capture_output=True,text=True,timeout=20,check=False)
 ruff.append({"path":row["path"],"args":args,"status":r.returncode,"stdout":r.stdout,"stderr":r.stderr})
closure=[]
for fd,data in fds:
 actual=os.pread(fd,len(data),0)
 closure.append({"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"afterSha256":hashlib.sha256(actual).hexdigest(),"seals":fcntl.fcntl(fd,1034)})
 if data!=actual:raise RuntimeError("frozen source changed")
 os.close(fd)
receipt={"schema":"canvaspilot74.author-native.v1","baselineCommit":"1bafdaa31f7789d8e561680cb6001bbe38b2da64","baselineTree":"fc4c5cee949a3a15caf32111af9144cb7eb95b6d","runtime":{"python":sys.executable,"version":sys.version,"platform":sys.platform},"sourceManifest":[pin(p,s) for p,s in sorted(sources.items())],"productManifest":PRODUCT["manifest"],"protectedSourceLeaves":len(protected),"sourceClosure":closure,"moduleOrigins":loaded,"tests":{"methods":result.testsRun,"failures":[{"test":str(t),"trace":trace} for t,trace in result.failures],"errors":[{"test":str(t),"trace":trace} for t,trace in result.errors],"skipped":[[str(t),why] for t,why in result.skipped],"successful":result.wasSuccessful(),"log":test_log.getvalue(),"seconds":time.monotonic()-started,"actualCliCalls":modules[1].RECEIVING_CALLS},"ruff":ruff,"scope":"Actual unmodified candidate modules and test files loaded by standard zipimport, sealed Linux memfd within one process tree; 21 independent CLI children use -m canvaspilot.cli and real numeric-loopback HTTPX. Six further actual in-process CLI invocations verify logger restoration. Only blank-query pre-client tripwires mock constructors. No provider, broker, installed service, package install, filesystem write, custom importer, or API/transport shim. Focused Ruff stdin checks use the exact four contributed Python source files; no full-suite or full-repository lint claim."}
print(json.dumps(receipt,ensure_ascii=False))
sys.exit(0 if result.wasSuccessful() and all(x["status"]==0 for x in ruff) else 1)
