import base64,fcntl,hashlib,io,json,os,socket,subprocess,sys,threading,time,zipfile,zlib
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlsplit,parse_qsl
GROUPS=__SOURCE_GROUPS__
catalog=[]
for g in GROUPS:
 raw=zlib.decompress(base64.b64decode(g["base64"]))
 if len(raw)!=g["bytes"] or hashlib.sha256(raw).hexdigest()!=g["sha256"]: raise RuntimeError("source group mismatch")
 catalog.extend(json.loads(raw))
buf=io.BytesIO(); manifest=[]
with zipfile.ZipFile(buf,"w",allowZip64=False) as zf:
 for e in sorted(catalog,key=lambda r:r["path"]):
  b=e["content"].encode("utf-8")
  actual=hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
  if len(b)!=e["bytes"] or actual!=e["gitBlob"]: raise RuntimeError("canonical source mismatch "+e["path"])
  name=e["path"].removeprefix("src/"); info=zipfile.ZipInfo(name,(2026,10,8,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;zf.writestr(info,b,compresslevel=9)
  manifest.append({"path":e["path"],"bytes":len(b),"gitBlob":actual,"sha256":hashlib.sha256(b).hexdigest()})
source=buf.getvalue(); source_sha=hashlib.sha256(source).hexdigest()
fd=os.memfd_create("canvaspilot74-baseline",os.MFD_CLOEXEC|os.MFD_ALLOW_SEALING);os.write(fd,source);fcntl.fcntl(fd,fcntl.F_ADD_SEALS,fcntl.F_SEAL_WRITE|fcntl.F_SEAL_GROW|fcntl.F_SEAL_SHRINK|fcntl.F_SEAL_SEAL)
root="/workspace/scratch/406d0fb04c43/agents/memory/canvas-announcement-search";profile=root+"/must-not-create-profile"
if os.path.lexists(profile):raise RuntimeError("fixture profile already exists")
text=("ordinary context "*35)+"Room change to Ω-204."
rows=[{"id":7,"title":"Meeting details","message":"<p>"+text+"</p>","posted_at":"2026-10-08T12:00:00Z","context_code":"course_42","html_url":"https://canvas.invalid/courses/42/discussion_topics/7"},{"id":7,"title":"ROOM CHANGE","message":"<p>Bring notes.</p>","posted_at":None,"context_code":"course_77","html_url":None},{"id":0,"title":None,"message":None,"posted_at":None,"context_code":"course_42","html_url":None}]
requests=[]; mode="ok"
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  parts=urlsplit(self.path); q=parse_qsl(parts.query,keep_blank_values=True);requests.append({"method":"GET","path":parts.path,"query":q,"authorization":self.headers.get("Authorization")})
  if parts.path!="/api/v1/announcements":self.send_error(404);return
  later=any(k=="cursor" for k,v in q)
  if later and mode=="late_failure":self.send_error(503,"synthetic later page failure");return
  b=json.dumps(rows[1:] if later else rows[:1]).encode();self.send_response(200);self.send_header("Content-Type","application/json")
  if not later:self.send_header("Link",'<http://127.0.0.1:'+str(self.server.server_port)+'/api/v1/announcements?cursor=opaque%2Bnext>; rel="next"')
  self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b)
server=ThreadingHTTPServer(("127.0.0.1",0),Handler);server.daemon_threads=True;thread=threading.Thread(target=lambda:server.serve_forever(poll_interval=0.01),daemon=True);thread.start()
env=dict(os.environ)
for k in list(env):
 if k.lower().endswith("_proxy") or k.startswith("CANVAS_") or k=="CANVASPILOT_CHROMIUM_BIN":env.pop(k,None)
env.update({"PYTHONPATH":"/proc/self/fd/"+str(fd),"PYTHONDONTWRITEBYTECODE":"1","PYTHONNOUSERSITE":"1","CANVAS_SESSION_PORT":"1"})
bootstrap='import os,sys,canvaspilot,canvaspilot.cli; prefix=os.environ["PYTHONPATH"]+"/"; loaded=[m for n,m in sys.modules.items() if n=="canvaspilot" or n.startswith("canvaspilot.")]; assert loaded and all(getattr(m,"__file__","").startswith(prefix) for m in loaded), "wrong package source"; canvaspilot.cli.main()'
cases=[]
def run(name,args,wanted):
 global requests
 requests=[];cmd=[sys.executable,"-B","-c",bootstrap,*args,"--base-url","http://127.0.0.1:"+str(server.server_port),"--profile",profile,"--token","synthetic-canvas-search-token"]
 started=time.monotonic();r=subprocess.run(cmd,env=env,pass_fds=(fd,),capture_output=True,text=True,timeout=15,check=False)
 rec={"name":name,"args":args,"status":r.returncode,"stdout":r.stdout,"stderr":r.stderr,"requests":list(requests),"seconds":time.monotonic()-started,"checks":wanted(r,list(requests))}
 rec["accepted"]=all(rec["checks"].values());cases.append(rec)
try:
 run("missing_search_capability",["find-announcements","42","77","--text","room change"],lambda r,q:{"search_command_accepted":r.returncode==0})
 run("original_full_reader",["announcements","42","77","--detail","full","--start-date","2026-10-01"],lambda r,q:{"success":r.returncode==0,"all_three_rows":len(json.loads(r.stdout))==3,"full_tail_present":"Room change to Ω-204." in json.loads(r.stdout)[0]["message_text"],"two_pages":len(q)==2,"initial_course_order":[v for k,v in q[0]["query"] if k=="context_codes[]"]==["course_42","course_77"],"initial_date":("start_date","2026-10-01") in [tuple(x) for x in q[0]["query"]],"opaque_next":q[1]["query"]==[("cursor","opaque+next")]})
 run("original_compact_reader",["announcements","42","77"],lambda r,q:{"success":r.returncode==0,"compact_tail_absent":"Room change" not in json.loads(r.stdout)[0]["message_text"],"compact_length":len(json.loads(r.stdout)[0]["message_text"])==401,"duplicates_and_null":[x["id"] for x in json.loads(r.stdout)]==[7,7,0] and json.loads(r.stdout)[2]["title"] is None,"two_pages":len(q)==2})
 mode="late_failure"
 run("original_later_page_refusal",["announcements","42","77"],lambda r,q:{"failure_status":r.returncode==1,"no_partial_stdout":r.stdout=="","structured_error":json.loads(r.stderr)["error"]=="HTTPStatusError","two_pages":len(q)==2})
finally:
 server.shutdown();server.server_close();thread.join(timeout=2)
os.lseek(fd,0,os.SEEK_SET);after=os.read(fd,len(source));seals=fcntl.fcntl(fd,fcntl.F_GET_SEALS);os.close(fd)
if hashlib.sha256(after).hexdigest()!=source_sha or os.path.lexists(profile):raise RuntimeError("source or profile changed")
receipt={"schema":"canvaspilot74.actual-memfd-baseline.v1","baselineCommit":"1bafdaa31f7789d8e561680cb6001bbe38b2da64","baselineTree":"fc4c5cee949a3a15caf32111af9144cb7eb95b6d","python":sys.executable,"pythonVersion":sys.version,"source":{"modules":len(manifest),"bytes":sum(e["bytes"] for e in manifest),"manifest":manifest,"zipBytes":len(source),"zipSha256":source_sha,"readOnlyMemfdSeals":seals,"afterSha256":hashlib.sha256(after).hexdigest()},"invocation":"Actual canvaspilot.cli:main console entry in independent Python children, with the complete canonical package loaded by standard zipimport from an inherited sealed memfd. Source prefix asserted for every loaded CanvasPilot module; no custom importer or API/transport substitution.","fixture":"Only disposable numeric-loopback HTTP; explicit synthetic token and nonexistent explicit profile; proxy and Canvas variables cleared; no broker/provider access or filesystem writes.","cases":cases,"acceptedGroups":sum(c["accepted"] for c in cases),"groups":len(cases),"missingCapabilityFailures":sum(not c["accepted"] for c in cases),"profileAbsentAfter":True,"sourceUnchanged":True}
print(json.dumps(receipt,ensure_ascii=False))
